#ifndef __HDR_H__
#define __HDR_H__
#define HDR_PIXEL_FORMAT_YUV420_NV12 0
#define HDR_PIXEL_FORMAT_YUV420_NV21 1
extern "C" {
  void *hdr_lc_init(int n); // n: number of input images, then return 
  int hdr_lc_set_params(void *ctx, int width, int height, float contrast_weight, float exposure_weight, int pixel_format = HDR_PIXEL_FORMAT_YUV420_NV12); // set parameters,  create opencl kernels and alloc opencl buffers
  int hdr_lc_get_params(void *ctx, int* width, int* height, float* contrast_weight, float* exposure_weight, int* pixel_format);
  int hdr_lc_process(void *ctx, unsigned char **src_yuv, unsigned char *dst_yuv);
  int hdr_lc_release(void *ctx);
  const char *hdr_lc_version_code_get();
}
#endif
/* example
  void *ctx = hdr_lc_init(3);
  assert(ctx);
  hdr_lc_set_params(ctx, 1920, 1080, 0.5f, 0.5f, HDR_PIXEL_FORMAT_YUV420_NV12);
  ....
  foreach frame {
    unsigned char* src_yuv[3];
    src_yuv[0] = ...; // address of yuv data of input image 1
    assert(src_yuv[0]);
    src_yuv[1] = ...; // address of yuv data of input image 2
    assert(src_yuv[1]);
    src_yuv[2] = ...; // address of yuv data of input image 3
    assert(src_yuv[2]);

    unsigned char *dst_yuv = (unsigned char *)malloc(framesize); // address of yuv data of output image
    assert(dst_yuv);

    // start process
    hdr_lc_process(ctx, src_yuv, dst_yuv);

    free(dst_yuv);
  }
  hdr_lc_release(ctx);
*/