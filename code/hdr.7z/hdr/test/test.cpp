#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <float.h>
#include <fstream>
#include "hdr_lc.h"

#ifdef _WIN32
#include <windows.h>
#else
#include <time.h>
#include <unistd.h>
#endif
#ifdef _WIN32
#define uint64_t unsigned __int64
uint64_t performanceCounter() {
  LARGE_INTEGER result;
  QueryPerformanceCounter(&result);
  return result.QuadPart;
}

uint64_t performanceFrequency() {
  LARGE_INTEGER result;
  QueryPerformanceFrequency(&result);
  return result.QuadPart;
}
#else // _WIN32
uint64_t performanceCounter() {
  uint64_t result = 0;
  timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  result = (uint64_t)ts.tv_sec * 1000000000LL + (uint64_t)ts.tv_nsec;
  return result;
}

uint64_t performanceFrequency() {
  uint64_t result = 1;
  result = 1000000000LL;
  return result;
}
#endif // _WIN32
double getDurationSec(uint64_t prev) {
  return (double)(performanceCounter() - prev)/performanceFrequency();
}

int main(int argc, char* argv[]) {
  if (argc <= 10) {
    printf("usage: width height contrast_weight saturation_weight exposure_weight low_exposure_image_path\
           medium_exposure_image_path high_exposure_image_path ... result_image_path reference_image_path");
    return -1;
  }
  /* load parameters */
  int width = atoi(argv[1]);
  int height = atoi(argv[2]);
  int y_size = width * height; // NV12 NV21
  int uv_size = ((width + 1) >> 1) * ((height + 1) >> 1); // NV12 NV21
  float contrast_weight = atof(argv[3]);
  float saturation_weight = atof(argv[4]);
  float exposure_weight = atof(argv[5]);
  /* prepare host memory for image and result */
  const int N = argc - 8;
  unsigned char **images = (unsigned char **)malloc(N * sizeof(unsigned char*));
  assert(images);
  memset(images, 0, N * sizeof(unsigned char*));
  FILE *fp = NULL;
  for (int i = 0; i < N; i++){
    fp = fopen(argv[6 + i], "rb");
    assert(fp);
    fseek(fp, 0, SEEK_SET);
    images[i] = (unsigned char *)malloc((y_size + uv_size * 2) * sizeof(unsigned char));
    assert(images[i]);
    fread(images[i], sizeof(unsigned char), (y_size + uv_size * 2) * sizeof(unsigned char), fp);
    fclose(fp);
  }
  unsigned char *result = (unsigned char *)malloc((y_size + uv_size * 2) * sizeof(unsigned char));
  assert(result);
  void *ctx = hdr_lc_init(N);
  assert(ctx);
  hdr_lc_set_params(ctx, width, height, contrast_weight, exposure_weight, HDR_PIXEL_FORMAT_YUV420_NV12); // use NV12 as default
  /* execute exposure fusion algorithm and output fused result */
  printf("fusing %d images with width = %d height = %d contrast_weight = %lf saturation_weight = %lf exposure_weight = %lf\n",
    N, width, height, contrast_weight, saturation_weight, exposure_weight);
  const int TEST_TIMES = 10;
  double TEST_COSTS = 0.0;
  for (int i = 0; i < TEST_TIMES; i++) {
    printf("loop %d:\n", i);
    uint64_t now;
    now = performanceCounter();
    hdr_lc_process(ctx, images, result);
    double duration = getDurationSec(now);
    printf("time-cost of exposure fusion: %f s\n", duration);
    if (i > 0) {
      TEST_COSTS += duration;
    }
  }
  hdr_lc_release(ctx);
  printf("average time-cost of exposure fusion: %f s\n", TEST_COSTS / (TEST_TIMES - 1));
  fp = fopen(argv[argc - 2], "wb");
  assert(fp);
  fwrite(result, sizeof(unsigned char), (y_size + uv_size * 2), fp);
  fclose(fp);
  printf("output %s done.\n", argv[7 + N]);
#if 0
  /* generate reference result */
  fp = fopen(argv[argc - 1], "wb");
  assert(fp);
  fwrite (result, sizeof(unsigned char), y_size + uv_size * 2, fp);
  fclose(fp);
#else
  /* comparing with reference result to verify it */
  fp = fopen(argv[argc - 1], "rb");
  assert(fp);
  int threshold = 1;
  int matched_y = 0;
  uint32_t idx_y = 0;
  while (idx_y < y_size) {
    unsigned char ref_y;
    fread (&ref_y, sizeof(unsigned char), 1, fp);
    unsigned char y = result[idx_y];
    if (abs(y - ref_y) > threshold) {
      //printf("[%d]Y(%d) != Y(%d)\n", idx_y, y, ref_y);
    } else {
      matched_y++;
    }
    idx_y++;
  }
  int matched_u = 0;
  int matched_v = 0;
  uint32_t idx_uv = 0;
  while (idx_uv < uv_size) {
    // NV12 NV21
    unsigned char ref_u;
    fread (&ref_u, sizeof(unsigned char), 1, fp);
    unsigned char ref_v;
    fread (&ref_v, sizeof(unsigned char), 1, fp);
    unsigned char u = result[y_size + idx_uv * 2];
    unsigned char v = result[y_size + idx_uv * 2 + 1];
    if (abs(u - ref_u) > threshold) {
      //printf("[%d]U(%d) != U(%d)\n", idx_uv, u, ref_u);
    } else {
      matched_u++;
    }
    if (abs(v - ref_v) > threshold) {
      //printf("[%d]V(%d) != V(%d)\n", idx_uv, v, ref_v);
    } else {
      matched_v++;
    }
    idx_uv++;
  }
  fclose(fp);
  printf("Threshold = %d: %.3f%% (%d/%d) Y matched, %.3f%% (%d/%d) U matched, %.3f%% (%d/%d) V matched.\n", threshold, (float)matched_y / y_size * 100, matched_y, y_size, (float)matched_u / uv_size * 100, matched_u, uv_size, (float)matched_v / uv_size * 100, matched_v, uv_size);
#endif
  /* finalize */
  free(result);
  for (int i = 0; i < N; i++) {
    free(images[i]);
  }
  free(images);
#ifdef _WIN32
  getchar();
#endif
  return 0;
}

