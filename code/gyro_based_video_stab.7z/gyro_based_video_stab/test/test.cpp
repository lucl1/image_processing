#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <vector>
#include "video_stab_lc.h"

using namespace std;

#ifdef _WIN32
#include <windows.h>
#else
#include <time.h>
#include <unistd.h>
#endif
#ifdef _WIN32
#define uint64_t unsigned __int64
uint64_t performanceCounter() {
  LARGE_INTEGER result;
  QueryPerformanceCounter(&result);
  return result.QuadPart;
}

uint64_t performanceFrequency() {
  LARGE_INTEGER result;
  QueryPerformanceFrequency(&result);
  return result.QuadPart;
}
#else // _WIN32
uint64_t performanceCounter() {
  uint64_t result = 0;
  timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  result = (uint64_t)ts.tv_sec * 1000000000LL + (uint64_t)ts.tv_nsec;
  return result;
}

uint64_t performanceFrequency() {
  uint64_t result = 1;
  result = 1000000000LL;
  return result;
}
#endif // _WIN32
double getDurationSec(uint64_t prev) {
  return (double)(performanceCounter() - prev)/performanceFrequency();
}

int main(int argc, char* argv[])
{
  if (argc != 19) {
    printf("usage: gyro_file_path framestamp_file_path src_video_file_path dst_video_file_path reference_video_file_path\
           src_width src_height dst_width dst_height crop_width crop_height constaint_width constraint_height\
           camera_horizontal_view_angle camera_vertical_view_angle cam2gyro_rotation_x cam2gyro_rotation_y cam2gyro_rotation_z");
    return -1;
  }
  /* load parameters */
  int src_width = atoi(argv[6]);
  int src_height = atoi(argv[7]);
  int dst_width = atoi(argv[8]);
  int dst_height = atoi(argv[9]);
  int crop_width = atoi(argv[10]);
  int crop_height = atoi(argv[11]);
  int constraint_width = atoi(argv[12]);
  int constraint_height = atoi(argv[13]);
  /* load calibrated camera&gyro params */
  double camera_horizontal_view_angle = atof(argv[14]);
  double camera_vertical_view_angle = atof(argv[15]);
  double cam2gyro_rotation_x = atof(argv[16]);
  double cam2gyro_rotation_y = atof(argv[17]);
  double cam2gyro_rotation_z = atof(argv[18]);

  /* read gyro data */
  vector<double> gyro_ts;
  vector<double> gyro_xs;
  vector<double> gyro_ys;
  vector<double> gyro_zs;
  FILE *fp = fopen(argv[1], "r" );
  if (!fp) {
    printf("file %s not exists\n", argv[1]);
    return -1;
  }
  while (!feof(fp)){
    double gyro_t;
    double gyro_x;
    double gyro_y;
    double gyro_z;
    fscanf(fp, "%lf,%lf,%lf,%lf,\n", &gyro_t, &gyro_x, &gyro_y, &gyro_z);
    gyro_ts.push_back(gyro_t);
    gyro_xs.push_back(gyro_x);
    gyro_ys.push_back(gyro_y);
    gyro_zs.push_back(gyro_z);
  }
  fclose(fp);

  /* read start timestamp and readout timestamp of video frame */
  vector<double> video_sts; // video frame start timestamp
  vector<double> video_rts; // video frame readout timestamp
  fp = fopen(argv[2], "r" );
  if (!fp) {
    printf("file %s not exists\n", argv[2]);
    return -1;
  }
  while (!feof(fp)){
    double video_st;
    double video_rt;
    fscanf(fp, "%lf,%lf,\n", &video_st, &video_rt);
    video_sts.push_back(video_st);
    video_rts.push_back(video_rt);
  }
  fclose(fp);

  /* initialize pose estimator */
  void *cpx = video_stab_lc_pose_init();
  assert(cpx);
  /* set parameters to pose estimator */
  video_stab_lc_pose_set_params(cpx, false); // update pose by using sensor data manually
  video_stab_lc_pose_start(cpx); // call it before start recording video frames
  /* initialize video stabilizer */
  void *csx = video_stab_lc_stab_init();
  assert(csx);
  /* set parameters to video stabilizer */
  video_stab_lc_stab_set_params(csx,
    src_width,
    src_height,
    dst_width,
    dst_height,
    crop_width,
    crop_height,
    constraint_width,
    constraint_height,
    camera_horizontal_view_angle,
    camera_vertical_view_angle,
    cam2gyro_rotation_x,
    cam2gyro_rotation_y,
    cam2gyro_rotation_z,
    VIDEO_STAB_PIXEL_FORMAT_YUV420_NV12
    );
  video_stab_lc_pose_start(csx); // call it before start recording video frames
  /* update pose by using sensor data manually */
  int TEST_COUNTS_UPDATE_CAMERA_POSE = 0;
  double TEST_COSTS_UPDATE_CAMERA_POSE = 0.0;
  for (int i = 0; i < gyro_ts.size(); i++) {
    uint64_t now = performanceCounter();
    video_stab_lc_pose_process(cpx,
      gyro_ts[i],
      gyro_xs[i],
      gyro_ys[i],
      gyro_zs[i]
    );
    double duration = getDurationSec(now);
    TEST_COSTS_UPDATE_CAMERA_POSE += duration;
    TEST_COUNTS_UPDATE_CAMERA_POSE++;
  }
  /* process video frame */
  FILE *fp_src_video = fopen(argv[3], "rb" );
  if (!fp_src_video) {
    printf("file %s not exists\n", argv[3]);
    return -1;
  }
  FILE *fp_dst_video = fopen(argv[4], "wb" );
  if (!fp_dst_video) {
    printf("file %s not exists\n", argv[4]);
    return -1;
  }
#if 0
  /* generate reference result */
  FILE *fp_reference_video = fopen(argv[5], "wb");
#else
  /* comparing with reference result to verify it */
  FILE *fp_reference_video = fopen(argv[5], "rb");
#endif
  if (!fp_reference_video) {
    printf("file %s not exists\n", argv[5]);
    return -1;
  }
  int src_y_size = src_width * src_height; // NV12 NV21
  int src_uv_size = ((src_width + 1) >> 1) * ((src_height + 1) >> 1); // NV12 NV21
  int dst_y_size = dst_width * dst_height;
  int dst_uv_size = ((dst_width + 1) >> 1) * ((dst_height + 1) >> 1);
  unsigned char *src_yuv = new unsigned char[src_y_size + (src_uv_size << 1)];
  assert(src_yuv);
  unsigned char *dst_yuv = new unsigned char[dst_y_size + (dst_uv_size << 1)];
  assert(dst_yuv);
  double TEST_COSTS_PROCESS_VIDEO_FRAME = 0.0;
  int TEST_COUNTS_PROCESS_VIDEO_FRAME = 0;
  for (int i = 0; i < video_sts.size() && !feof(fp_src_video); i++) {
    fread(src_yuv, sizeof(unsigned char), src_y_size + (src_uv_size << 1), fp_src_video);
    uint64_t now = performanceCounter();
    video_stab_lc_stab_process(csx,
      cpx,
      video_sts[i],
      video_rts[i],
      src_yuv,
      dst_yuv
      );
    double duration = getDurationSec(now);
    TEST_COSTS_PROCESS_VIDEO_FRAME += duration;
    TEST_COUNTS_PROCESS_VIDEO_FRAME++;
    fwrite(dst_yuv, sizeof(unsigned char), dst_y_size + (dst_uv_size << 1), fp_dst_video);
#if 0
    fwrite(dst_yuv, sizeof(unsigned char), dst_y_size + (dst_uv_size << 1), fp_reference_video);
    printf("process frame %d/%d done: %lf s\n", i, video_sts.size(), duration);
#else
    int threshold = 1;
    int matched = 0;
    for (int j = 0; j < dst_y_size + (dst_uv_size << 1); j++) {
      unsigned char ref;
      fread(&ref, sizeof(unsigned char), 1, fp_reference_video);
      unsigned char data = dst_yuv[j];
      if (abs(ref - data) > threshold) {
        //printf("[%d] %d == %d ?\n", j, ref, data);
      } else {
        matched++;
      }
    }
    printf("process frame %d/%d done: %lf s %.3f%%(%d/%d) matched\n", i, video_sts.size(), duration, matched * 100.0 / (dst_y_size + (dst_uv_size << 1)), matched, dst_y_size + (dst_uv_size << 1));
#endif
  }
  printf("average time-cost of update camera pose: %f s\n", TEST_COSTS_UPDATE_CAMERA_POSE / TEST_COUNTS_UPDATE_CAMERA_POSE);
  printf("average time-cost of process video frame: %f s\n", TEST_COSTS_PROCESS_VIDEO_FRAME / TEST_COUNTS_PROCESS_VIDEO_FRAME);
  delete src_yuv;
  delete dst_yuv;
  fclose(fp_src_video);
  fclose(fp_dst_video);
  fclose(fp_reference_video);
  /* call them after stop recording video frames */
  video_stab_lc_stab_stop(csx);
  video_stab_lc_pose_stop(cpx);
  /* destroy the context and release its resources if never use it */
  video_stab_lc_stab_release(csx);
  video_stab_lc_pose_release(cpx);
  return 0;
}