#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <float.h>
#include <math.h>
#include "UKF.h"

enum DISPLAY {
  ALL = 0, 
  UPPER,
  LOWER
};

void display(double *C, int m, int n, DISPLAY t = ALL) {
  for (int j = 0; j < m; j++) {
    for (int i = 0; i < n; i++) {
      if (i < j && t == UPPER) continue;
      if (i > j && t == LOWER) continue;
      printf("%lf ", C[i + j * n]);
    }
    printf("\n");
  }
}

UKF *UKF_init(UKF_f_func f_func, UKF_h_func h_func, int state_size, int measure_size, double process_noise, double measure_noise, double kappa, double alpha, double beta) {
  if (state_size <= 0 || measure_size <= 0 || !f_func || !h_func) {
    printf("UKF_init: invalid parameters.\n");
    return NULL;
  }
  if (measure_size > 4) {
    printf("UKF_init: size 1, 2, 3 and 4 is only supported for measurement vector.\n");
    return NULL;
  }
  UKF *ctx = new UKF;
  assert(ctx);
  ctx->state = new double[state_size];
  assert(ctx->state);
  ctx->measure = new double[measure_size];
  assert(ctx->measure);
  ctx->state_covariance = new double[state_size * state_size];
  assert(ctx->state_covariance);
  ctx->measure_covariance = new double[measure_size * measure_size];
  assert(ctx->measure_covariance);
  ctx->cross_covariance = new double[measure_size * state_size];
  assert(ctx->cross_covariance);
  ctx->kalman_gain = new double[measure_size * state_size];
  assert(ctx->kalman_gain);
  ctx->sigma_points = new double[state_size * (2 * state_size + 1)];
  assert(ctx->sigma_points);
  ctx->f_sigma_points = new double[state_size * (2 * state_size + 1)];
  assert(ctx->f_sigma_points);
  ctx->h_sigma_points = new double[measure_size * (2 * state_size + 1)];
  assert(ctx->h_sigma_points);
  // initialize temperary vector & matrix
  ctx->A = new double[state_size * state_size];
  assert(ctx->A);
  ctx->B = new double[state_size];
  assert(ctx->B);
  ctx->C = new double[measure_size];
  assert(ctx->C);
  ctx->D = new double[measure_size * measure_size];
  assert(ctx->D);
  ctx->E = new double[measure_size * state_size];
  assert(ctx->E);
  //
  ctx->process_noise = process_noise;
  ctx->measure_noise = measure_noise;
  ctx->lambda = alpha * alpha * (state_size + kappa);
  ctx->mean_weight = (ctx->lambda - state_size) / ctx->lambda;
  ctx->covariance_weight = ctx->mean_weight + 1 - (alpha * alpha) + beta;
  ctx->both_weight = 0.5 / ctx->lambda;
  ctx->lambda = sqrt(ctx->lambda);
  ctx->f_func = f_func;
  ctx->h_func = h_func;
  ctx->state_size = state_size;
  ctx->measure_size = measure_size;
  return ctx;
}

void UKF_release(UKF *ctx) {
  if (!ctx) {
    printf("UKF_release: invalid parameters.\n");
    return;
  }
  if (ctx->state) {
    delete ctx->state;
  }
  if (ctx->measure) {
    delete ctx->measure;
  }
  if (ctx->state_covariance) {
    delete ctx->state_covariance;
  }
  if (ctx->measure_covariance) {
    delete ctx->measure_covariance;
  }
  if (ctx->cross_covariance) {
    delete ctx->cross_covariance;
  }
  if (ctx->kalman_gain) {
    delete ctx->kalman_gain;
  }
  if (ctx->sigma_points) {
    delete ctx->sigma_points;
  }
  if (ctx->f_sigma_points) {
    delete ctx->f_sigma_points;
  }
  if (ctx->h_sigma_points) {
    delete ctx->h_sigma_points;
  }
  if (ctx->A) {
    delete ctx->A;
  }
  if (ctx->B) {
    delete ctx->B;
  }
  if (ctx->C) {
    delete ctx->C;
  }
  if (ctx->D) {
    delete ctx->D;
  }
  if (ctx->E) {
    delete ctx->E;
  }
  delete ctx;
}

// refered to MAVRIC_Library util/matrix.cpp inverse
bool inverse(double *src, double *dst, int n) { // inverse a matrix, only size 1, 2, 3, 4 is supported
  if (n == 1) {
    double det = src[0];
    if (det == 0) {
      return false;
    }
    dst[0] = 1.0f / det;
  } else if (n == 2) {
    double det = src[0] * src[3] - src[1] * src[2];
    if (det == 0) {
      return false;
    }
    dst[0] =  src[3] / det;
    dst[1] = -src[1] / det;
    dst[2] = -src[2] / det;
    dst[3] =  src[0] / det;
  } else if (n == 3) {
    double det = src[0] * (src[4] * src[8] - src[5] * src[7]) - src[1] * (src[3] * src[8] - src[5] * src[6]) + src[2] * (src[3] * src[7] - src[4] * src[6]);
    if (det == 0) {
      return false;
    }
    dst[0] =  (src[4] * src[8] - src[5] * src[7]) / det;
    dst[1] = -(src[1] * src[8] - src[2] * src[7]) / det;
    dst[2] =  (src[1] * src[5] - src[2] * src[4]) / det;
    dst[3] = -(src[3] * src[8] - src[5] * src[6]) / det;
    dst[4] =  (src[0] * src[8] - src[2] * src[6]) / det;
    dst[5] = -(src[0] * src[5] - src[2] * src[3]) / det;
    dst[6] =  (src[3] * src[7] - src[4] * src[6]) / det;
    dst[7] = -(src[0] * src[7] - src[1] * src[6]) / det;
    dst[8] =  (src[0] * src[4] - src[1] * src[3]) / det;
  } else if (n == 4) {
    double a11 = src[0];
    double a12 = src[1];
    double a13 = src[2];
    double a14 = src[3];
    double a21 = src[4];
    double a22 = src[5];
    double a23 = src[6];
    double a24 = src[7];
    double a31 = src[8];
    double a32 = src[9];
    double a33 = src[10];
    double a34 = src[11];
    double a41 = src[12];
    double a42 = src[13];
    double a43 = src[14];
    double a44 = src[15];
    double det = a11*a22*a33*a44 + a11*a23*a34*a42 + a11*a24*a32*a43
      + a12*a21*a34*a43 + a12*a23*a31*a44 + a12*a24*a33*a41
      + a13*a21*a32*a44 + a13*a22*a34*a41 + a13*a24*a31*a42
      + a14*a21*a33*a42 + a14*a22*a31*a43 + a14*a23*a32*a41
      - a11*a22*a34*a43 - a11*a23*a32*a44 - a11*a24*a33*a42
      - a12*a21*a33*a44 - a12*a23*a34*a41 - a12*a24*a31*a43
      - a13*a21*a34*a42 - a13*a22*a31*a44 - a13*a24*a32*a41
      - a14*a21*a32*a43 - a14*a22*a33*a41 - a14*a23*a31*a42;
    if (det == 0) {
      return false;
    }
    dst[0] = (a22*a33*a44 + a23*a34*a42 + a24*a32*a43 - a22*a34*a43 - a23*a32*a44 - a24*a33*a42) /det;
    dst[1] = (a12*a34*a43 + a13*a32*a44 + a14*a33*a42 - a12*a33*a44 - a13*a34*a42 - a14*a32*a43) /det;
    dst[2] = (a12*a23*a44 + a13*a24*a42 + a14*a22*a43 - a12*a24*a43 - a13*a22*a44 - a14*a23*a42) /det;
    dst[3] = (a12*a24*a33 + a13*a22*a34 + a14*a23*a32 - a12*a23*a34 - a13*a24*a32 - a14*a22*a33) /det;
    dst[4] = (a21*a34*a43 + a23*a31*a44 + a24*a33*a41 - a21*a33*a44 - a23*a34*a41 - a24*a31*a43) /det;
    dst[5] = (a11*a33*a44 + a13*a34*a41 + a14*a31*a43 - a11*a34*a43 - a13*a31*a44 - a14*a33*a41) /det;
    dst[6] = (a11*a24*a43 + a13*a21*a44 + a14*a23*a41 - a11*a23*a44 - a13*a24*a41 - a14*a21*a43) /det;
    dst[7] = (a11*a23*a34 + a13*a24*a31 + a14*a21*a33 - a11*a24*a33 - a13*a21*a34 - a14*a23*a31) /det;
    dst[8] = (a21*a32*a44 + a22*a34*a41 + a24*a31*a42 - a21*a34*a42 - a22*a31*a44 - a24*a32*a41) /det;
    dst[9] = (a11*a34*a42 + a12*a31*a44 + a14*a32*a41 - a11*a32*a44 - a12*a34*a41 - a14*a31*a42) /det;
    dst[10] = (a11*a22*a44 + a12*a24*a41 + a14*a21*a42 - a11*a24*a42 - a12*a21*a44 - a14*a22*a41) /det;
    dst[11] = (a11*a24*a32 + a12*a21*a34 + a14*a22*a31 - a11*a22*a34 - a12*a24*a31 - a14*a21*a32) /det;
    dst[12] = (a21*a33*a42 + a22*a31*a43 + a23*a32*a41 - a21*a32*a43 - a22*a33*a41 - a23*a31*a42) /det;
    dst[13] = (a11*a32*a43 + a12*a33*a41 + a13*a31*a42 - a11*a33*a42 - a12*a31*a43 - a13*a32*a41) /det;
    dst[14] = (a11*a23*a42 + a12*a21*a43 + a13*a22*a41 - a11*a22*a43 - a12*a23*a41 - a13*a21*a42) /det;
    dst[15] = (a11*a22*a33 + a12*a23*a31 + a13*a21*a32 - a11*a23*a32 - a12*a21*a33 - a13*a22*a31) /det;
  } else {
    printf("inverse: only size 1, 2, 3, 4 is supported.\n");
    return false;
  }
  return true;
}

int UKF_step(UKF *ctx, double* state, double* measure, double *covariance, double dt) {
  if (!ctx || !state || !measure || !covariance) {
    printf("UKF_step: invalid parameters.\n");
    return -1;
  }

  //display(state, 1, ctx->state_size);
  //display(measure, 1, ctx->measure_size);
  //display(covariance, ctx->state_size, ctx->state_size);

  // cholesky & initialize sigma points around x
  for (int i = 0; i < 2 * ctx->state_size + 1; i++) {
    memcpy(ctx->sigma_points + i * ctx->state_size, state, sizeof(double) * ctx->state_size);
  }
  double *p = ctx->sigma_points + ctx->state_size; // from 1 to state_size
  double *q = p + ctx->state_size * ctx->state_size; // from state_size + 1 to state_size * 2
  for (int i = 0; i < ctx->state_size; i++) {
    for (int j = 0; j < i + 1; j++) {
      double s = 0;
      for (int k = 0; k < j; k++) {
        s += ctx->A[i * ctx->state_size + k] * ctx->A[j * ctx->state_size + k];
      }
      double v;
      if (i == j) {
        v = covariance[i * ctx->state_size + i] - s;
        if (v <= 0.0) {
          printf("cholesky: matrix not positive definite.\n");
          return -1;
        }
        v = sqrt(v);
      } else {
        v = (1.0 / ctx->A[j * ctx->state_size + j] * (covariance[i * ctx->state_size + j] - s));
      }
      ctx->A[i * ctx->state_size + j] = v;
      p[j * ctx->state_size + i] += v * ctx->lambda;
      q[j * ctx->state_size + i] -= v * ctx->lambda;
    }
  }
  //display(ctx->A, ctx->state_size, ctx->state_size, LOWER);
  //display(ctx->sigma_points, 2 * ctx->state_size + 1, ctx->state_size);

  // unscented transformation of process
  p = ctx->sigma_points;
  q = ctx->f_sigma_points;
  ctx->f_func(p, dt, q);
  for (int i = 0; i < ctx->state_size; i++) {
    ctx->state[i] = (*q++) * ctx->mean_weight;
  }
  p += ctx->state_size;
  for (int j = 0; j < ctx->state_size * 2; j++) {
    ctx->f_func(p, dt, q);
    for (int i = 0; i < ctx->state_size; i++) {
      ctx->state[i] += (*q++) * ctx->both_weight;
    }
    p += ctx->state_size;
  }
  //display(ctx->state, 1, ctx->state_size);
  //display(ctx->f_sigma_points, ctx->state_size * 2 + 1, ctx->state_size);

  // unscented transformation of measurments
  p = ctx->f_sigma_points;
  q = ctx->h_sigma_points;
  ctx->h_func(p, q);
  for (int i = 0; i < ctx->measure_size; i++) {
    ctx->measure[i] = (*q++) * ctx->mean_weight;
  }
  p += ctx->state_size;
  for (int j = 0; j < ctx->state_size * 2; j++) {
    ctx->h_func(p, q);
    for (int i = 0; i < ctx->measure_size; i++) {
      ctx->measure[i] += (*q++) * ctx->both_weight;
    }
    p += ctx->state_size;
  }
  //display(ctx->measure, 1, ctx->measure_size);
  //display(ctx->h_sigma_points, ctx->state_size * 2 + 1, ctx->measure_size);

  // calculate covariances
  p = ctx->f_sigma_points;
  q = ctx->h_sigma_points;
  for (int i = 0; i < ctx->state_size; i++) {
    ctx->B[i] = (*p++) - ctx->state[i];
  }
  for (int i = 0; i < ctx->measure_size; i++) {
    ctx->C[i] = (*q++) - ctx->measure[i];
  }
  for (int j = 0; j < ctx->state_size; j++) {
    for (int i = 0; i < ctx->state_size; i++) {
      ctx->state_covariance[j * ctx->state_size + i] = ctx->covariance_weight * ctx->B[i] * ctx->B[j];
      if (i == j) {
        ctx->state_covariance[j * ctx->state_size + i] += ctx->process_noise; // add process noise
      }
    }
  }
  for (int j = 0; j < ctx->measure_size; j++) {
    for (int i = 0; i < ctx->measure_size; i++) {
      ctx->measure_covariance[j * ctx->measure_size + i] = ctx->covariance_weight * ctx->C[i] * ctx->C[j];
      if (i == j) {
        ctx->measure_covariance[j * ctx->measure_size + i] += ctx->measure_noise; // add measure noise
      }
    }
  }
  for (int j = 0; j < ctx->state_size; j++) {
    for (int i = 0; i < ctx->measure_size; i++) {
      ctx->cross_covariance[j * ctx->measure_size + i] = ctx->covariance_weight * ctx->B[j] * ctx->C[i];
    }
  }
  for (int k = 0; k < ctx->state_size * 2; k++) {
    for (int i = 0; i < ctx->state_size; i++) {
      ctx->B[i] = (*p++) - ctx->state[i];
    }
    for (int i = 0; i < ctx->measure_size; i++) {
      ctx->C[i] = (*q++) - ctx->measure[i];
    }
    for (int j = 0; j < ctx->state_size; j++) {
      for (int i = 0; i < ctx->state_size; i++) {
        ctx->state_covariance[j * ctx->state_size + i] += ctx->both_weight * ctx->B[i] * ctx->B[j];
      }
    }
    for (int j = 0; j < ctx->measure_size; j++) {
      for (int i = 0; i < ctx->measure_size; i++) {
        ctx->measure_covariance[j * ctx->measure_size + i] += ctx->both_weight * ctx->C[i] * ctx->C[j];
      }
    }
    for (int j = 0; j < ctx->state_size; j++) {
      for (int i = 0; i < ctx->measure_size; i++) {
        ctx->cross_covariance[j * ctx->measure_size + i] += ctx->both_weight * ctx->B[j] * ctx->C[i];
      }
    }
  }
  //display(ctx->state, 1, ctx->state_size);
  //display(ctx->state_covariance, ctx->state_size, ctx->state_size);
  //display(ctx->measure_covariance, ctx->measure_size, ctx->measure_size);
  //display(ctx->cross_covariance, ctx->state_size, ctx->measure_size);

  // calculate kalman gain
  if (!inverse(ctx->measure_covariance, ctx->D, ctx->measure_size)) {
    return -1;
  }
  //display(ctx->D, ctx->measure_size, ctx->measure_size);
  for (int k = 0; k < ctx->state_size; k++) {
    for (int j = 0; j < ctx->measure_size; j++) {
      double s = 0.0;
      for (int i = 0; i < ctx->measure_size; i++) {
        s += ctx->cross_covariance[k * ctx->measure_size + i] * ctx->D[i * ctx->measure_size + j];
      }
      ctx->kalman_gain[k * ctx->measure_size + j] = s;
    }
  }
  //display(ctx->kalman_gain, ctx->state_size, ctx->measure_size);

  // update state
  for (int i = 0; i < ctx->measure_size; i++) {
    ctx->C[i] = measure[i] - ctx->measure[i];
  }
  for (int j = 0; j < ctx->state_size; j++) {
    double s = 0.0;
    for (int i = 0; i < ctx->measure_size; i++) {
      s += ctx->kalman_gain[j * ctx->measure_size + i] * ctx->C[i];
    }
    state[j] = ctx->state[j] + s;
  }
  //display(state, 1, ctx->state_size);

  // update covariance
  for (int k = 0; k < ctx->state_size; k++) {
    for (int j = 0; j < ctx->state_size; j++) {
      double s = 0.0;
      for (int i = 0; i < ctx->measure_size; i++) {
        s += ctx->kalman_gain[k * ctx->measure_size + i] * ctx->cross_covariance[j * ctx->measure_size + i];
      }
      covariance[k * ctx->state_size + j] = ctx->state_covariance[k * ctx->state_size + j] - s;
    }
  }
  //display(covariance, ctx->state_size, ctx->state_size);

  return 0;
}