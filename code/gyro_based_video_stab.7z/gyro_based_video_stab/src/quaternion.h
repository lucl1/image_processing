#ifndef __MATRIX__
#define __MATRIX__
typedef struct vec4 {
  double x;
  double y;
  double z;
  double w;
} vec4;

// padding with 4 elements
typedef struct mat3 {
  vec4 s0;
  vec4 s1;
  vec4 s2;
} mat3;

typedef double matrix;

double dot(const vec4* a, const vec4* b);
double dot(const float* a, const vec4* b);

void eye(vec4* c);
void eye(mat3* c);

void normalize(const vec4* a, vec4* c);

void conjugate(const vec4* a, vec4* c);

// refer to Ogre OgreQuaternion.cpp 'expm'
void expm(const vec4* a, vec4* c);

// refer to Ogre OgreQuaternion.cpp 'logm'
void logm(const vec4* a, vec4* c);

void inverse(const vec4* a, vec4* c);

void transpose(const mat3* a, mat3* c);

void multiply(const vec4* a, const vec4* b, vec4* c);
void multiply(const mat3* a, const mat3* b, mat3* c);
void multiply(const mat3* a, const mat3* b, float* c);

void divide(const vec4* a, const vec4* b, vec4* c);

void add(const vec4* a, const vec4* b, vec4* c);
void add(const mat3* a, const mat3* b, mat3* c);

void sub(const vec4* a, const vec4* b, vec4* c);
void sub(const mat3* a, const mat3* b, mat3* c);

void slerp(const vec4* a, const vec4* b, double t, vec4 *c);

// refer to crisp rotations.py 'integrate_gyro_quaternion'
void integrate(const vec4* a, double wx, double wy, double wz, double dt, vec4 *c);

// refer to kazmath mat3.c 'kmMat3FromRotationQuaternion'
void q2mat(const vec4* a, mat3* c);

// refer to matlab quat2angle 'xyz'
void q2rot(const vec4* a, double* wx, double* wy, double* wz);

void rot_x(double angle, mat3 *c);
void rot_y(double angle, mat3 *c);
void rot_z(double angle, mat3 *c);

void display(const vec4* c);
void display(const mat3* c);
#endif