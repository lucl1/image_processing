# GYRO-BASED VIDEO STAB library
It provides a library to stabilize video frames by using gyroscope data, it use gyroscape data to estimate
camera pose, and use the estimated camera pose to correct the video frames, its camera rotation smoothing
algorithm is based on http://users.ece.utexas.edu/~bevans/papers/2014/stabilization/index.html and suitable
for the gyrocopes with bias, and its image warping algorithm is based on inverse mapping and accelerated it
with OpenCL(but I think forward mapping based on OpenGL is the best choice for correcting the rolling shutter
  effect).
Note that: the library is device-independent, but the demo/example/test case is device-dependent, you should
calibrate camera & gyroscope if use it on other devices.

## Change lists
2017/01/09 created by MingHong

## Folder organization
-inc         # Header files of the declaration of exported interfaces of libvideo_stab_lc.
-src         # Source files of the implementation of libvideo_stab_lc.
  -android   # Android make file for building the libvideo_stab_lc.so for android platform.
-test        # An example to illustrate how to use the interfaces of libvideo_stab_lc.
  -android   # Android make file for building the example for android platform.
  -cases     # Test video & gyroscope data

## How to generate libvideo_stab_lc.so for android platform ?
  $ cd src/android
  $ ndk-build         # Compile & build, note that you need to prepare the android NDK enviroment
                      # and ensure it works well.
  $ cd libs & ls      # OK, you will see two new folders, and libvideo_stab_lc.so will be created.
    arm64-v8a         # For ARM 64bits
    armeabi-v7a       # For ARM 32bits
   
## How to execute the example(test case) on android platform ?
  $ cd test/android
  $ ndk-build
  $ run.bat           # Window is only supported as host, and you should plugin you android device to the
                      # host via USB before run the example(test case).

                      # After the execution is finished, you will see an new YUV file named 'dst.yuv'
                      # is generated under the folder '/test/cases/manifold_motion_smoothing', then use YUVViewer to check it.

## How to use the interfaces of libvideo_stab_lc ?
  The header file 'inc/video_stab_lc.h' gives the details about the interfaces of libvideo_stab_lc,
  and you also can learn it at 'test/test.cpp'.