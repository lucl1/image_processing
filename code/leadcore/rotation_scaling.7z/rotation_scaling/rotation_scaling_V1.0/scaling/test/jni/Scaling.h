#include<stdio.h>
#include<stdlib.h>
#include <CL/cl.h>
#include<string.h>
#include<sys/types.h>
#include <fstream> 
#include <sys/time.h>
#include<cmath>
#include <sys/types.h> 
#include <iostream>
using namespace std;

#ifdef MAC
#include<OpenCL/cl.h>
#else
#include<CL/cl.h>
#endif

#define KERNEL_FUNC_P "Scaling_P"             //kernel函数
#define KERNEL_FUNC_SP  "Scaling_SP"

#define P_420 1                               //设置图像格式
#define SP_420 2

//查错函数
void CheckError(cl_int err)

{

    if(err != CL_SUCCESS)

    {

        switch( err )

        {

            case CL_DEVICE_NOT_FOUND: 
                 cout<<"CL_DEVICE_NOT_FOUND"<<endl; 
                 break;
			
			case CL_DEVICE_NOT_AVAILABLE: 
                 cout<<"CL_DEVICE_NOT_AVAILABLE"<<endl; 
                 break;
			
			case CL_COMPILER_NOT_AVAILABLE: 
                 cout<<"CL_COMPILER_NOT_AVAILABLE"<<endl; 
                 break;
			
			case CL_MEM_OBJECT_ALLOCATION_FAILURE: 
                 cout<<"CL_MEM_OBJECT_ALLOCATION_FAILURE"<<endl; 
                 break;
			
			case CL_OUT_OF_RESOURCES: 
                 cout<<"CL_OUT_OF_RESOURCES"<<endl; 
                 break;
			
			case CL_OUT_OF_HOST_MEMORY: 
                 cout<<"CL_OUT_OF_HOST_MEMORY"<<endl; 
                 break;
			
			case CL_PROFILING_INFO_NOT_AVAILABLE: 
                 cout<<"CL_PROFILING_INFO_NOT_AVAILABLE"<<endl; 
                 break;
			
			case CL_MEM_COPY_OVERLAP: 
                 cout<<"CL_MEM_COPY_OVERLAP"<<endl; 
                 break;
			
			case CL_IMAGE_FORMAT_MISMATCH: 
                 cout<<"CL_IMAGE_FORMAT_MISMATCH"<<endl; 
                 break;
			
			case CL_IMAGE_FORMAT_NOT_SUPPORTED: 
                 cout<<"CL_IMAGE_FORMAT_NOT_SUPPORTED"<<endl; 
                 break;
			
			case CL_BUILD_PROGRAM_FAILURE: 
                 cout<<"CL_BUILD_PROGRAM_FAILURE"<<endl; 
                 break;
			
			case CL_MAP_FAILURE: 
                 cout<<"CL_MAP_FAILURE"<<endl; 
                 break;
			
			case CL_MISALIGNED_SUB_BUFFER_OFFSET: 
                 cout<<"CL_MISALIGNED_SUB_BUFFER_OFFSET"<<endl; 
                 break;
			
			case CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST: 
                 cout<<"CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST"<<endl; 
                 break;
			
			case CL_INVALID_VALUE: 
                 cout<<"CL_INVALID_VALUE"<<endl; 
                 break;
			
			case CL_INVALID_DEVICE_TYPE: 
                 cout<<"CL_INVALID_DEVICE_TYPE"<<endl; 
                 break;
			
			case CL_INVALID_PLATFORM: 
                 cout<<"CL_INVALID_PLATFORM"<<endl; 
                 break;
			
			case CL_INVALID_DEVICE: 
                 cout<<"CL_INVALID_DEVICE"<<endl; 
                 break;
			
			case CL_INVALID_CONTEXT: 
                 cout<<"CL_INVALID_CONTEXT"<<endl; 
                 break;
			
			case CL_INVALID_QUEUE_PROPERTIES: 
                 cout<<"CL_INVALID_QUEUE_PROPERTIES"<<endl; 
                 break;
			
			case CL_INVALID_COMMAND_QUEUE: 
                 cout<<"CL_INVALID_COMMAND_QUEUE"<<endl; 
                 break;
			
			case CL_INVALID_HOST_PTR: 
                 cout<<"CL_INVALID_HOST_PTR"<<endl; 
                 break;
			
			case CL_INVALID_MEM_OBJECT: 
                 cout<<"CL_INVALID_MEM_OBJECT"<<endl; 
                 break;
			
			case CL_INVALID_IMAGE_FORMAT_DESCRIPTOR: 
                 cout<<"CL_INVALID_IMAGE_FORMAT_DESCRIPTOR"<<endl; 
                 break;
			
			case CL_INVALID_IMAGE_SIZE: 
                 cout<<"CL_INVALID_IMAGE_SIZE"<<endl; 
                 break;
			
			case CL_INVALID_SAMPLER: 
                 cout<<"CL_INVALID_SAMPLER"<<endl; 
                 break;
			
			case CL_INVALID_BINARY: 
                 cout<<"CL_INVALID_BINARY"<<endl; 
                 break;
			
			case CL_INVALID_BUILD_OPTIONS: 
                 cout<<"CL_INVALID_BUILD_OPTIONS"<<endl; 
                 break;
			
			case CL_INVALID_PROGRAM: 
                 cout<<"CL_INVALID_PROGRAM"<<endl; 
                 break;
			
			case CL_INVALID_PROGRAM_EXECUTABLE:
                 cout<<"CL_INVALID_PROGRAM_EXECUTABLE"<<endl; 
                 break;
			
			case CL_INVALID_KERNEL_NAME:
                 cout<<"CL_INVALID_KERNEL_NAME"<<endl;
                 break;
			
			case CL_INVALID_KERNEL_DEFINITION:
                 cout<<"CL_INVALID_KERNEL_DEFINITION"<<endl; 
                 break;
			
			case CL_INVALID_KERNEL: 
                 cout<<"CL_INVALID_KERNEL"<<endl; 
                 break;
			
			case CL_INVALID_ARG_INDEX:
                 cout<<"CL_INVALID_ARG_INDEX"<<endl; 
                 break;
			
			case CL_INVALID_ARG_VALUE:
                 cout<<"CL_INVALID_ARG_VALUE"<<endl; 
                 break;
			
			case CL_INVALID_ARG_SIZE: 
                 cout<<"CL_INVALID_ARG_SIZE"<<endl; 
                 break;
			
			case CL_INVALID_KERNEL_ARGS: 
                 cout<<"CL_INVALID_KERNEL_ARGS"<<endl; 
                 break;
			
			case CL_INVALID_WORK_DIMENSION: 
                 cout<<"CL_INVALID_WORK_DIMENSION"<<endl; 
                 break;
			
			case CL_INVALID_WORK_GROUP_SIZE: 
                 cout<<"CL_INVALID_WORK_GROUP_SIZE"<<endl; 
                 break;
			
			case CL_INVALID_WORK_ITEM_SIZE:
                 cout<<"CL_INVALID_WORK_ITEM_SIZE"<<endl; 
                 break;
			
			case CL_INVALID_GLOBAL_OFFSET: 
                 cout<<"CL_INVALID_GLOBAL_OFFSET"<<endl; 
                 break;
			
			case CL_INVALID_EVENT_WAIT_LIST: 
                 cout<<"CL_INVALID_EVENT_WAIT_LIST"<<endl; 
                 break;
			
			case CL_INVALID_EVENT:  
                 cout<<"CL_INVALID_EVENT"<<endl; 
                 break;
			
			case CL_INVALID_OPERATION:
                 cout<<"CL_INVALID_OPERATION"<<endl; 
                 break;
			
			case CL_INVALID_GL_OBJECT:
                 cout<<"CL_INVALID_GL_OBJECT"<<endl; 
                 break;
			
			case CL_INVALID_BUFFER_SIZE:
                 cout<<"CL_INVALID_BUFFER_SIZE"<<endl; 
                 break;
			
			case CL_INVALID_MIP_LEVEL:
                 cout<<"CL_INVALID_MIP_LEVEL"<<endl; 
                 break;
			
			case CL_INVALID_GLOBAL_WORK_SIZE:
                 cout<<"CL_INVALID_GLOBAL_WORK_SIZE"<<endl; 
                 break;
			
			case CL_INVALID_PROPERTY:
                 cout<<"CL_INVALID_PROPERTY"<<endl; 
                 break;

            default:
                 cout<<"Unknown error code: %d"<<(int)err<<endl; 
                 break;

        }

        getchar();

        exit( err );

    }

}

class Scaling
{
	
	private:
	
		//归一化变量
	    float widthNormalizationFactor, heightNormalizationFactor;
	
	    void *vab;
		
		//设置输入输出图像对象格式
        cl_image_format DataForm, DataFormUV;
		
	public:
	
		Scaling(int Width, int Height, int newWidth, int newHeight);
		
		~Scaling();
		
		//缩放函数
		void Processing_Scaling(unsigned char * InData, unsigned char * OutData, int Width, int Height, int newWidth, int newHeight, int Format);
		
};
