#include"Scaling.h"

//kernel����
const char* OpenCLSource[] = {
"const sampler_t Sampler_Scaling = CLK_NORMALIZED_COORDS_TRUE | CLK_ADDRESS_CLAMP_TO_EDGE | CLK_FILTER_LINEAR;",
"__kernel void Scaling_P(__read_only image2d_t SourceImageY, __read_only image2d_t SourceImageU, __read_only image2d_t SourceImageV, __write_only image2d_t DestinationImageY, __write_only image2d_t DestinationImageU, __write_only image2d_t DestinationImageV, const float widthNormalizationFactor, const float heightNormalizationFactor)",
"{",
"const int I = get_global_id(0);",
"const int J = get_global_id(1);",
"int2 CoordinateUV = (int2)(I, J);",
"float2 NormalizedCoordinateUV = convert_float2(CoordinateUV) * (float2)(widthNormalizationFactor * 2, heightNormalizationFactor * 2);",
"float4 ColourU = read_imagef(SourceImageU, Sampler_Scaling, NormalizedCoordinateUV);",
"write_imagef(DestinationImageU, CoordinateUV, ColourU);",
"float4 ColourV = read_imagef(SourceImageV, Sampler_Scaling, NormalizedCoordinateUV);",
"write_imagef(DestinationImageV, CoordinateUV, ColourV);",
"int2 CoordinateY1 = (int2)(I << 1, J << 1);",
"int2 CoordinateY2 = (int2)(CoordinateY1.s0, CoordinateY1.s1 + 1);",
"int2 CoordinateY3 = (int2)(CoordinateY1.s0 + 1, CoordinateY1.s1);",
"int2 CoordinateY4 = (int2)(CoordinateY1.s0 + 1, CoordinateY1.s1 + 1);",
"float2 NormalizedCoordinateY1 = convert_float2(CoordinateY1) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY2 = convert_float2(CoordinateY2) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY3 = convert_float2(CoordinateY3) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY4 = convert_float2(CoordinateY4) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float4 ColourY1 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY1);",
"write_imagef(DestinationImageY, CoordinateY1, ColourY1);float4 ColourY2 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY2);",
"write_imagef(DestinationImageY, CoordinateY2, ColourY2);float4 ColourY3 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY3);",
"write_imagef(DestinationImageY, CoordinateY3, ColourY3);float4 ColourY4 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY4);",
"write_imagef(DestinationImageY, CoordinateY4, ColourY4);",
"}",
"__kernel void Scaling_SP(__read_only image2d_t SourceImageY, __read_only image2d_t SourceImageUV, __write_only image2d_t DestinationImageY, __write_only image2d_t DestinationImageUV, const float widthNormalizationFactor, const float heightNormalizationFactor)",
"{",
"const int I = get_global_id(0);",
"const int J = get_global_id(1);",
"int2 CoordinateUV = (int2)(I, J);",
"float2 NormalizedCoordinateUV = convert_float2(CoordinateUV) * (float2)(widthNormalizationFactor * 2, heightNormalizationFactor * 2);",
"float4 ColourUV = read_imagef(SourceImageUV, Sampler_Scaling, NormalizedCoordinateUV);",
"write_imagef(DestinationImageUV, CoordinateUV, ColourUV);",
"int2 CoordinateY1 = (int2)(I << 1, J << 1);",
"int2 CoordinateY2 = (int2)(CoordinateY1.s0, CoordinateY1.s1 + 1);",
"int2 CoordinateY3 = (int2)(CoordinateY1.s0 + 1, CoordinateY1.s1);",
"int2 CoordinateY4 = (int2)(CoordinateY1.s0 + 1, CoordinateY1.s1 + 1);",
"float2 NormalizedCoordinateY1 = convert_float2(CoordinateY1) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY2 = convert_float2(CoordinateY2) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY3 = convert_float2(CoordinateY3) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY4 = convert_float2(CoordinateY4) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float4 ColourY1 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY1);",
"write_imagef(DestinationImageY, CoordinateY1, ColourY1);",
"float4 ColourY2 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY2);",
"write_imagef(DestinationImageY, CoordinateY2, ColourY2);",
"float4 ColourY3 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY3);",
"write_imagef(DestinationImageY, CoordinateY3, ColourY3);",
"float4 ColourY4 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY4);",
"write_imagef(DestinationImageY, CoordinateY4, ColourY4);",
"}"
};

struct Variable
{
	//ƽ̨����
	cl_platform_id platform;
	
	//�豸����
	cl_device_id device;
	
	//����������
	cl_context context;
	
	//�����������
	cl_program program;
	
	//��������kernel����
	cl_kernel kernel_scaling_P, kernel_scaling_SP;
	
	//�����������
	cl_command_queue queue;
	
	//�����������ͼ�����
	cl_mem InImageY, InImageU, InImageV, InImageUV;
	cl_mem OutScalingImageY, OutScalingImageU, OutScalingImageV, OutScalingImageUV;
	
};

/**********************************************************************
�������ܣ� �˺����ǹ��캯������Ҫ������ر����ĳ�ʼ��
���룺     ��
�����     ��
***********************************************************************/
Scaling::Scaling(int Width, int Height, int newWidth, int newHeight)
{
	
	widthNormalizationFactor = 1.0f / newWidth;
    heightNormalizationFactor = 1.0f / newHeight;
	
	vab = (Variable *)malloc(sizeof(Variable));
	
	//�����־λ
	cl_int status;
	
	//��ѯ����ƽ̨
	status = clGetPlatformIDs(1, &(((Variable *)vab)->platform), NULL);
	CheckError(status);
	 
	//��ѯ�����豸
    status = clGetDeviceIDs((((Variable *)vab)->platform), CL_DEVICE_TYPE_GPU, 1, &(((Variable *)vab)->device), NULL);
	CheckError(status);
	
	(((Variable *)vab)->context) = clCreateContext(NULL, 1, &(((Variable *)vab)->device), NULL, NULL, &status);
	CheckError(status);
	
	(((Variable *)vab)->program) = clCreateProgramWithSource((((Variable *)vab)->context), 50, OpenCLSource, NULL,&status);
    CheckError(status);
	
	//����������
	const char options[] = " -cl-fast-relaxed-math ";
	status = clBuildProgram((((Variable *)vab)->program),1,&(((Variable *)vab)->device),options,NULL,NULL);
	if(status < 0)
	{
		
		size_t log_size;
		status = clGetProgramBuildInfo((((Variable *)vab)->program), (((Variable *)vab)->device), CL_PROGRAM_BUILD_LOG, 0, NULL, &log_size);
		CheckError(status);
		char *program_log = (char*)malloc(log_size + 1);
		status = clGetProgramBuildInfo((((Variable *)vab)->program), (((Variable *)vab)->device), CL_PROGRAM_BUILD_LOG, log_size + 1, program_log, NULL);
		CheckError(status);
		cout<<"ProgramBuildInfo:"<<endl<<program_log<<endl;
		
	}
	
	(((Variable *)vab)->kernel_scaling_P) = clCreateKernel((((Variable *)vab)->program), KERNEL_FUNC_P, &status);
	CheckError(status);
	(((Variable *)vab)->kernel_scaling_SP) = clCreateKernel((((Variable *)vab)->program), KERNEL_FUNC_SP ,&status);
	CheckError(status);
	
	(((Variable *)vab)->queue) = clCreateCommandQueue((((Variable *)vab)->context),(((Variable *)vab)->device),CL_QUEUE_PROFILING_ENABLE,&status);
	CheckError(status);
	
	//ͼ������ʽ
	DataForm.image_channel_data_type = CL_UNORM_INT8;
    DataForm.image_channel_order = CL_R;
	DataFormUV.image_channel_data_type = CL_UNORM_INT8;
    DataFormUV.image_channel_order = CL_RG;
	
	//��������ͼ�����
	(((Variable *)vab)->InImageY) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_READ_ONLY|CL_MEM_ALLOC_HOST_PTR, &DataForm, Width, Height, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->InImageU) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_READ_ONLY|CL_MEM_ALLOC_HOST_PTR, &DataForm, Width / 2, Height / 2, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->InImageV) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_READ_ONLY|CL_MEM_ALLOC_HOST_PTR, &DataForm, Width / 2, Height / 2, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->InImageUV) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_READ_ONLY|CL_MEM_ALLOC_HOST_PTR, &DataFormUV, Width / 2, Height / 2, 0, NULL, &status);
	CheckError(status);
	
	//����������ת������ͼ�����
	(((Variable *)vab)->OutScalingImageY) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_WRITE_ONLY, &DataForm, newWidth, newHeight, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->OutScalingImageU) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_WRITE_ONLY, &DataForm, newWidth / 2, newHeight / 2, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->OutScalingImageV) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_WRITE_ONLY, &DataForm, newWidth / 2, newHeight / 2, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->OutScalingImageUV) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_WRITE_ONLY, &DataFormUV, newWidth / 2, newHeight / 2, 0, NULL, &status);
	CheckError(status);
	
	clFlush((((Variable *)vab)->queue));
}

/*************************************************************************************************
�������ܣ� �˺���ִ�е���ͼ�������
���룺     ���߸�������������ηֱ�������ͼ���Buffer�����ͼ���Buffer������ͼ����͸ߣ����ͼ��
           ���͸ߣ�����ͼ��ĸ�ʽ������ΪSP_420ʱ��420SP��ʽ������ΪP_420ʱ��420P��ʽ����
�����     ��
**************************************************************************************************/
void Scaling::Processing_Scaling(unsigned char * InData, unsigned char * OutData, int Width,int Height, int newWidth,int newHeight, int Format)
{
    
	//�����־λ
	cl_int status;
	
	//����ͼ���������д���������
	const size_t Origin[3] = {0,0,0};
	const size_t RegionY[3] = {Width, Height, 1};
	const size_t RegionUV[3] = {Width / 2, Height / 2, 1};
	
	//���ͼ��������ݶ�ȡ��������
	const size_t newRegionY[3] = {newWidth, newHeight, 1};
	const size_t newRegionUV[3] = {newWidth / 2, newHeight / 2, 1};
	
	switch(Format)
	{
		
		case P_420:
		
		    {
		    
			    //���������ݶ��뵽����ͼ����
				size_t rowPitch;
				unsigned char *InDataY = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->InImageY), CL_TRUE, CL_MAP_WRITE, Origin, RegionY, &rowPitch, NULL, 0, NULL, NULL, &status);
	            CheckError(status);
				memcpy(InDataY, InData, Width * Height);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->InImageY), InDataY, 0, NULL, NULL);
	            CheckError(status);
				
				unsigned char *InDataU = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->InImageU), CL_TRUE, CL_MAP_WRITE, Origin, RegionUV, &rowPitch, NULL, 0, NULL, NULL, &status);
				memcpy(InDataU, InData + Width * Height, Width * Height / 4);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->InImageU), InDataU, 0, NULL, NULL);
	            CheckError(status);
				
				unsigned char *InDataV = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->InImageV), CL_TRUE, CL_MAP_WRITE, Origin, RegionUV, &rowPitch, NULL, 0, NULL, NULL, &status);
	            memcpy(InDataV, InData + Width * Height * 5 / 4, Width * Height / 4);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->InImageV), InDataV, 0, NULL, NULL);
	            CheckError(status);
				
	        
			
			
	            //����kernel_P����
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 0, sizeof(cl_mem), &(((Variable *)vab)->InImageY));
                CheckError(status);
                status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 1, sizeof(cl_mem), &(((Variable *)vab)->InImageU));
	            CheckError(status);
			    status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 2, sizeof(cl_mem), &(((Variable *)vab)->InImageV));
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 3, sizeof(cl_mem), &(((Variable *)vab)->OutScalingImageY));
	            CheckError(status);
                status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 4, sizeof(cl_mem), &(((Variable *)vab)->OutScalingImageU));
	            CheckError(status);
			    status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 5, sizeof(cl_mem), &(((Variable *)vab)->OutScalingImageV));
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 6, sizeof(cl_float), &widthNormalizationFactor);
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 7, sizeof(cl_float), &heightNormalizationFactor);
	            CheckError(status);
	        
	            //��������ά��
                const int workDimensions_P = 2;
                size_t globalWorkSize_P[workDimensions_P] = {newWidth / 2, newHeight / 2};
			    
                clEnqueueNDRangeKernel((((Variable *)vab)->queue), (((Variable *)vab)->kernel_scaling_P), workDimensions_P, NULL, globalWorkSize_P, NULL, 0, NULL, NULL);
	            
			    status = clFinish((((Variable *)vab)->queue));
	            CheckError(status);
			   
			    //�����ͼ���е�����д�����Buffer��
				unsigned char *OutDataY = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageY), CL_TRUE, CL_MAP_READ, Origin, newRegionY, &rowPitch, NULL, 0, NULL, NULL, &status);
	            CheckError(status);
				memcpy(OutData, OutDataY, newWidth * newHeight);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageY), OutDataY, 0, NULL, NULL);
	            CheckError(status);
				
				unsigned char *OutDataU = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageU), CL_TRUE, CL_MAP_READ, Origin, newRegionUV, &rowPitch, NULL, 0, NULL, NULL, &status);
	            CheckError(status);
				memcpy(OutData + newWidth * newHeight, OutDataU, newWidth * newHeight / 4);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageU), OutDataU, 0, NULL, NULL);
	            CheckError(status);
				
				unsigned char *OutDataV = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageV), CL_TRUE, CL_MAP_READ, Origin, newRegionUV, &rowPitch, NULL, 0, NULL, NULL, &status);
	            CheckError(status);
				memcpy(OutData + newWidth * newHeight * 5 / 4, OutDataV, newWidth * newHeight / 4);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageV), OutDataV, 0, NULL, NULL);
	            CheckError(status);
				
		    }
		    
		    break;
		
		case SP_420:
		
		    {
		        
				//���������ݶ��뵽����ͼ����
				size_t rowPitch;
				unsigned char *InDataY = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->InImageY), CL_TRUE, CL_MAP_WRITE, Origin, RegionY, &rowPitch, NULL, 0, NULL, NULL, &status);
	            CheckError(status);
				memcpy(InDataY, InData, Width * Height);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->InImageY), InDataY, 0, NULL, NULL);
	            CheckError(status);
				
				unsigned char *InDataUV = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->InImageUV), CL_TRUE, CL_MAP_WRITE, Origin, RegionUV, &rowPitch, NULL, 0, NULL, NULL, &status);
				memcpy(InDataUV, InData + Width * Height, Width * Height / 2);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->InImageUV), InDataUV, 0, NULL, NULL);
	            CheckError(status);
			
			    //����kernel_P����
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 0, sizeof(cl_mem), &(((Variable *)vab)->InImageY));
                CheckError(status);
                status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 1, sizeof(cl_mem), &(((Variable *)vab)->InImageUV));
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 2, sizeof(cl_mem), &(((Variable *)vab)->OutScalingImageY));
	            CheckError(status);
                status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 3, sizeof(cl_mem), &(((Variable *)vab)->OutScalingImageUV));
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 4, sizeof(cl_float), &widthNormalizationFactor);
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 5, sizeof(cl_float), &heightNormalizationFactor);
	            CheckError(status);
	        
	            //��������ά��
                const int workDimensions_SP = 2;
                size_t globalWorkSize_SP[workDimensions_SP] = {newWidth / 2, newHeight / 2};
	
	            //ִ��kernel_SP
                clEnqueueNDRangeKernel((((Variable *)vab)->queue), (((Variable *)vab)->kernel_scaling_SP), workDimensions_SP, NULL, globalWorkSize_SP, NULL, 0, NULL, NULL);
	
                status = clFinish((((Variable *)vab)->queue));
	            CheckError(status);
	        
	            //�����ͼ���е�����д�����Buffer��
				unsigned char *OutDataY = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageY), CL_TRUE, CL_MAP_READ, Origin, newRegionY, &rowPitch, NULL, 0, NULL, NULL, &status);
	            CheckError(status);
				memcpy(OutData, OutDataY, newWidth * newHeight);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageY), OutDataY, 0, NULL, NULL);
	            CheckError(status);
				
				unsigned char *OutDataUV = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageUV), CL_TRUE, CL_MAP_READ, Origin, newRegionUV, &rowPitch, NULL, 0, NULL, NULL, &status);
	            CheckError(status);
				memcpy(OutData + newWidth * newHeight, OutDataUV, newWidth * newHeight / 2);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageUV), OutDataUV, 0, NULL, NULL);
	            CheckError(status);
			
		    }
		
	        break;
		
		default:
		
		    {
			
			    cout<<"Invalid Image Format."<<endl;
			
		    }
			
		    break;
		
	}
    
}

/***********************************************
�������ܣ� �˺�����������������Ҫ�������ͷ���Դ
���룺     ��
�����     ��
************************************************/
Scaling ::~Scaling()
{
	
	//�ͷ�ͼ�����
    clReleaseMemObject((((Variable *)vab)->InImageY));
    clReleaseMemObject((((Variable *)vab)->InImageU));
	clReleaseMemObject((((Variable *)vab)->InImageV));
	clReleaseMemObject((((Variable *)vab)->InImageUV));
	clReleaseMemObject((((Variable *)vab)->OutScalingImageY));
    clReleaseMemObject((((Variable *)vab)->OutScalingImageU));
	clReleaseMemObject((((Variable *)vab)->OutScalingImageV));
	clReleaseMemObject((((Variable *)vab)->OutScalingImageUV));
	
	//�ͷ�OpenCL ��Դ
    clReleaseProgram((((Variable *)vab)->program));
    clReleaseCommandQueue((((Variable *)vab)->queue));
    clReleaseContext((((Variable *)vab)->context));
    clReleaseKernel((((Variable *)vab)->kernel_scaling_P));
	clReleaseKernel((((Variable *)vab)->kernel_scaling_P));
	
}