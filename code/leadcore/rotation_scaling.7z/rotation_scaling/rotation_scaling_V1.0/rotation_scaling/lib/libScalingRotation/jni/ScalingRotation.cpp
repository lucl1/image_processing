#include"ScalingRotation.h"

//kernel����
const char* OpenCLSource[] = {
"const sampler_t Sampler_Scaling = CLK_NORMALIZED_COORDS_TRUE | CLK_ADDRESS_CLAMP_TO_EDGE | CLK_FILTER_LINEAR;",
"__kernel void Scaling_P(__read_only image2d_t SourceImageY, __read_only image2d_t SourceImageU, __read_only image2d_t SourceImageV, __write_only image2d_t DestinationImageY, __write_only image2d_t DestinationImageU, __write_only image2d_t DestinationImageV, const float widthNormalizationFactor, const float heightNormalizationFactor)",
"{",
"const int I = get_global_id(0);",
"const int J = get_global_id(1);",
"int2 CoordinateUV = (int2)(I, J);",
"float2 NormalizedCoordinateUV = convert_float2(CoordinateUV) * (float2)(widthNormalizationFactor * 2, heightNormalizationFactor * 2);",
"float4 ColourU = read_imagef(SourceImageU, Sampler_Scaling, NormalizedCoordinateUV);",
"write_imagef(DestinationImageU, CoordinateUV, ColourU);",
"float4 ColourV = read_imagef(SourceImageV, Sampler_Scaling, NormalizedCoordinateUV);",
"write_imagef(DestinationImageV, CoordinateUV, ColourV);",
"int2 CoordinateY1 = (int2)(I << 1, J << 1);",
"int2 CoordinateY2 = (int2)(CoordinateY1.s0, CoordinateY1.s1 + 1);",
"int2 CoordinateY3 = (int2)(CoordinateY1.s0 + 1, CoordinateY1.s1);",
"int2 CoordinateY4 = (int2)(CoordinateY1.s0 + 1, CoordinateY1.s1 + 1);",
"float2 NormalizedCoordinateY1 = convert_float2(CoordinateY1) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY2 = convert_float2(CoordinateY2) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY3 = convert_float2(CoordinateY3) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY4 = convert_float2(CoordinateY4) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float4 ColourY1 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY1);",
"write_imagef(DestinationImageY, CoordinateY1, ColourY1);float4 ColourY2 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY2);",
"write_imagef(DestinationImageY, CoordinateY2, ColourY2);float4 ColourY3 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY3);",
"write_imagef(DestinationImageY, CoordinateY3, ColourY3);float4 ColourY4 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY4);",
"write_imagef(DestinationImageY, CoordinateY4, ColourY4);",
"}",
"__kernel void Scaling_SP(__read_only image2d_t SourceImageY, __read_only image2d_t SourceImageUV, __write_only image2d_t DestinationImageY, __write_only image2d_t DestinationImageUV, const float widthNormalizationFactor, const float heightNormalizationFactor)",
"{",
"const int I = get_global_id(0);",
"const int J = get_global_id(1);",
"int2 CoordinateUV = (int2)(I, J);",
"float2 NormalizedCoordinateUV = convert_float2(CoordinateUV) * (float2)(widthNormalizationFactor * 2, heightNormalizationFactor * 2);",
"float4 ColourUV = read_imagef(SourceImageUV, Sampler_Scaling, NormalizedCoordinateUV);",
"write_imagef(DestinationImageUV, CoordinateUV, ColourUV);",
"int2 CoordinateY1 = (int2)(I << 1, J << 1);",
"int2 CoordinateY2 = (int2)(CoordinateY1.s0, CoordinateY1.s1 + 1);",
"int2 CoordinateY3 = (int2)(CoordinateY1.s0 + 1, CoordinateY1.s1);",
"int2 CoordinateY4 = (int2)(CoordinateY1.s0 + 1, CoordinateY1.s1 + 1);",
"float2 NormalizedCoordinateY1 = convert_float2(CoordinateY1) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY2 = convert_float2(CoordinateY2) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY3 = convert_float2(CoordinateY3) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float2 NormalizedCoordinateY4 = convert_float2(CoordinateY4) * (float2)(widthNormalizationFactor, heightNormalizationFactor);",
"float4 ColourY1 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY1);",
"write_imagef(DestinationImageY, CoordinateY1, ColourY1);",
"float4 ColourY2 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY2);",
"write_imagef(DestinationImageY, CoordinateY2, ColourY2);",
"float4 ColourY3 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY3);",
"write_imagef(DestinationImageY, CoordinateY3, ColourY3);",
"float4 ColourY4 = read_imagef(SourceImageY, Sampler_Scaling, NormalizedCoordinateY4);",
"write_imagef(DestinationImageY, CoordinateY4, ColourY4);",
"}",
"__kernel void RotationP_90(__global const uchar* restrict InBufferY, __global const uchar* restrict InBufferU, __global const uchar* restrict InBufferV, __global uchar* restrict OutBufferY, __global uchar* restrict OutBufferU, __global uchar* restrict OutBufferV, const int Width, const int Height)",
"{",
"const int columnUV = get_global_id(0) << 3;",
"const int rowUV = get_global_id(1) << 3;",
"const int offsetUVL1 = (rowUV * Width >> 1) + columnUV;",
"const int offsetUVL2 = offsetUVL1 + (Width >> 1);",
"const int offsetUVL3 = offsetUVL2 + (Width >> 1);",
"const int offsetUVL4 = offsetUVL3 + (Width >> 1);",
"const int offsetUVL5 = offsetUVL4 + (Width >> 1);",
"const int offsetUVL6 = offsetUVL5 + (Width >> 1);",
"const int offsetUVL7 = offsetUVL6 + (Width >> 1);",
"const int offsetUVL8 = offsetUVL7 + (Width >> 1);",
"uchar8 LoadU1 = vload8(0, InBufferU + offsetUVL1);",
"uchar8 LoadU2 = vload8(0, InBufferU + offsetUVL2);",
"uchar8 LoadU3 = vload8(0, InBufferU + offsetUVL3);",
"uchar8 LoadU4 = vload8(0, InBufferU + offsetUVL4);",
"uchar8 LoadU5 = vload8(0, InBufferU + offsetUVL5);",
"uchar8 LoadU6 = vload8(0, InBufferU + offsetUVL6);",
"uchar8 LoadU7 = vload8(0, InBufferU + offsetUVL7);",
"uchar8 LoadU8 = vload8(0, InBufferU + offsetUVL8);",
"uchar8 StoreU1 = (uchar8)(LoadU8.s0, LoadU7.s0, LoadU6.s0, LoadU5.s0, LoadU4.s0, LoadU3.s0, LoadU2.s0, LoadU1.s0);",
"uchar8 StoreU2 = (uchar8)(LoadU8.s1, LoadU7.s1, LoadU6.s1, LoadU5.s1, LoadU4.s1, LoadU3.s1, LoadU2.s1, LoadU1.s1);",
"uchar8 StoreU3 = (uchar8)(LoadU8.s2, LoadU7.s2, LoadU6.s2, LoadU5.s2, LoadU4.s2, LoadU3.s2, LoadU2.s2, LoadU1.s2);",
"uchar8 StoreU4 = (uchar8)(LoadU8.s3, LoadU7.s3, LoadU6.s3, LoadU5.s3, LoadU4.s3, LoadU3.s3, LoadU2.s3, LoadU1.s3);",
"uchar8 StoreU5 = (uchar8)(LoadU8.s4, LoadU7.s4, LoadU6.s4, LoadU5.s4, LoadU4.s4, LoadU3.s4, LoadU2.s4, LoadU1.s4);",
"uchar8 StoreU6 = (uchar8)(LoadU8.s5, LoadU7.s5, LoadU6.s5, LoadU5.s5, LoadU4.s5, LoadU3.s5, LoadU2.s5, LoadU1.s5);",
"uchar8 StoreU7 = (uchar8)(LoadU8.s6, LoadU7.s6, LoadU6.s6, LoadU5.s6, LoadU4.s6, LoadU3.s6, LoadU2.s6, LoadU1.s6);",
"uchar8 StoreU8 = (uchar8)(LoadU8.s7, LoadU7.s7, LoadU6.s7, LoadU5.s7, LoadU4.s7, LoadU3.s7, LoadU2.s7, LoadU1.s7);",
"uchar8 LoadV1 = vload8(0, InBufferV + offsetUVL1);",
"uchar8 LoadV2 = vload8(0, InBufferV + offsetUVL2);",
"uchar8 LoadV3 = vload8(0, InBufferV + offsetUVL3);",
"uchar8 LoadV4 = vload8(0, InBufferV + offsetUVL4);",
"uchar8 LoadV5 = vload8(0, InBufferV + offsetUVL5);",
"uchar8 LoadV6 = vload8(0, InBufferV + offsetUVL6);",
"uchar8 LoadV7 = vload8(0, InBufferV + offsetUVL7);",
"uchar8 LoadV8 = vload8(0, InBufferV + offsetUVL8);",
"uchar8 StoreV1 = (uchar8)(LoadV8.s0, LoadV7.s0, LoadV6.s0, LoadV5.s0, LoadV4.s0, LoadV3.s0, LoadV2.s0, LoadV1.s0);",
"uchar8 StoreV2 = (uchar8)(LoadV8.s1, LoadV7.s1, LoadV6.s1, LoadV5.s1, LoadV4.s1, LoadV3.s1, LoadV2.s1, LoadV1.s1);",
"uchar8 StoreV3 = (uchar8)(LoadV8.s2, LoadV7.s2, LoadV6.s2, LoadV5.s2, LoadV4.s2, LoadV3.s2, LoadV2.s2, LoadV1.s2);",
"uchar8 StoreV4 = (uchar8)(LoadV8.s3, LoadV7.s3, LoadV6.s3, LoadV5.s3, LoadV4.s3, LoadV3.s3, LoadV2.s3, LoadV1.s3);",
"uchar8 StoreV5 = (uchar8)(LoadV8.s4, LoadV7.s4, LoadV6.s4, LoadV5.s4, LoadV4.s4, LoadV3.s4, LoadV2.s4, LoadV1.s4);",
"uchar8 StoreV6 = (uchar8)(LoadV8.s5, LoadV7.s5, LoadV6.s5, LoadV5.s5, LoadV4.s5, LoadV3.s5, LoadV2.s5, LoadV1.s5);",
"uchar8 StoreV7 = (uchar8)(LoadV8.s6, LoadV7.s6, LoadV6.s6, LoadV5.s6, LoadV4.s6, LoadV3.s6, LoadV2.s6, LoadV1.s6);",
"uchar8 StoreV8 = (uchar8)(LoadV8.s7, LoadV7.s7, LoadV6.s7, LoadV5.s7, LoadV4.s7, LoadV3.s7, LoadV2.s7, LoadV1.s7);",
"const int offsetUVS1 = (columnUV * Height >> 1) + (Height >> 1) - rowUV - 8;",
"const int offsetUVS2 = offsetUVS1 + (Height >> 1);",
"const int offsetUVS3 = offsetUVS2 + (Height >> 1);",
"const int offsetUVS4 = offsetUVS3 + (Height >> 1);",
"const int offsetUVS5 = offsetUVS4 + (Height >> 1);",
"const int offsetUVS6 = offsetUVS5 + (Height >> 1);",
"const int offsetUVS7 = offsetUVS6 + (Height >> 1);",
"const int offsetUVS8 = offsetUVS7 + (Height >> 1);",
"vstore8(StoreU1, 0, OutBufferU + offsetUVS1);",
"vstore8(StoreU2, 0, OutBufferU + offsetUVS2);",
"vstore8(StoreU3, 0, OutBufferU + offsetUVS3);",
"vstore8(StoreU4, 0, OutBufferU + offsetUVS4);",
"vstore8(StoreU5, 0, OutBufferU + offsetUVS5);",
"vstore8(StoreU6, 0, OutBufferU + offsetUVS6);",
"vstore8(StoreU7, 0, OutBufferU + offsetUVS7);",
"vstore8(StoreU8, 0, OutBufferU + offsetUVS8);",
"vstore8(StoreV1, 0, OutBufferV + offsetUVS1);",
"vstore8(StoreV2, 0, OutBufferV + offsetUVS2);",
"vstore8(StoreV3, 0, OutBufferV + offsetUVS3);",
"vstore8(StoreV4, 0, OutBufferV + offsetUVS4);",
"vstore8(StoreV5, 0, OutBufferV + offsetUVS5);",
"vstore8(StoreV6, 0, OutBufferV + offsetUVS6);",
"vstore8(StoreV7, 0, OutBufferV + offsetUVS7);",
"vstore8(StoreV8, 0, OutBufferV + offsetUVS8);",
"const int columnY = get_global_id(0) << 4;",
"const int rowY = get_global_id(1) << 4;",
"const int offsetYL1  = rowY * Width + columnY;",
"const int offsetYL2  = offsetYL1  + Width;",
"const int offsetYL3  = offsetYL2  + Width;",
"const int offsetYL4  = offsetYL3  + Width;",
"const int offsetYL5  = offsetYL4  + Width;",
"const int offsetYL6  = offsetYL5  + Width;",
"const int offsetYL7  = offsetYL6  + Width;",
"const int offsetYL8  = offsetYL7  + Width;",
"const int offsetYL9  = offsetYL8  + Width;",
"const int offsetYL10 = offsetYL9  + Width;",
"const int offsetYL11 = offsetYL10 + Width;",
"const int offsetYL12 = offsetYL11 + Width;",
"const int offsetYL13 = offsetYL12 + Width;",
"const int offsetYL14 = offsetYL13 + Width;",
"const int offsetYL15 = offsetYL14 + Width;",
"const int offsetYL16 = offsetYL15 + Width;",
"uchar16 LoadY1  = vload16(0, InBufferY + offsetYL1);",
"uchar16 LoadY2  = vload16(0, InBufferY + offsetYL2);",
"uchar16 LoadY3  = vload16(0, InBufferY + offsetYL3);",
"uchar16 LoadY4  = vload16(0, InBufferY + offsetYL4);",
"uchar16 LoadY5  = vload16(0, InBufferY + offsetYL5);",
"uchar16 LoadY6  = vload16(0, InBufferY + offsetYL6);",
"uchar16 LoadY7  = vload16(0, InBufferY + offsetYL7);",
"uchar16 LoadY8  = vload16(0, InBufferY + offsetYL8);",
"uchar16 LoadY9  = vload16(0, InBufferY + offsetYL9);",
"uchar16 LoadY10 = vload16(0, InBufferY + offsetYL10);",
"uchar16 LoadY11 = vload16(0, InBufferY + offsetYL11);",
"uchar16 LoadY12 = vload16(0, InBufferY + offsetYL12);",
"uchar16 LoadY13 = vload16(0, InBufferY + offsetYL13);",
"uchar16 LoadY14 = vload16(0, InBufferY + offsetYL14);",
"uchar16 LoadY15 = vload16(0, InBufferY + offsetYL15);",
"uchar16 LoadY16 = vload16(0, InBufferY + offsetYL16);",
"uchar16 StoreY1  = (uchar16)(LoadY16.s0, LoadY15.s0, LoadY14.s0, LoadY13.s0, LoadY12.s0, LoadY11.s0, LoadY10.s0, LoadY9.s0, LoadY8.s0, LoadY7.s0, LoadY6.s0, LoadY5.s0, LoadY4.s0, LoadY3.s0, LoadY2.s0, LoadY1.s0);",
"uchar16 StoreY2  = (uchar16)(LoadY16.s1, LoadY15.s1, LoadY14.s1, LoadY13.s1, LoadY12.s1, LoadY11.s1, LoadY10.s1, LoadY9.s1, LoadY8.s1, LoadY7.s1, LoadY6.s1, LoadY5.s1, LoadY4.s1, LoadY3.s1, LoadY2.s1, LoadY1.s1);",
"uchar16 StoreY3  = (uchar16)(LoadY16.s2, LoadY15.s2, LoadY14.s2, LoadY13.s2, LoadY12.s2, LoadY11.s2, LoadY10.s2, LoadY9.s2, LoadY8.s2, LoadY7.s2, LoadY6.s2, LoadY5.s2, LoadY4.s2, LoadY3.s2, LoadY2.s2, LoadY1.s2);",
"uchar16 StoreY4  = (uchar16)(LoadY16.s3, LoadY15.s3, LoadY14.s3, LoadY13.s3, LoadY12.s3, LoadY11.s3, LoadY10.s3, LoadY9.s3, LoadY8.s3, LoadY7.s3, LoadY6.s3, LoadY5.s3, LoadY4.s3, LoadY3.s3, LoadY2.s3, LoadY1.s3);",
"uchar16 StoreY5  = (uchar16)(LoadY16.s4, LoadY15.s4, LoadY14.s4, LoadY13.s4, LoadY12.s4, LoadY11.s4, LoadY10.s4, LoadY9.s4, LoadY8.s4, LoadY7.s4, LoadY6.s4, LoadY5.s4, LoadY4.s4, LoadY3.s4, LoadY2.s4, LoadY1.s4);",
"uchar16 StoreY6  = (uchar16)(LoadY16.s5, LoadY15.s5, LoadY14.s5, LoadY13.s5, LoadY12.s5, LoadY11.s5, LoadY10.s5, LoadY9.s5, LoadY8.s5, LoadY7.s5, LoadY6.s5, LoadY5.s5, LoadY4.s5, LoadY3.s5, LoadY2.s5, LoadY1.s5);",
"uchar16 StoreY7  = (uchar16)(LoadY16.s6, LoadY15.s6, LoadY14.s6, LoadY13.s6, LoadY12.s6, LoadY11.s6, LoadY10.s6, LoadY9.s6, LoadY8.s6, LoadY7.s6, LoadY6.s6, LoadY5.s6, LoadY4.s6, LoadY3.s6, LoadY2.s6, LoadY1.s6);",
"uchar16 StoreY8  = (uchar16)(LoadY16.s7, LoadY15.s7, LoadY14.s7, LoadY13.s7, LoadY12.s7, LoadY11.s7, LoadY10.s7, LoadY9.s7, LoadY8.s7, LoadY7.s7, LoadY6.s7, LoadY5.s7, LoadY4.s7, LoadY3.s7, LoadY2.s7, LoadY1.s7);",
"uchar16 StoreY9  = (uchar16)(LoadY16.s8, LoadY15.s8, LoadY14.s8, LoadY13.s8, LoadY12.s8, LoadY11.s8, LoadY10.s8, LoadY9.s8, LoadY8.s8, LoadY7.s8, LoadY6.s8, LoadY5.s8, LoadY4.s8, LoadY3.s8, LoadY2.s8, LoadY1.s8);",
"uchar16 StoreY10 = (uchar16)(LoadY16.s9, LoadY15.s9, LoadY14.s9, LoadY13.s9, LoadY12.s9, LoadY11.s9, LoadY10.s9, LoadY9.s9, LoadY8.s9, LoadY7.s9, LoadY6.s9, LoadY5.s9, LoadY4.s9, LoadY3.s9, LoadY2.s9, LoadY1.s9);",
"uchar16 StoreY11 = (uchar16)(LoadY16.sa, LoadY15.sa, LoadY14.sa, LoadY13.sa, LoadY12.sa, LoadY11.sa, LoadY10.sa, LoadY9.sa, LoadY8.sa, LoadY7.sa, LoadY6.sa, LoadY5.sa, LoadY4.sa, LoadY3.sa, LoadY2.sa, LoadY1.sa);",
"uchar16 StoreY12 = (uchar16)(LoadY16.sb, LoadY15.sb, LoadY14.sb, LoadY13.sb, LoadY12.sb, LoadY11.sb, LoadY10.sb, LoadY9.sb, LoadY8.sb, LoadY7.sb, LoadY6.sb, LoadY5.sb, LoadY4.sb, LoadY3.sb, LoadY2.sb, LoadY1.sb);",
"uchar16 StoreY13 = (uchar16)(LoadY16.sc, LoadY15.sc, LoadY14.sc, LoadY13.sc, LoadY12.sc, LoadY11.sc, LoadY10.sc, LoadY9.sc, LoadY8.sc, LoadY7.sc, LoadY6.sc, LoadY5.sc, LoadY4.sc, LoadY3.sc, LoadY2.sc, LoadY1.sc);",
"uchar16 StoreY14 = (uchar16)(LoadY16.sd, LoadY15.sd, LoadY14.sd, LoadY13.sd, LoadY12.sd, LoadY11.sd, LoadY10.sd, LoadY9.sd, LoadY8.sd, LoadY7.sd, LoadY6.sd, LoadY5.sd, LoadY4.sd, LoadY3.sd, LoadY2.sd, LoadY1.sd);",
"uchar16 StoreY15 = (uchar16)(LoadY16.se, LoadY15.se, LoadY14.se, LoadY13.se, LoadY12.se, LoadY11.se, LoadY10.se, LoadY9.se, LoadY8.se, LoadY7.se, LoadY6.se, LoadY5.se, LoadY4.se, LoadY3.se, LoadY2.se, LoadY1.se);",
"uchar16 StoreY16 = (uchar16)(LoadY16.sf, LoadY15.sf, LoadY14.sf, LoadY13.sf, LoadY12.sf, LoadY11.sf, LoadY10.sf, LoadY9.sf, LoadY8.sf, LoadY7.sf, LoadY6.sf, LoadY5.sf, LoadY4.sf, LoadY3.sf, LoadY2.sf, LoadY1.sf);",
"const int offsetYS1  = (columnY * Height) + Height - rowY - 16;",
"const int offsetYS2  = offsetYS1  + Height;",
"const int offsetYS3  = offsetYS2  + Height;",
"const int offsetYS4  = offsetYS3  + Height;",
"const int offsetYS5  = offsetYS4  + Height;",
"const int offsetYS6  = offsetYS5  + Height;",
"const int offsetYS7  = offsetYS6  + Height;",
"const int offsetYS8  = offsetYS7  + Height;",
"const int offsetYS9  = offsetYS8  + Height;",
"const int offsetYS10 = offsetYS9  + Height;",
"const int offsetYS11 = offsetYS10 + Height;",
"const int offsetYS12 = offsetYS11 + Height;",
"const int offsetYS13 = offsetYS12 + Height;",
"const int offsetYS14 = offsetYS13 + Height;",
"const int offsetYS15 = offsetYS14 + Height;",
"const int offsetYS16 = offsetYS15 + Height;",
"vstore16(StoreY1,  0, OutBufferY + offsetYS1);",
"vstore16(StoreY2,  0, OutBufferY + offsetYS2);",
"vstore16(StoreY3,  0, OutBufferY + offsetYS3);",
"vstore16(StoreY4,  0, OutBufferY + offsetYS4);",
"vstore16(StoreY5,  0, OutBufferY + offsetYS5);",
"vstore16(StoreY6,  0, OutBufferY + offsetYS6);",
"vstore16(StoreY7,  0, OutBufferY + offsetYS7);",
"vstore16(StoreY8,  0, OutBufferY + offsetYS8);",
"vstore16(StoreY9,  0, OutBufferY + offsetYS9);",
"vstore16(StoreY10, 0, OutBufferY + offsetYS10);",
"vstore16(StoreY11, 0, OutBufferY + offsetYS11);",
"vstore16(StoreY12, 0, OutBufferY + offsetYS12);",
"vstore16(StoreY13, 0, OutBufferY + offsetYS13);",
"vstore16(StoreY14, 0, OutBufferY + offsetYS14);",
"vstore16(StoreY15, 0, OutBufferY + offsetYS15);",
"vstore16(StoreY16, 0, OutBufferY + offsetYS16);",
"}",
"__kernel void RotationP_180(__global const uchar* restrict InBufferY, __global const uchar* restrict InBufferU, __global const uchar* restrict InBufferV, __global uchar* restrict OutBufferY, __global uchar* restrict OutBufferU, __global uchar* restrict OutBufferV, const int Width, const int Height)",
"{",
"const int columnUV = get_global_id(0) << 3;",
"const int row      = get_global_id(1);",
"const int offsetUVL1 = ((row  << 3)      * Width >> 1) + columnUV;",
"const int offsetUVL2 = (((row << 3) + 1) * Width >> 1) + columnUV;",
"const int offsetUVL3 = (((row << 3) + 2) * Width >> 1) + columnUV;",
"const int offsetUVL4 = (((row << 3) + 3) * Width >> 1) + columnUV;",
"const int offsetUVL5 = (((row << 3) + 4) * Width >> 1) + columnUV;",
"const int offsetUVL6 = (((row << 3) + 5) * Width >> 1) + columnUV;",
"const int offsetUVL7 = (((row << 3) + 6) * Width >> 1) + columnUV;",
"const int offsetUVL8 = (((row << 3) + 7) * Width >> 1) + columnUV;",
"uchar8 LoadU1 = vload8(0, InBufferU + offsetUVL1);",
"uchar8 LoadU2 = vload8(0, InBufferU + offsetUVL2);",
"uchar8 LoadU3 = vload8(0, InBufferU + offsetUVL3);",
"uchar8 LoadU4 = vload8(0, InBufferU + offsetUVL4);",
"uchar8 LoadU5 = vload8(0, InBufferU + offsetUVL5);",
"uchar8 LoadU6 = vload8(0, InBufferU + offsetUVL6);",
"uchar8 LoadU7 = vload8(0, InBufferU + offsetUVL7);",
"uchar8 LoadU8 = vload8(0, InBufferU + offsetUVL8);",
"uchar8 StoreU1 = (uchar8)(LoadU8.s7, LoadU8.s6, LoadU8.s5, LoadU8.s4, LoadU8.s3, LoadU8.s2, LoadU8.s1, LoadU8.s0);",
"uchar8 StoreU2 = (uchar8)(LoadU7.s7, LoadU7.s6, LoadU7.s5, LoadU7.s4, LoadU7.s3, LoadU7.s2, LoadU7.s1, LoadU7.s0);",
"uchar8 StoreU3 = (uchar8)(LoadU6.s7, LoadU6.s6, LoadU6.s5, LoadU6.s4, LoadU6.s3, LoadU6.s2, LoadU6.s1, LoadU6.s0);",
"uchar8 StoreU4 = (uchar8)(LoadU5.s7, LoadU5.s6, LoadU5.s5, LoadU5.s4, LoadU5.s3, LoadU5.s2, LoadU5.s1, LoadU5.s0);",
"uchar8 StoreU5 = (uchar8)(LoadU4.s7, LoadU4.s6, LoadU4.s5, LoadU4.s4, LoadU4.s3, LoadU4.s2, LoadU4.s1, LoadU4.s0);",
"uchar8 StoreU6 = (uchar8)(LoadU3.s7, LoadU3.s6, LoadU3.s5, LoadU3.s4, LoadU3.s3, LoadU3.s2, LoadU3.s1, LoadU3.s0);",
"uchar8 StoreU7 = (uchar8)(LoadU2.s7, LoadU2.s6, LoadU2.s5, LoadU2.s4, LoadU2.s3, LoadU2.s2, LoadU2.s1, LoadU2.s0);",
"uchar8 StoreU8 = (uchar8)(LoadU1.s7, LoadU1.s6, LoadU1.s5, LoadU1.s4, LoadU1.s3, LoadU1.s2, LoadU1.s1, LoadU1.s0);",
"uchar8 LoadV1 = vload8(0, InBufferV + offsetUVL1);",
"uchar8 LoadV2 = vload8(0, InBufferV + offsetUVL2);",
"uchar8 LoadV3 = vload8(0, InBufferV + offsetUVL3);",
"uchar8 LoadV4 = vload8(0, InBufferV + offsetUVL4);",
"uchar8 LoadV5 = vload8(0, InBufferV + offsetUVL5);",
"uchar8 LoadV6 = vload8(0, InBufferV + offsetUVL6);",
"uchar8 LoadV7 = vload8(0, InBufferV + offsetUVL7);",
"uchar8 LoadV8 = vload8(0, InBufferV + offsetUVL8);",
"uchar8 StoreV1 = (uchar8)(LoadV8.s7, LoadV8.s6, LoadV8.s5, LoadV8.s4, LoadV8.s3, LoadV8.s2, LoadV8.s1, LoadV8.s0);",
"uchar8 StoreV2 = (uchar8)(LoadV7.s7, LoadV7.s6, LoadV7.s5, LoadV7.s4, LoadV7.s3, LoadV7.s2, LoadV7.s1, LoadV7.s0);",
"uchar8 StoreV3 = (uchar8)(LoadV6.s7, LoadV6.s6, LoadV6.s5, LoadV6.s4, LoadV6.s3, LoadV6.s2, LoadV6.s1, LoadV6.s0);",
"uchar8 StoreV4 = (uchar8)(LoadV5.s7, LoadV5.s6, LoadV5.s5, LoadV5.s4, LoadV5.s3, LoadV5.s2, LoadV5.s1, LoadV5.s0);",
"uchar8 StoreV5 = (uchar8)(LoadV4.s7, LoadV4.s6, LoadV4.s5, LoadV4.s4, LoadV4.s3, LoadV4.s2, LoadV4.s1, LoadV4.s0);",
"uchar8 StoreV6 = (uchar8)(LoadV3.s7, LoadV3.s6, LoadV3.s5, LoadV3.s4, LoadV3.s3, LoadV3.s2, LoadV3.s1, LoadV3.s0);",
"uchar8 StoreV7 = (uchar8)(LoadV2.s7, LoadV2.s6, LoadV2.s5, LoadV2.s4, LoadV2.s3, LoadV2.s2, LoadV2.s1, LoadV2.s0);",
"uchar8 StoreV8 = (uchar8)(LoadV1.s7, LoadV1.s6, LoadV1.s5, LoadV1.s4, LoadV1.s3, LoadV1.s2, LoadV1.s1, LoadV1.s0);",
"const int offsetUVS1 = (((Height >> 1) - (row << 3) - 8) * Width >> 1) + (Width >> 1) - columnUV - 8;",
"const int offsetUVS2 = (((Height >> 1) - (row << 3) - 7) * Width >> 1) + (Width >> 1) - columnUV - 8;",
"const int offsetUVS3 = (((Height >> 1) - (row << 3) - 6) * Width >> 1) + (Width >> 1) - columnUV - 8;",
"const int offsetUVS4 = (((Height >> 1) - (row << 3) - 5) * Width >> 1) + (Width >> 1) - columnUV - 8;",
"const int offsetUVS5 = (((Height >> 1) - (row << 3) - 4) * Width >> 1) + (Width >> 1) - columnUV - 8;",
"const int offsetUVS6 = (((Height >> 1) - (row << 3) - 3) * Width >> 1) + (Width >> 1) - columnUV - 8;",
"const int offsetUVS7 = (((Height >> 1) - (row << 3) - 2) * Width >> 1) + (Width >> 1) - columnUV - 8;",
"const int offsetUVS8 = (((Height >> 1) - (row << 3) - 1) * Width >> 1) + (Width >> 1) - columnUV - 8;",
"vstore8(StoreU1, 0, OutBufferU + offsetUVS1);",
"vstore8(StoreU2, 0, OutBufferU + offsetUVS2);",
"vstore8(StoreU3, 0, OutBufferU + offsetUVS3);",
"vstore8(StoreU4, 0, OutBufferU + offsetUVS4);",
"vstore8(StoreU5, 0, OutBufferU + offsetUVS5);",
"vstore8(StoreU6, 0, OutBufferU + offsetUVS6);",
"vstore8(StoreU7, 0, OutBufferU + offsetUVS7);",
"vstore8(StoreU8, 0, OutBufferU + offsetUVS8);",
"vstore8(StoreV1, 0, OutBufferV + offsetUVS1);",
"vstore8(StoreV2, 0, OutBufferV + offsetUVS2);",
"vstore8(StoreV3, 0, OutBufferV + offsetUVS3);",
"vstore8(StoreV4, 0, OutBufferV + offsetUVS4);",
"vstore8(StoreV5, 0, OutBufferV + offsetUVS5);",
"vstore8(StoreV6, 0, OutBufferV + offsetUVS6);",
"vstore8(StoreV7, 0, OutBufferV + offsetUVS7);",
"vstore8(StoreV8, 0, OutBufferV + offsetUVS8);",
"const int columnY = get_global_id(0) << 4;",
"const int offsetYL1  = ((row  << 4)       * Width) + columnY;",
"const int offsetYL2  = (((row << 4) +  1) * Width) + columnY;",
"const int offsetYL3  = (((row << 4) +  2) * Width) + columnY;",
"const int offsetYL4  = (((row << 4) +  3) * Width) + columnY;",
"const int offsetYL5  = (((row << 4) +  4) * Width) + columnY;",
"const int offsetYL6  = (((row << 4) +  5) * Width) + columnY;",
"const int offsetYL7  = (((row << 4) +  6) * Width) + columnY;",
"const int offsetYL8  = (((row << 4) +  7) * Width) + columnY;",
"const int offsetYL9  = (((row << 4) +  8) * Width) + columnY;",
"const int offsetYL10 = (((row << 4) +  9) * Width) + columnY;",
"const int offsetYL11 = (((row << 4) + 10) * Width) + columnY;",
"const int offsetYL12 = (((row << 4) + 11) * Width) + columnY;",
"const int offsetYL13 = (((row << 4) + 12) * Width) + columnY;",
"const int offsetYL14 = (((row << 4) + 13) * Width) + columnY;",
"const int offsetYL15 = (((row << 4) + 14) * Width) + columnY;",
"const int offsetYL16 = (((row << 4) + 15) * Width) + columnY;",
"uchar16 LoadY1  = vload16(0, InBufferY + offsetYL1);",
"uchar16 LoadY2  = vload16(0, InBufferY + offsetYL2);",
"uchar16 LoadY3  = vload16(0, InBufferY + offsetYL3);",
"uchar16 LoadY4  = vload16(0, InBufferY + offsetYL4);",
"uchar16 LoadY5  = vload16(0, InBufferY + offsetYL5);",
"uchar16 LoadY6  = vload16(0, InBufferY + offsetYL6);",
"uchar16 LoadY7  = vload16(0, InBufferY + offsetYL7);",
"uchar16 LoadY8  = vload16(0, InBufferY + offsetYL8);",
"uchar16 LoadY9  = vload16(0, InBufferY + offsetYL9);",
"uchar16 LoadY10 = vload16(0, InBufferY + offsetYL10);",
"uchar16 LoadY11 = vload16(0, InBufferY + offsetYL11);",
"uchar16 LoadY12 = vload16(0, InBufferY + offsetYL12);",
"uchar16 LoadY13 = vload16(0, InBufferY + offsetYL13);",
"uchar16 LoadY14 = vload16(0, InBufferY + offsetYL14);",
"uchar16 LoadY15 = vload16(0, InBufferY + offsetYL15);",
"uchar16 LoadY16 = vload16(0, InBufferY + offsetYL16);",
"uchar16 StoreY1  = (uchar16)(LoadY16.sf, LoadY16.se, LoadY16.sd, LoadY16.sc, LoadY16.sb, LoadY16.sa, LoadY16.s9, LoadY16.s8, LoadY16.s7, LoadY16.s6, LoadY16.s5, LoadY16.s4, LoadY16.s3, LoadY16.s2, LoadY16.s1, LoadY16.s0);",
"uchar16 StoreY2  = (uchar16)(LoadY15.sf, LoadY15.se, LoadY15.sd, LoadY15.sc, LoadY15.sb, LoadY15.sa, LoadY15.s9, LoadY15.s8, LoadY15.s7, LoadY15.s6, LoadY15.s5, LoadY15.s4, LoadY15.s3, LoadY15.s2, LoadY15.s1, LoadY15.s0);",
"uchar16 StoreY3  = (uchar16)(LoadY14.sf, LoadY14.se, LoadY14.sd, LoadY14.sc, LoadY14.sb, LoadY14.sa, LoadY14.s9, LoadY14.s8, LoadY14.s7, LoadY14.s6, LoadY14.s5, LoadY14.s4, LoadY14.s3, LoadY14.s2, LoadY14.s1, LoadY14.s0);",
"uchar16 StoreY4  = (uchar16)(LoadY13.sf, LoadY13.se, LoadY13.sd, LoadY13.sc, LoadY13.sb, LoadY13.sa, LoadY13.s9, LoadY13.s8, LoadY13.s7, LoadY13.s6, LoadY13.s5, LoadY13.s4, LoadY13.s3, LoadY13.s2, LoadY13.s1, LoadY13.s0);",
"uchar16 StoreY5  = (uchar16)(LoadY12.sf, LoadY12.se, LoadY12.sd, LoadY12.sc, LoadY12.sb, LoadY12.sa, LoadY12.s9, LoadY12.s8, LoadY12.s7, LoadY12.s6, LoadY12.s5, LoadY12.s4, LoadY12.s3, LoadY12.s2, LoadY12.s1, LoadY12.s0);",
"uchar16 StoreY6  = (uchar16)(LoadY11.sf, LoadY11.se, LoadY11.sd, LoadY11.sc, LoadY11.sb, LoadY11.sa, LoadY11.s9, LoadY11.s8, LoadY11.s7, LoadY11.s6, LoadY11.s5, LoadY11.s4, LoadY11.s3, LoadY11.s2, LoadY11.s1, LoadY11.s0);",
"uchar16 StoreY7  = (uchar16)(LoadY10.sf, LoadY10.se, LoadY10.sd, LoadY10.sc, LoadY10.sb, LoadY10.sa, LoadY10.s9, LoadY10.s8, LoadY10.s7, LoadY10.s6, LoadY10.s5, LoadY10.s4, LoadY10.s3, LoadY10.s2, LoadY10.s1, LoadY10.s0);",
"uchar16 StoreY8  = (uchar16)( LoadY9.sf,  LoadY9.se,  LoadY9.sd,  LoadY9.sc,  LoadY9.sb,  LoadY9.sa,  LoadY9.s9,  LoadY9.s8,  LoadY9.s7,  LoadY9.s6,  LoadY9.s5,  LoadY9.s4,  LoadY9.s3,  LoadY9.s2,  LoadY9.s1,  LoadY9.s0);",
"uchar16 StoreY9  = (uchar16)( LoadY8.sf,  LoadY8.se,  LoadY8.sd,  LoadY8.sc,  LoadY8.sb,  LoadY8.sa,  LoadY8.s9,  LoadY8.s8,  LoadY8.s7,  LoadY8.s6,  LoadY8.s5,  LoadY8.s4,  LoadY8.s3,  LoadY8.s2,  LoadY8.s1,  LoadY8.s0);",
"uchar16 StoreY10 = (uchar16)( LoadY7.sf,  LoadY7.se,  LoadY7.sd,  LoadY7.sc,  LoadY7.sb,  LoadY7.sa,  LoadY7.s9,  LoadY7.s8,  LoadY7.s7,  LoadY7.s6,  LoadY7.s5,  LoadY7.s4,  LoadY7.s3,  LoadY7.s2,  LoadY7.s1,  LoadY7.s0);",
"uchar16 StoreY11 = (uchar16)( LoadY6.sf,  LoadY6.se,  LoadY6.sd,  LoadY6.sc,  LoadY6.sb,  LoadY6.sa,  LoadY6.s9,  LoadY6.s8,  LoadY6.s7,  LoadY6.s6,  LoadY6.s5,  LoadY6.s4,  LoadY6.s3,  LoadY6.s2,  LoadY6.s1,  LoadY6.s0);",
"uchar16 StoreY12 = (uchar16)( LoadY5.sf,  LoadY5.se,  LoadY5.sd,  LoadY5.sc,  LoadY5.sb,  LoadY5.sa,  LoadY5.s9,  LoadY5.s8,  LoadY5.s7,  LoadY5.s6,  LoadY5.s5,  LoadY5.s4,  LoadY5.s3,  LoadY5.s2,  LoadY5.s1,  LoadY5.s0);",
"uchar16 StoreY13 = (uchar16)( LoadY4.sf,  LoadY4.se,  LoadY4.sd,  LoadY4.sc,  LoadY4.sb,  LoadY4.sa,  LoadY4.s9,  LoadY4.s8,  LoadY4.s7,  LoadY4.s6,  LoadY4.s5,  LoadY4.s4,  LoadY4.s3,  LoadY4.s2,  LoadY4.s1,  LoadY4.s0);",
"uchar16 StoreY14 = (uchar16)( LoadY3.sf,  LoadY3.se,  LoadY3.sd,  LoadY3.sc,  LoadY3.sb,  LoadY3.sa,  LoadY3.s9,  LoadY3.s8,  LoadY3.s7,  LoadY3.s6,  LoadY3.s5,  LoadY3.s4,  LoadY3.s3,  LoadY3.s2,  LoadY3.s1,  LoadY3.s0);",
"uchar16 StoreY15 = (uchar16)( LoadY2.sf,  LoadY2.se,  LoadY2.sd,  LoadY2.sc,  LoadY2.sb,  LoadY2.sa,  LoadY2.s9,  LoadY2.s8,  LoadY2.s7,  LoadY2.s6,  LoadY2.s5,  LoadY2.s4,  LoadY2.s3,  LoadY2.s2,  LoadY2.s1,  LoadY2.s0);",
"uchar16 StoreY16 = (uchar16)( LoadY1.sf,  LoadY1.se,  LoadY1.sd,  LoadY1.sc,  LoadY1.sb,  LoadY1.sa,  LoadY1.s9,  LoadY1.s8,  LoadY1.s7,  LoadY1.s6,  LoadY1.s5,  LoadY1.s4,  LoadY1.s3,  LoadY1.s2,  LoadY1.s1,  LoadY1.s0);",
"const int offsetYS1  = (Height - (row << 4) - 16) * Width + Width - columnY - 16;",
"const int offsetYS2  = (Height - (row << 4) - 15) * Width + Width - columnY - 16;",
"const int offsetYS3  = (Height - (row << 4) - 14) * Width + Width - columnY - 16;",
"const int offsetYS4  = (Height - (row << 4) - 13) * Width + Width - columnY - 16;",
"const int offsetYS5  = (Height - (row << 4) - 12) * Width + Width - columnY - 16;",
"const int offsetYS6  = (Height - (row << 4) - 11) * Width + Width - columnY - 16;",
"const int offsetYS7  = (Height - (row << 4) - 10) * Width + Width - columnY - 16;",
"const int offsetYS8  = (Height - (row << 4) - 9)  * Width + Width - columnY - 16;",
"const int offsetYS9  = (Height - (row << 4) - 8)  * Width + Width - columnY - 16;",
"const int offsetYS10 = (Height - (row << 4) - 7)  * Width + Width - columnY - 16;",
"const int offsetYS11 = (Height - (row << 4) - 6)  * Width + Width - columnY - 16;",
"const int offsetYS12 = (Height - (row << 4) - 5)  * Width + Width - columnY - 16;",
"const int offsetYS13 = (Height - (row << 4) - 4)  * Width + Width - columnY - 16;",
"const int offsetYS14 = (Height - (row << 4) - 3)  * Width + Width - columnY - 16;",
"const int offsetYS15 = (Height - (row << 4) - 2)  * Width + Width - columnY - 16;",
"const int offsetYS16 = (Height - (row << 4) - 1)  * Width + Width - columnY - 16;",
"vstore16(StoreY1,  0, OutBufferY + offsetYS1);",
"vstore16(StoreY2,  0, OutBufferY + offsetYS2);",
"vstore16(StoreY3,  0, OutBufferY + offsetYS3);",
"vstore16(StoreY4,  0, OutBufferY + offsetYS4);",
"vstore16(StoreY5,  0, OutBufferY + offsetYS5);",
"vstore16(StoreY6,  0, OutBufferY + offsetYS6);",
"vstore16(StoreY7,  0, OutBufferY + offsetYS7);",
"vstore16(StoreY8,  0, OutBufferY + offsetYS8);",
"vstore16(StoreY9,  0, OutBufferY + offsetYS9);",
"vstore16(StoreY10, 0, OutBufferY + offsetYS10);",
"vstore16(StoreY11, 0, OutBufferY + offsetYS11);",
"vstore16(StoreY12, 0, OutBufferY + offsetYS12);",
"vstore16(StoreY13, 0, OutBufferY + offsetYS13);",
"vstore16(StoreY14, 0, OutBufferY + offsetYS14);",
"vstore16(StoreY15, 0, OutBufferY + offsetYS15);",
"vstore16(StoreY16, 0, OutBufferY + offsetYS16);",
"}",
"__kernel void RotationP_270(__global const uchar* restrict InBufferY, __global const uchar* restrict InBufferU, __global const uchar* restrict InBufferV, __global uchar* restrict OutBufferY, __global uchar* restrict OutBufferU, __global uchar* restrict OutBufferV, const int Width, const int Height)",
"{",
"const int columnUV = get_global_id(0) << 3;",
"const int row = get_global_id(1);",
"const int offsetUVL1 = ((row  << 3)      * Width >> 1) + columnUV;",
"const int offsetUVL2 = (((row << 3) + 1) * Width >> 1) + columnUV;",
"const int offsetUVL3 = (((row << 3) + 2) * Width >> 1) + columnUV;",
"const int offsetUVL4 = (((row << 3) + 3) * Width >> 1) + columnUV;",
"const int offsetUVL5 = (((row << 3) + 4) * Width >> 1) + columnUV;",
"const int offsetUVL6 = (((row << 3) + 5) * Width >> 1) + columnUV;",
"const int offsetUVL7 = (((row << 3) + 6) * Width >> 1) + columnUV;",
"const int offsetUVL8 = (((row << 3) + 7) * Width >> 1) + columnUV;",
"uchar8 LoadU1 = vload8(0, InBufferU + offsetUVL1);",
"uchar8 LoadU2 = vload8(0, InBufferU + offsetUVL2);",
"uchar8 LoadU3 = vload8(0, InBufferU + offsetUVL3);",
"uchar8 LoadU4 = vload8(0, InBufferU + offsetUVL4);",
"uchar8 LoadU5 = vload8(0, InBufferU + offsetUVL5);",
"uchar8 LoadU6 = vload8(0, InBufferU + offsetUVL6);",
"uchar8 LoadU7 = vload8(0, InBufferU + offsetUVL7);",
"uchar8 LoadU8 = vload8(0, InBufferU + offsetUVL8);",
"uchar8 StoreU1 = (uchar8)(LoadU1.s0, LoadU2.s0, LoadU3.s0, LoadU4.s0, LoadU5.s0, LoadU6.s0, LoadU7.s0, LoadU8.s0);",
"uchar8 StoreU2 = (uchar8)(LoadU1.s1, LoadU2.s1, LoadU3.s1, LoadU4.s1, LoadU5.s1, LoadU6.s1, LoadU7.s1, LoadU8.s1);",
"uchar8 StoreU3 = (uchar8)(LoadU1.s2, LoadU2.s2, LoadU3.s2, LoadU4.s2, LoadU5.s2, LoadU6.s2, LoadU7.s2, LoadU8.s2);",
"uchar8 StoreU4 = (uchar8)(LoadU1.s3, LoadU2.s3, LoadU3.s3, LoadU4.s3, LoadU5.s3, LoadU6.s3, LoadU7.s3, LoadU8.s3);",
"uchar8 StoreU5 = (uchar8)(LoadU1.s4, LoadU2.s4, LoadU3.s4, LoadU4.s4, LoadU5.s4, LoadU6.s4, LoadU7.s4, LoadU8.s4);",
"uchar8 StoreU6 = (uchar8)(LoadU1.s5, LoadU2.s5, LoadU3.s5, LoadU4.s5, LoadU5.s5, LoadU6.s5, LoadU7.s5, LoadU8.s5);",
"uchar8 StoreU7 = (uchar8)(LoadU1.s6, LoadU2.s6, LoadU3.s6, LoadU4.s6, LoadU5.s6, LoadU6.s6, LoadU7.s6, LoadU8.s6);",
"uchar8 StoreU8 = (uchar8)(LoadU1.s7, LoadU2.s7, LoadU3.s7, LoadU4.s7, LoadU5.s7, LoadU6.s7, LoadU7.s7, LoadU8.s7);",
"uchar8 LoadV1 = vload8(0, InBufferV + offsetUVL1);",
"uchar8 LoadV2 = vload8(0, InBufferV + offsetUVL2);",
"uchar8 LoadV3 = vload8(0, InBufferV + offsetUVL3);",
"uchar8 LoadV4 = vload8(0, InBufferV + offsetUVL4);",
"uchar8 LoadV5 = vload8(0, InBufferV + offsetUVL5);",
"uchar8 LoadV6 = vload8(0, InBufferV + offsetUVL6);",
"uchar8 LoadV7 = vload8(0, InBufferV + offsetUVL7);",
"uchar8 LoadV8 = vload8(0, InBufferV + offsetUVL8);",
"uchar8 StoreV1 = (uchar8)(LoadV1.s0, LoadV2.s0, LoadV3.s0, LoadV4.s0, LoadV5.s0, LoadV6.s0, LoadV7.s0, LoadV8.s0);",
"uchar8 StoreV2 = (uchar8)(LoadV1.s1, LoadV2.s1, LoadV3.s1, LoadV4.s1, LoadV5.s1, LoadV6.s1, LoadV7.s1, LoadV8.s1);",
"uchar8 StoreV3 = (uchar8)(LoadV1.s2, LoadV2.s2, LoadV3.s2, LoadV4.s2, LoadV5.s2, LoadV6.s2, LoadV7.s2, LoadV8.s2);",
"uchar8 StoreV4 = (uchar8)(LoadV1.s3, LoadV2.s3, LoadV3.s3, LoadV4.s3, LoadV5.s3, LoadV6.s3, LoadV7.s3, LoadV8.s3);",
"uchar8 StoreV5 = (uchar8)(LoadV1.s4, LoadV2.s4, LoadV3.s4, LoadV4.s4, LoadV5.s4, LoadV6.s4, LoadV7.s4, LoadV8.s4);",
"uchar8 StoreV6 = (uchar8)(LoadV1.s5, LoadV2.s5, LoadV3.s5, LoadV4.s5, LoadV5.s5, LoadV6.s5, LoadV7.s5, LoadV8.s5);",
"uchar8 StoreV7 = (uchar8)(LoadV1.s6, LoadV2.s6, LoadV3.s6, LoadV4.s6, LoadV5.s6, LoadV6.s6, LoadV7.s6, LoadV8.s6);",
"uchar8 StoreV8 = (uchar8)(LoadV1.s7, LoadV2.s7, LoadV3.s7, LoadV4.s7, LoadV5.s7, LoadV6.s7, LoadV7.s7, LoadV8.s7);",
"const int offsetUVS1 = (((Width >> 1) - columnUV - 1) * Height >> 1) + (row << 3);",
"const int offsetUVS2 = (((Width >> 1) - columnUV - 2) * Height >> 1) + (row << 3);",
"const int offsetUVS3 = (((Width >> 1) - columnUV - 3) * Height >> 1) + (row << 3);",
"const int offsetUVS4 = (((Width >> 1) - columnUV - 4) * Height >> 1) + (row << 3);",
"const int offsetUVS5 = (((Width >> 1) - columnUV - 5) * Height >> 1) + (row << 3);",
"const int offsetUVS6 = (((Width >> 1) - columnUV - 6) * Height >> 1) + (row << 3);",
"const int offsetUVS7 = (((Width >> 1) - columnUV - 7) * Height >> 1) + (row << 3);",
"const int offsetUVS8 = (((Width >> 1) - columnUV - 8) * Height >> 1) + (row << 3);",
"vstore8(StoreU1, 0, OutBufferU + offsetUVS1);",
"vstore8(StoreU2, 0, OutBufferU + offsetUVS2);",
"vstore8(StoreU3, 0, OutBufferU + offsetUVS3);",
"vstore8(StoreU4, 0, OutBufferU + offsetUVS4);",
"vstore8(StoreU5, 0, OutBufferU + offsetUVS5);",
"vstore8(StoreU6, 0, OutBufferU + offsetUVS6);",
"vstore8(StoreU7, 0, OutBufferU + offsetUVS7);",
"vstore8(StoreU8, 0, OutBufferU + offsetUVS8);",
"vstore8(StoreV1, 0, OutBufferV + offsetUVS1);",
"vstore8(StoreV2, 0, OutBufferV + offsetUVS2);",
"vstore8(StoreV3, 0, OutBufferV + offsetUVS3);",
"vstore8(StoreV4, 0, OutBufferV + offsetUVS4);",
"vstore8(StoreV5, 0, OutBufferV + offsetUVS5);",
"vstore8(StoreV6, 0, OutBufferV + offsetUVS6);",
"vstore8(StoreV7, 0, OutBufferV + offsetUVS7);",
"vstore8(StoreV8, 0, OutBufferV + offsetUVS8);",
"const int columnY = get_global_id(0) << 4;",
"const int offsetYL1  = ((row  << 4)       * Width) + columnY;",
"const int offsetYL2  = (((row << 4) +  1) * Width) + columnY;",
"const int offsetYL3  = (((row << 4) +  2) * Width) + columnY;",
"const int offsetYL4  = (((row << 4) +  3) * Width) + columnY;",
"const int offsetYL5  = (((row << 4) +  4) * Width) + columnY;",
"const int offsetYL6  = (((row << 4) +  5) * Width) + columnY;",
"const int offsetYL7  = (((row << 4) +  6) * Width) + columnY;",
"const int offsetYL8  = (((row << 4) +  7) * Width) + columnY;",
"const int offsetYL9  = (((row << 4) +  8) * Width) + columnY;",
"const int offsetYL10 = (((row << 4) +  9) * Width) + columnY;",
"const int offsetYL11 = (((row << 4) + 10) * Width) + columnY;",
"const int offsetYL12 = (((row << 4) + 11) * Width) + columnY;",
"const int offsetYL13 = (((row << 4) + 12) * Width) + columnY;",
"const int offsetYL14 = (((row << 4) + 13) * Width) + columnY;",
"const int offsetYL15 = (((row << 4) + 14) * Width) + columnY;",
"const int offsetYL16 = (((row << 4) + 15) * Width) + columnY;",
"uchar16 LoadY1  = vload16(0, InBufferY + offsetYL1);",
"uchar16 LoadY2  = vload16(0, InBufferY + offsetYL2);",
"uchar16 LoadY3  = vload16(0, InBufferY + offsetYL3);",
"uchar16 LoadY4  = vload16(0, InBufferY + offsetYL4);",
"uchar16 LoadY5  = vload16(0, InBufferY + offsetYL5);",
"uchar16 LoadY6  = vload16(0, InBufferY + offsetYL6);",
"uchar16 LoadY7  = vload16(0, InBufferY + offsetYL7);",
"uchar16 LoadY8  = vload16(0, InBufferY + offsetYL8);",
"uchar16 LoadY9  = vload16(0, InBufferY + offsetYL9);",
"uchar16 LoadY10 = vload16(0, InBufferY + offsetYL10);",
"uchar16 LoadY11 = vload16(0, InBufferY + offsetYL11);",
"uchar16 LoadY12 = vload16(0, InBufferY + offsetYL12);",
"uchar16 LoadY13 = vload16(0, InBufferY + offsetYL13);",
"uchar16 LoadY14 = vload16(0, InBufferY + offsetYL14);",
"uchar16 LoadY15 = vload16(0, InBufferY + offsetYL15);",
"uchar16 LoadY16 = vload16(0, InBufferY + offsetYL16);",
"uchar16 StoreY1  = (uchar16)(LoadY1.s0, LoadY2.s0, LoadY3.s0, LoadY4.s0, LoadY5.s0, LoadY6.s0, LoadY7.s0, LoadY8.s0, LoadY9.s0, LoadY10.s0, LoadY11.s0, LoadY12.s0, LoadY13.s0, LoadY14.s0, LoadY15.s0, LoadY16.s0);",
"uchar16 StoreY2  = (uchar16)(LoadY1.s1, LoadY2.s1, LoadY3.s1, LoadY4.s1, LoadY5.s1, LoadY6.s1, LoadY7.s1, LoadY8.s1, LoadY9.s1, LoadY10.s1, LoadY11.s1, LoadY12.s1, LoadY13.s1, LoadY14.s1, LoadY15.s1, LoadY16.s1);",
"uchar16 StoreY3  = (uchar16)(LoadY1.s2, LoadY2.s2, LoadY3.s2, LoadY4.s2, LoadY5.s2, LoadY6.s2, LoadY7.s2, LoadY8.s2, LoadY9.s2, LoadY10.s2, LoadY11.s2, LoadY12.s2, LoadY13.s2, LoadY14.s2, LoadY15.s2, LoadY16.s2);",
"uchar16 StoreY4  = (uchar16)(LoadY1.s3, LoadY2.s3, LoadY3.s3, LoadY4.s3, LoadY5.s3, LoadY6.s3, LoadY7.s3, LoadY8.s3, LoadY9.s3, LoadY10.s3, LoadY11.s3, LoadY12.s3, LoadY13.s3, LoadY14.s3, LoadY15.s3, LoadY16.s3);",
"uchar16 StoreY5  = (uchar16)(LoadY1.s4, LoadY2.s4, LoadY3.s4, LoadY4.s4, LoadY5.s4, LoadY6.s4, LoadY7.s4, LoadY8.s4, LoadY9.s4, LoadY10.s4, LoadY11.s4, LoadY12.s4, LoadY13.s4, LoadY14.s4, LoadY15.s4, LoadY16.s4);",
"uchar16 StoreY6  = (uchar16)(LoadY1.s5, LoadY2.s5, LoadY3.s5, LoadY4.s5, LoadY5.s5, LoadY6.s5, LoadY7.s5, LoadY8.s5, LoadY9.s5, LoadY10.s5, LoadY11.s5, LoadY12.s5, LoadY13.s5, LoadY14.s5, LoadY15.s5, LoadY16.s5);",
"uchar16 StoreY7  = (uchar16)(LoadY1.s6, LoadY2.s6, LoadY3.s6, LoadY4.s6, LoadY5.s6, LoadY6.s6, LoadY7.s6, LoadY8.s6, LoadY9.s6, LoadY10.s6, LoadY11.s6, LoadY12.s6, LoadY13.s6, LoadY14.s6, LoadY15.s6, LoadY16.s6);",
"uchar16 StoreY8  = (uchar16)(LoadY1.s7, LoadY2.s7, LoadY3.s7, LoadY4.s7, LoadY5.s7, LoadY6.s7, LoadY7.s7, LoadY8.s7, LoadY9.s7, LoadY10.s7, LoadY11.s7, LoadY12.s7, LoadY13.s7, LoadY14.s7, LoadY15.s7, LoadY16.s7);",
"uchar16 StoreY9  = (uchar16)(LoadY1.s8, LoadY2.s8, LoadY3.s0, LoadY4.s8, LoadY5.s8, LoadY6.s8, LoadY7.s8, LoadY8.s8, LoadY9.s8, LoadY10.s8, LoadY11.s8, LoadY12.s8, LoadY13.s8, LoadY14.s8, LoadY15.s8, LoadY16.s8);",
"uchar16 StoreY10 = (uchar16)(LoadY1.s9, LoadY2.s9, LoadY3.s9, LoadY4.s9, LoadY5.s9, LoadY6.s9, LoadY7.s9, LoadY8.s9, LoadY9.s9, LoadY10.s9, LoadY11.s9, LoadY12.s9, LoadY13.s9, LoadY14.s9, LoadY15.s9, LoadY16.s9);",
"uchar16 StoreY11 = (uchar16)(LoadY1.sa, LoadY2.sa, LoadY3.sa, LoadY4.sa, LoadY5.sa, LoadY6.sa, LoadY7.sa, LoadY8.sa, LoadY9.sa, LoadY10.sa, LoadY11.sa, LoadY12.sa, LoadY13.sa, LoadY14.sa, LoadY15.sa, LoadY16.sa);",
"uchar16 StoreY12 = (uchar16)(LoadY1.sb, LoadY2.sb, LoadY3.sb, LoadY4.sb, LoadY5.sb, LoadY6.sb, LoadY7.sb, LoadY8.sb, LoadY9.sb, LoadY10.sb, LoadY11.sb, LoadY12.sb, LoadY13.sb, LoadY14.sb, LoadY15.sb, LoadY16.sb);",
"uchar16 StoreY13 = (uchar16)(LoadY1.sc, LoadY2.sc, LoadY3.sc, LoadY4.sc, LoadY5.sc, LoadY6.sc, LoadY7.sc, LoadY8.sc, LoadY9.sc, LoadY10.sc, LoadY11.sc, LoadY12.sc, LoadY13.sc, LoadY14.sc, LoadY15.sc, LoadY16.sc);",
"uchar16 StoreY14 = (uchar16)(LoadY1.sd, LoadY2.sd, LoadY3.sd, LoadY4.sd, LoadY5.sd, LoadY6.sd, LoadY7.sd, LoadY8.sd, LoadY9.sd, LoadY10.sd, LoadY11.sd, LoadY12.sd, LoadY13.sd, LoadY14.sd, LoadY15.sd, LoadY16.sd);",
"uchar16 StoreY15 = (uchar16)(LoadY1.se, LoadY2.se, LoadY3.se, LoadY4.se, LoadY5.se, LoadY6.se, LoadY7.se, LoadY8.se, LoadY9.se, LoadY10.se, LoadY11.se, LoadY12.se, LoadY13.se, LoadY14.se, LoadY15.se, LoadY16.se);",
"uchar16 StoreY16 = (uchar16)(LoadY1.sf, LoadY2.sf, LoadY3.sf, LoadY4.sf, LoadY5.sf, LoadY6.sf, LoadY7.sf, LoadY8.sf, LoadY9.sf, LoadY10.sf, LoadY11.sf, LoadY12.sf, LoadY13.sf, LoadY14.sf, LoadY15.sf, LoadY16.sf);",
"const int offsetYS1  = ((Width - columnY -  1) * Height) + (row << 4);",
"const int offsetYS2  = ((Width - columnY -  2) * Height) + (row << 4);",
"const int offsetYS3  = ((Width - columnY -  3) * Height) + (row << 4);",
"const int offsetYS4  = ((Width - columnY -  4) * Height) + (row << 4);",
"const int offsetYS5  = ((Width - columnY -  5) * Height) + (row << 4);",
"const int offsetYS6  = ((Width - columnY -  6) * Height) + (row << 4);",
"const int offsetYS7  = ((Width - columnY -  7) * Height) + (row << 4);",
"const int offsetYS8  = ((Width - columnY -  8) * Height) + (row << 4);",
"const int offsetYS9  = ((Width - columnY -  9) * Height) + (row << 4);",
"const int offsetYS10 = ((Width - columnY - 10) * Height) + (row << 4);",
"const int offsetYS11 = ((Width - columnY - 11) * Height) + (row << 4);",
"const int offsetYS12 = ((Width - columnY - 12) * Height) + (row << 4);",
"const int offsetYS13 = ((Width - columnY - 13) * Height) + (row << 4);",
"const int offsetYS14 = ((Width - columnY - 14) * Height) + (row << 4);",
"const int offsetYS15 = ((Width - columnY - 15) * Height) + (row << 4);",
"const int offsetYS16 = ((Width - columnY - 16) * Height) + (row << 4);",
"vstore16(StoreY1,  0, OutBufferY + offsetYS1);",
"vstore16(StoreY2,  0, OutBufferY + offsetYS2);",
"vstore16(StoreY3,  0, OutBufferY + offsetYS3);",
"vstore16(StoreY4,  0, OutBufferY + offsetYS4);",
"vstore16(StoreY5,  0, OutBufferY + offsetYS5);",
"vstore16(StoreY6,  0, OutBufferY + offsetYS6);",
"vstore16(StoreY7,  0, OutBufferY + offsetYS7);",
"vstore16(StoreY8,  0, OutBufferY + offsetYS8);",
"vstore16(StoreY9,  0, OutBufferY + offsetYS9);",
"vstore16(StoreY10, 0, OutBufferY + offsetYS10);",
"vstore16(StoreY11, 0, OutBufferY + offsetYS11);",
"vstore16(StoreY12, 0, OutBufferY + offsetYS12);",
"vstore16(StoreY13, 0, OutBufferY + offsetYS13);",
"vstore16(StoreY14, 0, OutBufferY + offsetYS14);",
"vstore16(StoreY15, 0, OutBufferY + offsetYS15);",
"vstore16(StoreY16, 0, OutBufferY + offsetYS16);",
"}",
"__kernel void RotationSP_90(__global const uchar* restrict InBufferY, __global const uchar* restrict InBufferUV, __global uchar* restrict OutBufferY, __global uchar* restrict OutBufferUV, const int Width, const int Height)",
"{",
"const int column = get_global_id(0) << 4;",
"const int row = get_global_id(1);",
"const int offsetUVL1 = ((row  << 3)      * Width) + column;",
"const int offsetUVL2 = (((row << 3) + 1) * Width) + column;",
"const int offsetUVL3 = (((row << 3) + 2) * Width) + column;",
"const int offsetUVL4 = (((row << 3) + 3) * Width) + column;",
"const int offsetUVL5 = (((row << 3) + 4) * Width) + column;",
"const int offsetUVL6 = (((row << 3) + 5) * Width) + column;",
"const int offsetUVL7 = (((row << 3) + 6) * Width) + column;",
"const int offsetUVL8 = (((row << 3) + 7) * Width) + column;",
"uchar16 LoadUV1 = vload16(0, InBufferUV + offsetUVL1);",
"uchar16 LoadUV2 = vload16(0, InBufferUV + offsetUVL2);",
"uchar16 LoadUV3 = vload16(0, InBufferUV + offsetUVL3);",
"uchar16 LoadUV4 = vload16(0, InBufferUV + offsetUVL4);",
"uchar16 LoadUV5 = vload16(0, InBufferUV + offsetUVL5);",
"uchar16 LoadUV6 = vload16(0, InBufferUV + offsetUVL6);",
"uchar16 LoadUV7 = vload16(0, InBufferUV + offsetUVL7);",
"uchar16 LoadUV8 = vload16(0, InBufferUV + offsetUVL8);",
"uchar16 StoreUV1 = (uchar16)(LoadUV8.s0, LoadUV8.s1, LoadUV7.s0, LoadUV7.s1, LoadUV6.s0, LoadUV6.s1, LoadUV5.s0, LoadUV5.s1, LoadUV4.s0, LoadUV4.s1, LoadUV3.s0, LoadUV3.s1, LoadUV2.s0, LoadUV2.s1, LoadUV1.s0, LoadUV1.s1);",
"uchar16 StoreUV2 = (uchar16)(LoadUV8.s2, LoadUV8.s3, LoadUV7.s2, LoadUV7.s3, LoadUV6.s2, LoadUV6.s3, LoadUV5.s2, LoadUV5.s3, LoadUV4.s2, LoadUV4.s3, LoadUV3.s2, LoadUV3.s3, LoadUV2.s2, LoadUV2.s3, LoadUV1.s2, LoadUV1.s3);",
"uchar16 StoreUV3 = (uchar16)(LoadUV8.s4, LoadUV8.s5, LoadUV7.s4, LoadUV7.s5, LoadUV6.s4, LoadUV6.s5, LoadUV5.s4, LoadUV5.s5, LoadUV4.s4, LoadUV4.s5, LoadUV3.s4, LoadUV3.s5, LoadUV2.s4, LoadUV2.s5, LoadUV1.s4, LoadUV1.s5);",
"uchar16 StoreUV4 = (uchar16)(LoadUV8.s6, LoadUV8.s7, LoadUV7.s6, LoadUV7.s7, LoadUV6.s6, LoadUV6.s7, LoadUV5.s6, LoadUV5.s7, LoadUV4.s6, LoadUV4.s7, LoadUV3.s6, LoadUV3.s7, LoadUV2.s6, LoadUV2.s7, LoadUV1.s6, LoadUV1.s7);",
"uchar16 StoreUV5 = (uchar16)(LoadUV8.s8, LoadUV8.s9, LoadUV7.s8, LoadUV7.s9, LoadUV6.s8, LoadUV6.s9, LoadUV5.s8, LoadUV5.s9, LoadUV4.s8, LoadUV4.s9, LoadUV3.s8, LoadUV3.s9, LoadUV2.s8, LoadUV2.s9, LoadUV1.s8, LoadUV1.s9);",
"uchar16 StoreUV6 = (uchar16)(LoadUV8.sa, LoadUV8.sb, LoadUV7.sa, LoadUV7.sb, LoadUV6.sa, LoadUV6.sb, LoadUV5.sa, LoadUV5.sb, LoadUV4.sa, LoadUV4.sb, LoadUV3.sa, LoadUV3.sb, LoadUV2.sa, LoadUV2.sb, LoadUV1.sa, LoadUV1.sb);",
"uchar16 StoreUV7 = (uchar16)(LoadUV8.sc, LoadUV8.sd, LoadUV7.sc, LoadUV7.sd, LoadUV6.sc, LoadUV6.sd, LoadUV5.sc, LoadUV5.sd, LoadUV4.sc, LoadUV4.sd, LoadUV3.sc, LoadUV3.sd, LoadUV2.sc, LoadUV2.sd, LoadUV1.sc, LoadUV1.sd);",
"uchar16 StoreUV8 = (uchar16)(LoadUV8.se, LoadUV8.sf, LoadUV7.se, LoadUV7.sf, LoadUV6.se, LoadUV6.sf, LoadUV5.se, LoadUV5.sf, LoadUV4.se, LoadUV4.sf, LoadUV3.se, LoadUV3.sf, LoadUV2.se, LoadUV2.sf, LoadUV1.se, LoadUV1.sf);",
"const int offsetUVS1 = ((get_global_id(0)  << 3)      * Height) + Height - (row << 4) - 16;",
"const int offsetUVS2 = (((get_global_id(0) << 3) + 1) * Height) + Height - (row << 4) - 16;",
"const int offsetUVS3 = (((get_global_id(0) << 3) + 2) * Height) + Height - (row << 4) - 16;",
"const int offsetUVS4 = (((get_global_id(0) << 3) + 3) * Height) + Height - (row << 4) - 16;",
"const int offsetUVS5 = (((get_global_id(0) << 3) + 4) * Height) + Height - (row << 4) - 16;",
"const int offsetUVS6 = (((get_global_id(0) << 3) + 5) * Height) + Height - (row << 4) - 16;",
"const int offsetUVS7 = (((get_global_id(0) << 3) + 6) * Height) + Height - (row << 4) - 16;",
"const int offsetUVS8 = (((get_global_id(0) << 3) + 7) * Height) + Height - (row << 4) - 16;",
"vstore16(StoreUV1, 0, OutBufferUV + offsetUVS1);",
"vstore16(StoreUV2, 0, OutBufferUV + offsetUVS2);",
"vstore16(StoreUV3, 0, OutBufferUV + offsetUVS3);",
"vstore16(StoreUV4, 0, OutBufferUV + offsetUVS4);",
"vstore16(StoreUV5, 0, OutBufferUV + offsetUVS5);",
"vstore16(StoreUV6, 0, OutBufferUV + offsetUVS6);",
"vstore16(StoreUV7, 0, OutBufferUV + offsetUVS7);",
"vstore16(StoreUV8, 0, OutBufferUV + offsetUVS8);",
"const int offsetYL1  = ((row  << 4)       * Width) + column;",
"const int offsetYL2  = (((row << 4) + 1)  * Width) + column;",
"const int offsetYL3  = (((row << 4) + 2)  * Width) + column;",
"const int offsetYL4  = (((row << 4) + 3)  * Width) + column;",
"const int offsetYL5  = (((row << 4) + 4)  * Width) + column;",
"const int offsetYL6  = (((row << 4) + 5)  * Width) + column;",
"const int offsetYL7  = (((row << 4) + 6)  * Width) + column;",
"const int offsetYL8  = (((row << 4) + 7)  * Width) + column;",
"const int offsetYL9  = (((row << 4) + 8)  * Width) + column;",
"const int offsetYL10 = (((row << 4) + 9)  * Width) + column;",
"const int offsetYL11 = (((row << 4) + 10) * Width) + column;",
"const int offsetYL12 = (((row << 4) + 11) * Width) + column;",
"const int offsetYL13 = (((row << 4) + 12) * Width) + column;",
"const int offsetYL14 = (((row << 4) + 13) * Width) + column;",
"const int offsetYL15 = (((row << 4) + 14) * Width) + column;",
"const int offsetYL16 = (((row << 4) + 15) * Width) + column;",	
"uchar16 LoadY1  = vload16(0, InBufferY + offsetYL1);",
"uchar16 LoadY2  = vload16(0, InBufferY + offsetYL2);",
"uchar16 LoadY3  = vload16(0, InBufferY + offsetYL3);",
"uchar16 LoadY4  = vload16(0, InBufferY + offsetYL4);",
"uchar16 LoadY5  = vload16(0, InBufferY + offsetYL5);",
"uchar16 LoadY6  = vload16(0, InBufferY + offsetYL6);",
"uchar16 LoadY7  = vload16(0, InBufferY + offsetYL7);",
"uchar16 LoadY8  = vload16(0, InBufferY + offsetYL8);",
"uchar16 LoadY9  = vload16(0, InBufferY + offsetYL9);",
"uchar16 LoadY10 = vload16(0, InBufferY + offsetYL10);",
"uchar16 LoadY11 = vload16(0, InBufferY + offsetYL11);",
"uchar16 LoadY12 = vload16(0, InBufferY + offsetYL12);",
"uchar16 LoadY13 = vload16(0, InBufferY + offsetYL13);",
"uchar16 LoadY14 = vload16(0, InBufferY + offsetYL14);",
"uchar16 LoadY15 = vload16(0, InBufferY + offsetYL15);",
"uchar16 LoadY16 = vload16(0, InBufferY + offsetYL16);",
"uchar16 StoreY1  = (uchar16)(LoadY16.s0, LoadY15.s0, LoadY14.s0, LoadY13.s0, LoadY12.s0, LoadY11.s0, LoadY10.s0, LoadY9.s0, LoadY8.s0, LoadY7.s0, LoadY6.s0, LoadY5.s0, LoadY4.s0, LoadY3.s0, LoadY2.s0, LoadY1.s0);",
"uchar16 StoreY2  = (uchar16)(LoadY16.s1, LoadY15.s1, LoadY14.s1, LoadY13.s1, LoadY12.s1, LoadY11.s1, LoadY10.s1, LoadY9.s1, LoadY8.s1, LoadY7.s1, LoadY6.s1, LoadY5.s1, LoadY4.s1, LoadY3.s1, LoadY2.s1, LoadY1.s1);",
"uchar16 StoreY3  = (uchar16)(LoadY16.s2, LoadY15.s2, LoadY14.s2, LoadY13.s2, LoadY12.s2, LoadY11.s2, LoadY10.s2, LoadY9.s2, LoadY8.s2, LoadY7.s2, LoadY6.s2, LoadY5.s2, LoadY4.s2, LoadY3.s2, LoadY2.s2, LoadY1.s2);",
"uchar16 StoreY4  = (uchar16)(LoadY16.s3, LoadY15.s3, LoadY14.s3, LoadY13.s3, LoadY12.s3, LoadY11.s3, LoadY10.s3, LoadY9.s3, LoadY8.s3, LoadY7.s3, LoadY6.s3, LoadY5.s3, LoadY4.s3, LoadY3.s3, LoadY2.s3, LoadY1.s3);",
"uchar16 StoreY5  = (uchar16)(LoadY16.s4, LoadY15.s4, LoadY14.s4, LoadY13.s4, LoadY12.s4, LoadY11.s4, LoadY10.s4, LoadY9.s4, LoadY8.s4, LoadY7.s4, LoadY6.s4, LoadY5.s4, LoadY4.s4, LoadY3.s4, LoadY2.s4, LoadY1.s4);",
"uchar16 StoreY6  = (uchar16)(LoadY16.s5, LoadY15.s5, LoadY14.s5, LoadY13.s5, LoadY12.s5, LoadY11.s5, LoadY10.s5, LoadY9.s5, LoadY8.s5, LoadY7.s5, LoadY6.s5, LoadY5.s5, LoadY4.s5, LoadY3.s5, LoadY2.s5, LoadY1.s5);",
"uchar16 StoreY7  = (uchar16)(LoadY16.s6, LoadY15.s6, LoadY14.s6, LoadY13.s6, LoadY12.s6, LoadY11.s6, LoadY10.s6, LoadY9.s6, LoadY8.s6, LoadY7.s6, LoadY6.s6, LoadY5.s6, LoadY4.s6, LoadY3.s6, LoadY2.s6, LoadY1.s6);",
"uchar16 StoreY8  = (uchar16)(LoadY16.s7, LoadY15.s7, LoadY14.s7, LoadY13.s7, LoadY12.s7, LoadY11.s7, LoadY10.s7, LoadY9.s7, LoadY8.s7, LoadY7.s7, LoadY6.s7, LoadY5.s7, LoadY4.s7, LoadY3.s7, LoadY2.s7, LoadY1.s7);",
"uchar16 StoreY9  = (uchar16)(LoadY16.s8, LoadY15.s8, LoadY14.s8, LoadY13.s8, LoadY12.s8, LoadY11.s8, LoadY10.s8, LoadY9.s8, LoadY8.s8, LoadY7.s8, LoadY6.s8, LoadY5.s8, LoadY4.s8, LoadY3.s8, LoadY2.s8, LoadY1.s8);",
"uchar16 StoreY10 = (uchar16)(LoadY16.s9, LoadY15.s9, LoadY14.s9, LoadY13.s9, LoadY12.s9, LoadY11.s9, LoadY10.s9, LoadY9.s9, LoadY8.s9, LoadY7.s9, LoadY6.s9, LoadY5.s9, LoadY4.s9, LoadY3.s9, LoadY2.s9, LoadY1.s9);",
"uchar16 StoreY11 = (uchar16)(LoadY16.sa, LoadY15.sa, LoadY14.sa, LoadY13.sa, LoadY12.sa, LoadY11.sa, LoadY10.sa, LoadY9.sa, LoadY8.sa, LoadY7.sa, LoadY6.sa, LoadY5.sa, LoadY4.sa, LoadY3.sa, LoadY2.sa, LoadY1.sa);",
"uchar16 StoreY12 = (uchar16)(LoadY16.sb, LoadY15.sb, LoadY14.sb, LoadY13.sb, LoadY12.sb, LoadY11.sb, LoadY10.sb, LoadY9.sb, LoadY8.sb, LoadY7.sb, LoadY6.sb, LoadY5.sb, LoadY4.sb, LoadY3.sb, LoadY2.sb, LoadY1.sb);",
"uchar16 StoreY13 = (uchar16)(LoadY16.sc, LoadY15.sc, LoadY14.sc, LoadY13.sc, LoadY12.sc, LoadY11.sc, LoadY10.sc, LoadY9.sc, LoadY8.sc, LoadY7.sc, LoadY6.sc, LoadY5.sc, LoadY4.sc, LoadY3.sc, LoadY2.sc, LoadY1.sc);",
"uchar16 StoreY14 = (uchar16)(LoadY16.sd, LoadY15.sd, LoadY14.sd, LoadY13.sd, LoadY12.sd, LoadY11.sd, LoadY10.sd, LoadY9.sd, LoadY8.sd, LoadY7.sd, LoadY6.sd, LoadY5.sd, LoadY4.sd, LoadY3.sd, LoadY2.sd, LoadY1.sd);",
"uchar16 StoreY15 = (uchar16)(LoadY16.se, LoadY15.se, LoadY14.se, LoadY13.se, LoadY12.se, LoadY11.se, LoadY10.se, LoadY9.se, LoadY8.se, LoadY7.se, LoadY6.se, LoadY5.se, LoadY4.se, LoadY3.se, LoadY2.se, LoadY1.se);",
"uchar16 StoreY16 = (uchar16)(LoadY16.sf, LoadY15.sf, LoadY14.sf, LoadY13.sf, LoadY12.sf, LoadY11.sf, LoadY10.sf, LoadY9.sf, LoadY8.sf, LoadY7.sf, LoadY6.sf, LoadY5.sf, LoadY4.sf, LoadY3.sf, LoadY2.sf, LoadY1.sf);",
"const int offsetYS1  = (column        * Height) + Height - (row << 4) - 16;",
"const int offsetYS2  = ((column + 1)  * Height) + Height - (row << 4) - 16;",
"const int offsetYS3  = ((column + 2)  * Height) + Height - (row << 4) - 16;",
"const int offsetYS4  = ((column + 3)  * Height) + Height - (row << 4) - 16;",
"const int offsetYS5  = ((column + 4)  * Height) + Height - (row << 4) - 16;",
"const int offsetYS6  = ((column + 5)  * Height) + Height - (row << 4) - 16;",
"const int offsetYS7  = ((column + 6)  * Height) + Height - (row << 4) - 16;",
"const int offsetYS8  = ((column + 7)  * Height) + Height - (row << 4) - 16;",
"const int offsetYS9  = ((column + 8)  * Height) + Height - (row << 4) - 16;",
"const int offsetYS10 = ((column + 9)  * Height) + Height - (row << 4) - 16;",
"const int offsetYS11 = ((column + 10) * Height) + Height - (row << 4) - 16;",
"const int offsetYS12 = ((column + 11) * Height) + Height - (row << 4) - 16;",
"const int offsetYS13 = ((column + 12) * Height) + Height - (row << 4) - 16;",
"const int offsetYS14 = ((column + 13) * Height) + Height - (row << 4) - 16;",
"const int offsetYS15 = ((column + 14) * Height) + Height - (row << 4) - 16;",
"const int offsetYS16 = ((column + 15) * Height) + Height - (row << 4) - 16;",
"vstore16(StoreY1,  0, OutBufferY + offsetYS1);",
"vstore16(StoreY2,  0, OutBufferY + offsetYS2);",
"vstore16(StoreY3,  0, OutBufferY + offsetYS3);",
"vstore16(StoreY4,  0, OutBufferY + offsetYS4);",
"vstore16(StoreY5,  0, OutBufferY + offsetYS5);",
"vstore16(StoreY6,  0, OutBufferY + offsetYS6);",
"vstore16(StoreY7,  0, OutBufferY + offsetYS7);",
"vstore16(StoreY8,  0, OutBufferY + offsetYS8);",
"vstore16(StoreY9,  0, OutBufferY + offsetYS9);",
"vstore16(StoreY10, 0, OutBufferY + offsetYS10);",
"vstore16(StoreY11, 0, OutBufferY + offsetYS11);",
"vstore16(StoreY12, 0, OutBufferY + offsetYS12);",
"vstore16(StoreY13, 0, OutBufferY + offsetYS13);",
"vstore16(StoreY14, 0, OutBufferY + offsetYS14);",
"vstore16(StoreY15, 0, OutBufferY + offsetYS15);",
"vstore16(StoreY16, 0, OutBufferY + offsetYS16);",
"}",
"__kernel void RotationSP_180(__global const uchar* restrict InBufferY, __global const uchar* restrict InBufferUV, __global uchar* restrict OutBufferY, __global uchar* restrict OutBufferUV, const int Width, const int Height)",
"{",
"const int column = get_global_id(0) << 4;",
"const int row = get_global_id(1);",
"const int offsetUVL1 = ((row  << 3)      * Width) + column;",
"const int offsetUVL2 = (((row << 3) + 1) * Width) + column;",
"const int offsetUVL3 = (((row << 3) + 2) * Width) + column;",
"const int offsetUVL4 = (((row << 3) + 3) * Width) + column;",
"const int offsetUVL5 = (((row << 3) + 4) * Width) + column;",
"const int offsetUVL6 = (((row << 3) + 5) * Width) + column;",
"const int offsetUVL7 = (((row << 3) + 6) * Width) + column;",
"const int offsetUVL8 = (((row << 3) + 7) * Width) + column;",
"uchar16 LoadUV1 = vload16(0, InBufferUV + offsetUVL1);",
"uchar16 LoadUV2 = vload16(0, InBufferUV + offsetUVL2);",
"uchar16 LoadUV3 = vload16(0, InBufferUV + offsetUVL3);",
"uchar16 LoadUV4 = vload16(0, InBufferUV + offsetUVL4);",
"uchar16 LoadUV5 = vload16(0, InBufferUV + offsetUVL5);",
"uchar16 LoadUV6 = vload16(0, InBufferUV + offsetUVL6);",
"uchar16 LoadUV7 = vload16(0, InBufferUV + offsetUVL7);",
"uchar16 LoadUV8 = vload16(0, InBufferUV + offsetUVL8);",
"uchar16 StoreUV1 = (uchar16)(LoadUV1.se, LoadUV1.sf, LoadUV1.sc, LoadUV1.sd, LoadUV1.sa, LoadUV1.sb, LoadUV1.s8, LoadUV1.s9, LoadUV1.s6, LoadUV1.s7, LoadUV1.s4, LoadUV1.s5, LoadUV1.s2, LoadUV1.s3, LoadUV1.s0, LoadUV1.s1);",
"uchar16 StoreUV2 = (uchar16)(LoadUV2.se, LoadUV2.sf, LoadUV2.sc, LoadUV2.sd, LoadUV2.sa, LoadUV2.sb, LoadUV2.s8, LoadUV2.s9, LoadUV2.s6, LoadUV2.s7, LoadUV2.s4, LoadUV2.s5, LoadUV2.s2, LoadUV2.s3, LoadUV2.s0, LoadUV2.s1);",
"uchar16 StoreUV3 = (uchar16)(LoadUV3.se, LoadUV3.sd, LoadUV3.sc, LoadUV3.sd, LoadUV3.sa, LoadUV3.sb, LoadUV3.s8, LoadUV3.s9, LoadUV3.s6, LoadUV3.s7, LoadUV3.s4, LoadUV3.s5, LoadUV3.s2, LoadUV3.s3, LoadUV3.s0, LoadUV3.s1);",
"uchar16 StoreUV4 = (uchar16)(LoadUV4.se, LoadUV4.sf, LoadUV4.sc, LoadUV4.sd, LoadUV4.sa, LoadUV4.sb, LoadUV4.s8, LoadUV4.s9, LoadUV4.s6, LoadUV4.s7, LoadUV4.s4, LoadUV4.s5, LoadUV4.s2, LoadUV4.s3, LoadUV4.s0, LoadUV4.s1);",
"uchar16 StoreUV5 = (uchar16)(LoadUV5.se, LoadUV5.sf, LoadUV5.sc, LoadUV5.sd, LoadUV5.sa, LoadUV5.sb, LoadUV5.s8, LoadUV5.s9, LoadUV5.s6, LoadUV5.s7, LoadUV5.s4, LoadUV5.s5, LoadUV5.s2, LoadUV5.s3, LoadUV5.s0, LoadUV5.s1);",
"uchar16 StoreUV6 = (uchar16)(LoadUV6.se, LoadUV6.sf, LoadUV6.sc, LoadUV6.sd, LoadUV6.sa, LoadUV6.sb, LoadUV6.s8, LoadUV6.s9, LoadUV6.s6, LoadUV6.s7, LoadUV6.s4, LoadUV6.s5, LoadUV6.s2, LoadUV6.s3, LoadUV6.s0, LoadUV6.s1);",
"uchar16 StoreUV7 = (uchar16)(LoadUV7.se, LoadUV7.sf, LoadUV7.sc, LoadUV7.sd, LoadUV7.sa, LoadUV7.sb, LoadUV7.s8, LoadUV7.s9, LoadUV7.s6, LoadUV7.s7, LoadUV7.s4, LoadUV7.s5, LoadUV7.s2, LoadUV7.s3, LoadUV7.s0, LoadUV7.s1);",
"uchar16 StoreUV8 = (uchar16)(LoadUV8.se, LoadUV8.sf, LoadUV8.sc, LoadUV8.sd, LoadUV8.sa, LoadUV8.sb, LoadUV8.s8, LoadUV8.s9, LoadUV8.s6, LoadUV8.s7, LoadUV8.s4, LoadUV8.s5, LoadUV8.s2, LoadUV8.s3, LoadUV8.s0, LoadUV8.s1);",
"const int offsetUVS1 = (((Height >> 1) - (row << 3) - 1) * Width) + Width - column - 16;",
"const int offsetUVS2 = (((Height >> 1) - (row << 3) - 2) * Width) + Width - column - 16;",
"const int offsetUVS3 = (((Height >> 1) - (row << 3) - 3) * Width) + Width - column - 16;",
"const int offsetUVS4 = (((Height >> 1) - (row << 3) - 4) * Width) + Width - column - 16;",
"const int offsetUVS5 = (((Height >> 1) - (row << 3) - 5) * Width) + Width - column - 16;",
"const int offsetUVS6 = (((Height >> 1) - (row << 3) - 6) * Width) + Width - column - 16;",
"const int offsetUVS7 = (((Height >> 1) - (row << 3) - 7) * Width) + Width - column - 16;",
"const int offsetUVS8 = (((Height >> 1) - (row << 3) - 8) * Width) + Width - column - 16;",
"vstore16(StoreUV1, 0, OutBufferUV + offsetUVS1);",
"vstore16(StoreUV2, 0, OutBufferUV + offsetUVS2);",
"vstore16(StoreUV3, 0, OutBufferUV + offsetUVS3);",
"vstore16(StoreUV4, 0, OutBufferUV + offsetUVS4);",
"vstore16(StoreUV5, 0, OutBufferUV + offsetUVS5);",
"vstore16(StoreUV6, 0, OutBufferUV + offsetUVS6);",
"vstore16(StoreUV7, 0, OutBufferUV + offsetUVS7);",
"vstore16(StoreUV8, 0, OutBufferUV + offsetUVS8);",
"const int offsetYL1  = ((row  << 4)       * Width) + column;",
"const int offsetYL2  = (((row << 4) +  1) * Width) + column;",
"const int offsetYL3  = (((row << 4) +  2) * Width) + column;",
"const int offsetYL4  = (((row << 4) +  3) * Width) + column;",
"const int offsetYL5  = (((row << 4) +  4) * Width) + column;",
"const int offsetYL6  = (((row << 4) +  5) * Width) + column;",
"const int offsetYL7  = (((row << 4) +  6) * Width) + column;",
"const int offsetYL8  = (((row << 4) +  7) * Width) + column;",
"const int offsetYL9  = (((row << 4) +  8) * Width) + column;",
"const int offsetYL10 = (((row << 4) +  9) * Width) + column;",
"const int offsetYL11 = (((row << 4) + 10) * Width) + column;",
"const int offsetYL12 = (((row << 4) + 11) * Width) + column;",
"const int offsetYL13 = (((row << 4) + 12) * Width) + column;",
"const int offsetYL14 = (((row << 4) + 13) * Width) + column;",
"const int offsetYL15 = (((row << 4) + 14) * Width) + column;",
"const int offsetYL16 = (((row << 4) + 15) * Width) + column;",
"uchar16 LoadY1  = vload16(0, InBufferY + offsetYL1);",
"uchar16 LoadY2  = vload16(0, InBufferY + offsetYL2);",
"uchar16 LoadY3  = vload16(0, InBufferY + offsetYL3);",
"uchar16 LoadY4  = vload16(0, InBufferY + offsetYL4);",
"uchar16 LoadY5  = vload16(0, InBufferY + offsetYL5);",
"uchar16 LoadY6  = vload16(0, InBufferY + offsetYL6);",
"uchar16 LoadY7  = vload16(0, InBufferY + offsetYL7);",
"uchar16 LoadY8  = vload16(0, InBufferY + offsetYL8);",
"uchar16 LoadY9  = vload16(0, InBufferY + offsetYL9);",
"uchar16 LoadY10 = vload16(0, InBufferY + offsetYL10);",
"uchar16 LoadY11 = vload16(0, InBufferY + offsetYL11);",
"uchar16 LoadY12 = vload16(0, InBufferY + offsetYL12);",
"uchar16 LoadY13 = vload16(0, InBufferY + offsetYL13);",
"uchar16 LoadY14 = vload16(0, InBufferY + offsetYL14);",
"uchar16 LoadY15 = vload16(0, InBufferY + offsetYL15);",
"uchar16 LoadY16 = vload16(0, InBufferY + offsetYL16);",
"uchar16 StoreY1  = (uchar16)(LoadY16.sf, LoadY16.se, LoadY16.sd, LoadY16.sc, LoadY16.sb, LoadY16.sa, LoadY16.s9, LoadY16.s8, LoadY16.s7, LoadY16.s6, LoadY16.s5, LoadY16.s4, LoadY16.s3, LoadY16.s2, LoadY16.s1, LoadY16.s0);",
"uchar16 StoreY2  = (uchar16)(LoadY15.sf, LoadY15.se, LoadY15.sd, LoadY15.sc, LoadY15.sb, LoadY15.sa, LoadY15.s9, LoadY15.s8, LoadY15.s7, LoadY15.s6, LoadY15.s5, LoadY15.s4, LoadY15.s3, LoadY15.s2, LoadY15.s1, LoadY15.s0);",
"uchar16 StoreY3  = (uchar16)(LoadY14.sf, LoadY14.se, LoadY14.sd, LoadY14.sc, LoadY14.sb, LoadY14.sa, LoadY14.s9, LoadY14.s8, LoadY14.s7, LoadY14.s6, LoadY14.s5, LoadY14.s4, LoadY14.s3, LoadY14.s2, LoadY14.s1, LoadY14.s0);",
"uchar16 StoreY4  = (uchar16)(LoadY13.sf, LoadY13.se, LoadY13.sd, LoadY13.sc, LoadY13.sb, LoadY13.sa, LoadY13.s9, LoadY13.s8, LoadY13.s7, LoadY13.s6, LoadY13.s5, LoadY13.s4, LoadY13.s3, LoadY13.s2, LoadY13.s1, LoadY13.s0);",
"uchar16 StoreY5  = (uchar16)(LoadY12.sf, LoadY12.se, LoadY12.sd, LoadY12.sc, LoadY12.sb, LoadY12.sa, LoadY12.s9, LoadY12.s8, LoadY12.s7, LoadY12.s6, LoadY12.s5, LoadY12.s4, LoadY12.s3, LoadY12.s2, LoadY12.s1, LoadY12.s0);",
"uchar16 StoreY6  = (uchar16)(LoadY11.sf, LoadY11.se, LoadY11.sd, LoadY11.sc, LoadY11.sb, LoadY11.sa, LoadY11.s9, LoadY11.s8, LoadY11.s7, LoadY11.s6, LoadY11.s5, LoadY11.s4, LoadY11.s3, LoadY11.s2, LoadY11.s1, LoadY11.s0);",
"uchar16 StoreY7  = (uchar16)(LoadY10.sf, LoadY10.se, LoadY10.sd, LoadY10.sc, LoadY10.sb, LoadY10.sa, LoadY10.s9, LoadY10.s8, LoadY10.s7, LoadY10.s6, LoadY10.s5, LoadY10.s4, LoadY10.s3, LoadY10.s2, LoadY10.s1, LoadY10.s0);",
"uchar16 StoreY8  = (uchar16)( LoadY9.sf,  LoadY9.se,  LoadY9.sd,  LoadY9.sc,  LoadY9.sb,  LoadY9.sa,  LoadY9.s9,  LoadY9.s8,  LoadY9.s7,  LoadY9.s6,  LoadY9.s5,  LoadY9.s4,  LoadY9.s3,  LoadY9.s2,  LoadY9.s1,  LoadY9.s0);",
"uchar16 StoreY9  = (uchar16)( LoadY8.sf,  LoadY8.se,  LoadY8.sd,  LoadY8.sc,  LoadY8.sb,  LoadY8.sa,  LoadY8.s9,  LoadY8.s8,  LoadY8.s7,  LoadY8.s6,  LoadY8.s5,  LoadY8.s4,  LoadY8.s3,  LoadY8.s2,  LoadY8.s1,  LoadY8.s0);",
"uchar16 StoreY10 = (uchar16)( LoadY7.sf,  LoadY7.se,  LoadY7.sd,  LoadY7.sc,  LoadY7.sb,  LoadY7.sa,  LoadY7.s9,  LoadY7.s8,  LoadY7.s7,  LoadY7.s6,  LoadY7.s5,  LoadY7.s4,  LoadY7.s3,  LoadY7.s2,  LoadY7.s1,  LoadY7.s0);",
"uchar16 StoreY11 = (uchar16)( LoadY6.sf,  LoadY6.se,  LoadY6.sd,  LoadY6.sc,  LoadY6.sb,  LoadY6.sa,  LoadY6.s9,  LoadY6.s8,  LoadY6.s7,  LoadY6.s6,  LoadY6.s5,  LoadY6.s4,  LoadY6.s3,  LoadY6.s2,  LoadY6.s1,  LoadY6.s0);",
"uchar16 StoreY12 = (uchar16)( LoadY5.sf,  LoadY5.se,  LoadY5.sd,  LoadY5.sc,  LoadY5.sb,  LoadY5.sa,  LoadY5.s9,  LoadY5.s8,  LoadY5.s7,  LoadY5.s6,  LoadY5.s5,  LoadY5.s4,  LoadY5.s3,  LoadY5.s2,  LoadY5.s1,  LoadY5.s0);",
"uchar16 StoreY13 = (uchar16)( LoadY4.sf,  LoadY4.se,  LoadY4.sd,  LoadY4.sc,  LoadY4.sb,  LoadY4.sa,  LoadY4.s9,  LoadY4.s8,  LoadY4.s7,  LoadY4.s6,  LoadY4.s5,  LoadY4.s4,  LoadY4.s3,  LoadY4.s2,  LoadY4.s1,  LoadY4.s0);",
"uchar16 StoreY14 = (uchar16)( LoadY3.sf,  LoadY3.se,  LoadY3.sd,  LoadY3.sc,  LoadY3.sb,  LoadY3.sa,  LoadY3.s9,  LoadY3.s8,  LoadY3.s7,  LoadY3.s6,  LoadY3.s5,  LoadY3.s4,  LoadY3.s3,  LoadY3.s2,  LoadY3.s1,  LoadY3.s0);",
"uchar16 StoreY15 = (uchar16)( LoadY2.sf,  LoadY2.se,  LoadY2.sd,  LoadY2.sc,  LoadY2.sb,  LoadY2.sa,  LoadY2.s9,  LoadY2.s8,  LoadY2.s7,  LoadY2.s6,  LoadY2.s5,  LoadY2.s4,  LoadY2.s3,  LoadY2.s2,  LoadY2.s1,  LoadY2.s0);",
"uchar16 StoreY16 = (uchar16)( LoadY1.sf,  LoadY1.se,  LoadY1.sd,  LoadY1.sc,  LoadY1.sb,  LoadY1.sa,  LoadY1.s9,  LoadY1.s8,  LoadY1.s7,  LoadY1.s6,  LoadY1.s5,  LoadY1.s4,  LoadY1.s3,  LoadY1.s2,  LoadY1.s1,  LoadY1.s0);",
"const int offsetYS1  = (Height - (row << 4) - 16) * Width + Width - column - 16;",
"const int offsetYS2  = (Height - (row << 4) - 15) * Width + Width - column - 16;",
"const int offsetYS3  = (Height - (row << 4) - 14) * Width + Width - column - 16;",
"const int offsetYS4  = (Height - (row << 4) - 13) * Width + Width - column - 16;",
"const int offsetYS5  = (Height - (row << 4) - 12) * Width + Width - column - 16;",
"const int offsetYS6  = (Height - (row << 4) - 11) * Width + Width - column - 16;",
"const int offsetYS7  = (Height - (row << 4) - 10) * Width + Width - column - 16;",
"const int offsetYS8  = (Height - (row << 4) - 9)  * Width + Width - column - 16;",
"const int offsetYS9  = (Height - (row << 4) - 8)  * Width + Width - column - 16;",
"const int offsetYS10 = (Height - (row << 4) - 7)  * Width + Width - column - 16;",
"const int offsetYS11 = (Height - (row << 4) - 6)  * Width + Width - column - 16;",
"const int offsetYS12 = (Height - (row << 4) - 5)  * Width + Width - column - 16;",
"const int offsetYS13 = (Height - (row << 4) - 4)  * Width + Width - column - 16;",
"const int offsetYS14 = (Height - (row << 4) - 3)  * Width + Width - column - 16;",
"const int offsetYS15 = (Height - (row << 4) - 2)  * Width + Width - column - 16;",
"const int offsetYS16 = (Height - (row << 4) - 1)  * Width + Width - column - 16;",
"vstore16(StoreY1,  0, OutBufferY + offsetYS1);",
"vstore16(StoreY2,  0, OutBufferY + offsetYS2);",
"vstore16(StoreY3,  0, OutBufferY + offsetYS3);",
"vstore16(StoreY4,  0, OutBufferY + offsetYS4);",
"vstore16(StoreY5,  0, OutBufferY + offsetYS5);",
"vstore16(StoreY6,  0, OutBufferY + offsetYS6);",
"vstore16(StoreY7,  0, OutBufferY + offsetYS7);",
"vstore16(StoreY8,  0, OutBufferY + offsetYS8);",
"vstore16(StoreY9,  0, OutBufferY + offsetYS9);",
"vstore16(StoreY10, 0, OutBufferY + offsetYS10);",
"vstore16(StoreY11, 0, OutBufferY + offsetYS11);",
"vstore16(StoreY12, 0, OutBufferY + offsetYS12);",
"vstore16(StoreY13, 0, OutBufferY + offsetYS13);",
"vstore16(StoreY14, 0, OutBufferY + offsetYS14);",
"vstore16(StoreY15, 0, OutBufferY + offsetYS15);",
"vstore16(StoreY16, 0, OutBufferY + offsetYS16);",
"}",
"__kernel void RotationSP_270(__global const uchar* restrict InBufferY, __global const uchar* restrict InBufferUV, __global uchar* restrict OutBufferY, __global uchar* restrict OutBufferUV, const int Width, const int Height)",
"{",
"const int column = get_global_id(0) << 4;",
"const int row = get_global_id(1);",
"const int offsetUVL1 = (( row << 3)      * Width) + column;",
"const int offsetUVL2 = (((row << 3) + 1) * Width) + column;",
"const int offsetUVL3 = (((row << 3) + 2) * Width) + column;",
"const int offsetUVL4 = (((row << 3) + 3) * Width) + column;",
"const int offsetUVL5 = (((row << 3) + 4) * Width) + column;",
"const int offsetUVL6 = (((row << 3) + 5) * Width) + column;",
"const int offsetUVL7 = (((row << 3) + 6) * Width) + column;",
"const int offsetUVL8 = (((row << 3) + 7) * Width) + column;",
"uchar16 LoadUV1 = vload16(0, InBufferUV + offsetUVL1);",
"uchar16 LoadUV2 = vload16(0, InBufferUV + offsetUVL2);",
"uchar16 LoadUV3 = vload16(0, InBufferUV + offsetUVL3);",
"uchar16 LoadUV4 = vload16(0, InBufferUV + offsetUVL4);",
"uchar16 LoadUV5 = vload16(0, InBufferUV + offsetUVL5);",
"uchar16 LoadUV6 = vload16(0, InBufferUV + offsetUVL6);",
"uchar16 LoadUV7 = vload16(0, InBufferUV + offsetUVL7);",
"uchar16 LoadUV8 = vload16(0, InBufferUV + offsetUVL8);",
"uchar16 StoreUV1 = (uchar16)(LoadUV1.s0, LoadUV1.s1, LoadUV2.s0, LoadUV2.s1, LoadUV3.s0, LoadUV3.s1, LoadUV4.s0, LoadUV4.s1, LoadUV5.s0, LoadUV5.s1, LoadUV6.s0, LoadUV6.s1, LoadUV7.s0, LoadUV7.s1, LoadUV8.s0, LoadUV8.s1);",
"uchar16 StoreUV2 = (uchar16)(LoadUV1.s2, LoadUV1.s3, LoadUV2.s2, LoadUV2.s3, LoadUV3.s2, LoadUV3.s3, LoadUV4.s2, LoadUV4.s3, LoadUV5.s2, LoadUV5.s3, LoadUV6.s2, LoadUV6.s3, LoadUV7.s2, LoadUV7.s3, LoadUV8.s2, LoadUV8.s3);",
"uchar16 StoreUV3 = (uchar16)(LoadUV1.s4, LoadUV1.s5, LoadUV2.s4, LoadUV2.s5, LoadUV3.s4, LoadUV3.s5, LoadUV4.s4, LoadUV4.s5, LoadUV5.s4, LoadUV5.s5, LoadUV6.s4, LoadUV6.s5, LoadUV7.s4, LoadUV7.s5, LoadUV8.s4, LoadUV8.s5);",
"uchar16 StoreUV4 = (uchar16)(LoadUV1.s6, LoadUV1.s7, LoadUV2.s6, LoadUV2.s7, LoadUV3.s6, LoadUV3.s7, LoadUV4.s6, LoadUV4.s7, LoadUV5.s6, LoadUV5.s7, LoadUV6.s6, LoadUV6.s7, LoadUV7.s6, LoadUV7.s7, LoadUV8.s6, LoadUV8.s7);",
"uchar16 StoreUV5 = (uchar16)(LoadUV1.s8, LoadUV1.s9, LoadUV2.s8, LoadUV2.s9, LoadUV3.s8, LoadUV3.s9, LoadUV4.s8, LoadUV4.s9, LoadUV5.s8, LoadUV5.s9, LoadUV6.s8, LoadUV6.s9, LoadUV7.s8, LoadUV7.s9, LoadUV8.s8, LoadUV8.s9);",
"uchar16 StoreUV6 = (uchar16)(LoadUV1.sa, LoadUV1.sb, LoadUV2.sa, LoadUV2.sb, LoadUV3.sa, LoadUV3.sb, LoadUV4.sa, LoadUV4.sb, LoadUV5.sa, LoadUV5.sb, LoadUV6.sa, LoadUV6.sb, LoadUV7.sa, LoadUV7.sb, LoadUV8.sa, LoadUV8.sb);",
"uchar16 StoreUV7 = (uchar16)(LoadUV1.sc, LoadUV1.sd, LoadUV2.sc, LoadUV2.sd, LoadUV3.sc, LoadUV3.sd, LoadUV4.sc, LoadUV4.sd, LoadUV5.sc, LoadUV5.sd, LoadUV6.sc, LoadUV6.sd, LoadUV7.sc, LoadUV7.sd, LoadUV8.sc, LoadUV8.sd);",
"uchar16 StoreUV8 = (uchar16)(LoadUV1.se, LoadUV1.sf, LoadUV2.se, LoadUV2.sf, LoadUV3.se, LoadUV3.sf, LoadUV4.se, LoadUV4.sf, LoadUV5.se, LoadUV5.sf, LoadUV6.se, LoadUV6.sf, LoadUV7.se, LoadUV7.sf, LoadUV8.se, LoadUV8.sf);",
"const int offsetUVS1 = (((Width >> 1) - (get_global_id(0) << 3) - 1)) * Height + (row << 4);",
"const int offsetUVS2 = (((Width >> 1) - (get_global_id(0) << 3) - 2)) * Height + (row << 4);",
"const int offsetUVS3 = (((Width >> 1) - (get_global_id(0) << 3) - 3)) * Height + (row << 4);",
"const int offsetUVS4 = (((Width >> 1) - (get_global_id(0) << 3) - 4)) * Height + (row << 4);",
"const int offsetUVS5 = (((Width >> 1) - (get_global_id(0) << 3) - 5)) * Height + (row << 4);",
"const int offsetUVS6 = (((Width >> 1) - (get_global_id(0) << 3) - 6)) * Height + (row << 4);",
"const int offsetUVS7 = (((Width >> 1) - (get_global_id(0) << 3) - 7)) * Height + (row << 4);",
"const int offsetUVS8 = (((Width >> 1) - (get_global_id(0) << 3) - 8)) * Height + (row << 4);",
"vstore16(StoreUV1, 0, OutBufferUV + offsetUVS1);",
"vstore16(StoreUV2, 0, OutBufferUV + offsetUVS2);",
"vstore16(StoreUV3, 0, OutBufferUV + offsetUVS3);",
"vstore16(StoreUV4, 0, OutBufferUV + offsetUVS4);",
"vstore16(StoreUV5, 0, OutBufferUV + offsetUVS5);",
"vstore16(StoreUV6, 0, OutBufferUV + offsetUVS6);",
"vstore16(StoreUV7, 0, OutBufferUV + offsetUVS7);",
"vstore16(StoreUV8, 0, OutBufferUV + offsetUVS8);",
"const int offsetYL1  = ((row  << 4)       * Width) + column;",
"const int offsetYL2  = (((row << 4) +  1) * Width) + column;",
"const int offsetYL3  = (((row << 4) +  2) * Width) + column;",
"const int offsetYL4  = (((row << 4) +  3) * Width) + column;",
"const int offsetYL5  = (((row << 4) +  4) * Width) + column;",
"const int offsetYL6  = (((row << 4) +  5) * Width) + column;",
"const int offsetYL7  = (((row << 4) +  6) * Width) + column;",
"const int offsetYL8  = (((row << 4) +  7) * Width) + column;",
"const int offsetYL9  = (((row << 4) +  8) * Width) + column;",
"const int offsetYL10 = (((row << 4) +  9) * Width) + column;",
"const int offsetYL11 = (((row << 4) + 10) * Width) + column;",
"const int offsetYL12 = (((row << 4) + 11) * Width) + column;",
"const int offsetYL13 = (((row << 4) + 12) * Width) + column;",
"const int offsetYL14 = (((row << 4) + 13) * Width) + column;",
"const int offsetYL15 = (((row << 4) + 14) * Width) + column;",
"const int offsetYL16 = (((row << 4) + 15) * Width) + column;",
"uchar16 LoadY1  = vload16(0, InBufferY + offsetYL1);",
"uchar16 LoadY2  = vload16(0, InBufferY + offsetYL2);",
"uchar16 LoadY3  = vload16(0, InBufferY + offsetYL3);",
"uchar16 LoadY4  = vload16(0, InBufferY + offsetYL4);",
"uchar16 LoadY5  = vload16(0, InBufferY + offsetYL5);",
"uchar16 LoadY6  = vload16(0, InBufferY + offsetYL6);",
"uchar16 LoadY7  = vload16(0, InBufferY + offsetYL7);",
"uchar16 LoadY8  = vload16(0, InBufferY + offsetYL8);",
"uchar16 LoadY9  = vload16(0, InBufferY + offsetYL9);",
"uchar16 LoadY10 = vload16(0, InBufferY + offsetYL10);",
"uchar16 LoadY11 = vload16(0, InBufferY + offsetYL11);",
"uchar16 LoadY12 = vload16(0, InBufferY + offsetYL12);",
"uchar16 LoadY13 = vload16(0, InBufferY + offsetYL13);",
"uchar16 LoadY14 = vload16(0, InBufferY + offsetYL14);",
"uchar16 LoadY15 = vload16(0, InBufferY + offsetYL15);",
"uchar16 LoadY16 = vload16(0, InBufferY + offsetYL16);",
"uchar16 StoreY1  = (uchar16)(LoadY1.s0, LoadY2.s0, LoadY3.s0, LoadY4.s0, LoadY5.s0, LoadY6.s0, LoadY7.s0, LoadY8.s0, LoadY9.s0, LoadY10.s0, LoadY11.s0, LoadY12.s0, LoadY13.s0, LoadY14.s0, LoadY15.s0, LoadY16.s0);",
"uchar16 StoreY2  = (uchar16)(LoadY1.s1, LoadY2.s1, LoadY3.s1, LoadY4.s1, LoadY5.s1, LoadY6.s1, LoadY7.s1, LoadY8.s1, LoadY9.s1, LoadY10.s1, LoadY11.s1, LoadY12.s1, LoadY13.s1, LoadY14.s1, LoadY15.s1, LoadY16.s1);",
"uchar16 StoreY3  = (uchar16)(LoadY1.s2, LoadY2.s2, LoadY3.s2, LoadY4.s2, LoadY5.s2, LoadY6.s2, LoadY7.s2, LoadY8.s2, LoadY9.s2, LoadY10.s2, LoadY11.s2, LoadY12.s2, LoadY13.s2, LoadY14.s2, LoadY15.s2, LoadY16.s2);",
"uchar16 StoreY4  = (uchar16)(LoadY1.s3, LoadY2.s3, LoadY3.s3, LoadY4.s3, LoadY5.s3, LoadY6.s3, LoadY7.s3, LoadY8.s3, LoadY9.s3, LoadY10.s3, LoadY11.s3, LoadY12.s3, LoadY13.s3, LoadY14.s3, LoadY15.s3, LoadY16.s3);",
"uchar16 StoreY5  = (uchar16)(LoadY1.s4, LoadY2.s4, LoadY3.s4, LoadY4.s4, LoadY5.s4, LoadY6.s4, LoadY7.s4, LoadY8.s4, LoadY9.s4, LoadY10.s4, LoadY11.s4, LoadY12.s4, LoadY13.s4, LoadY14.s4, LoadY15.s4, LoadY16.s4);",
"uchar16 StoreY6  = (uchar16)(LoadY1.s5, LoadY2.s5, LoadY3.s5, LoadY4.s5, LoadY5.s5, LoadY6.s5, LoadY7.s5, LoadY8.s5, LoadY9.s5, LoadY10.s5, LoadY11.s5, LoadY12.s5, LoadY13.s5, LoadY14.s5, LoadY15.s5, LoadY16.s5);",
"uchar16 StoreY7  = (uchar16)(LoadY1.s6, LoadY2.s6, LoadY3.s6, LoadY4.s6, LoadY5.s6, LoadY6.s6, LoadY7.s6, LoadY8.s6, LoadY9.s6, LoadY10.s6, LoadY11.s6, LoadY12.s6, LoadY13.s6, LoadY14.s6, LoadY15.s6, LoadY16.s6);",
"uchar16 StoreY8  = (uchar16)(LoadY1.s7, LoadY2.s7, LoadY3.s7, LoadY4.s7, LoadY5.s7, LoadY6.s7, LoadY7.s7, LoadY8.s7, LoadY9.s7, LoadY10.s7, LoadY11.s7, LoadY12.s7, LoadY13.s7, LoadY14.s7, LoadY15.s7, LoadY16.s7);",
"uchar16 StoreY9  = (uchar16)(LoadY1.s8, LoadY2.s8, LoadY3.s0, LoadY4.s8, LoadY5.s8, LoadY6.s8, LoadY7.s8, LoadY8.s8, LoadY9.s8, LoadY10.s8, LoadY11.s8, LoadY12.s8, LoadY13.s8, LoadY14.s8, LoadY15.s8, LoadY16.s8);",
"uchar16 StoreY10 = (uchar16)(LoadY1.s9, LoadY2.s9, LoadY3.s9, LoadY4.s9, LoadY5.s9, LoadY6.s9, LoadY7.s9, LoadY8.s9, LoadY9.s9, LoadY10.s9, LoadY11.s9, LoadY12.s9, LoadY13.s9, LoadY14.s9, LoadY15.s9, LoadY16.s9);",
"uchar16 StoreY11 = (uchar16)(LoadY1.sa, LoadY2.sa, LoadY3.sa, LoadY4.sa, LoadY5.sa, LoadY6.sa, LoadY7.sa, LoadY8.sa, LoadY9.sa, LoadY10.sa, LoadY11.sa, LoadY12.sa, LoadY13.sa, LoadY14.sa, LoadY15.sa, LoadY16.sa);",
"uchar16 StoreY12 = (uchar16)(LoadY1.sb, LoadY2.sb, LoadY3.sb, LoadY4.sb, LoadY5.sb, LoadY6.sb, LoadY7.sb, LoadY8.sb, LoadY9.sb, LoadY10.sb, LoadY11.sb, LoadY12.sb, LoadY13.sb, LoadY14.sb, LoadY15.sb, LoadY16.sb);",
"uchar16 StoreY13 = (uchar16)(LoadY1.sc, LoadY2.sc, LoadY3.sc, LoadY4.sc, LoadY5.sc, LoadY6.sc, LoadY7.sc, LoadY8.sc, LoadY9.sc, LoadY10.sc, LoadY11.sc, LoadY12.sc, LoadY13.sc, LoadY14.sc, LoadY15.sc, LoadY16.sc);",
"uchar16 StoreY14 = (uchar16)(LoadY1.sd, LoadY2.sd, LoadY3.sd, LoadY4.sd, LoadY5.sd, LoadY6.sd, LoadY7.sd, LoadY8.sd, LoadY9.sd, LoadY10.sd, LoadY11.sd, LoadY12.sd, LoadY13.sd, LoadY14.sd, LoadY15.sd, LoadY16.sd);",
"uchar16 StoreY15 = (uchar16)(LoadY1.se, LoadY2.se, LoadY3.se, LoadY4.se, LoadY5.se, LoadY6.se, LoadY7.se, LoadY8.se, LoadY9.se, LoadY10.se, LoadY11.se, LoadY12.se, LoadY13.se, LoadY14.se, LoadY15.se, LoadY16.se);",
"uchar16 StoreY16 = (uchar16)(LoadY1.sf, LoadY2.sf, LoadY3.sf, LoadY4.sf, LoadY5.sf, LoadY6.sf, LoadY7.sf, LoadY8.sf, LoadY9.sf, LoadY10.sf, LoadY11.sf, LoadY12.sf, LoadY13.sf, LoadY14.sf, LoadY15.sf, LoadY16.sf);",
"const int offsetYS1  = ((Width - column -  1) * Height) + (row << 4);",
"const int offsetYS2  = ((Width - column -  2) * Height) + (row << 4);",
"const int offsetYS3  = ((Width - column -  3) * Height) + (row << 4);",
"const int offsetYS4  = ((Width - column -  4) * Height) + (row << 4);",
"const int offsetYS5  = ((Width - column -  5) * Height) + (row << 4);",
"const int offsetYS6  = ((Width - column -  6) * Height) + (row << 4);",
"const int offsetYS7  = ((Width - column -  7) * Height) + (row << 4);",
"const int offsetYS8  = ((Width - column -  8) * Height) + (row << 4);",
"const int offsetYS9  = ((Width - column -  9) * Height) + (row << 4);",
"const int offsetYS10 = ((Width - column - 10) * Height) + (row << 4);",
"const int offsetYS11 = ((Width - column - 11) * Height) + (row << 4);",
"const int offsetYS12 = ((Width - column - 12) * Height) + (row << 4);",
"const int offsetYS13 = ((Width - column - 13) * Height) + (row << 4);",
"const int offsetYS14 = ((Width - column - 14) * Height) + (row << 4);",
"const int offsetYS15 = ((Width - column - 15) * Height) + (row << 4);",
"const int offsetYS16 = ((Width - column - 16) * Height) + (row << 4);",
"vstore16(StoreY1,  0, OutBufferY + offsetYS1);",
"vstore16(StoreY2,  0, OutBufferY + offsetYS2);",
"vstore16(StoreY3,  0, OutBufferY + offsetYS3);",
"vstore16(StoreY4,  0, OutBufferY + offsetYS4);",
"vstore16(StoreY5,  0, OutBufferY + offsetYS5);",
"vstore16(StoreY6,  0, OutBufferY + offsetYS6);",
"vstore16(StoreY7,  0, OutBufferY + offsetYS7);",
"vstore16(StoreY8,  0, OutBufferY + offsetYS8);",
"vstore16(StoreY9,  0, OutBufferY + offsetYS9);",
"vstore16(StoreY10, 0, OutBufferY + offsetYS10);",
"vstore16(StoreY11, 0, OutBufferY + offsetYS11);",
"vstore16(StoreY12, 0, OutBufferY + offsetYS12);",
"vstore16(StoreY13, 0, OutBufferY + offsetYS13);",
"vstore16(StoreY14, 0, OutBufferY + offsetYS14);",
"vstore16(StoreY15, 0, OutBufferY + offsetYS15);",
"vstore16(StoreY16, 0, OutBufferY + offsetYS16);",
"}"
};

struct Variable
{
	//ƽ̨����
	cl_platform_id platform;
	
	//�豸����
	cl_device_id device;
	
	//����������
	cl_context context;
	
	//�����������
	cl_program program;
	
	//��������kernel����
	cl_kernel kernel_scaling_P, kernel_scaling_SP, kernel_rotationP_90, kernel_rotationP_180, kernel_rotationP_270, kernel_rotationSP_90, kernel_rotationSP_180, kernel_rotationSP_270;
	
	//�����������
	cl_command_queue queue;
	
	//�����������ͼ�����
	cl_mem InImageY, InImageU, InImageV, InImageUV;
	cl_mem OutScalingImageY, OutScalingImageU, OutScalingImageV, OutScalingImageUV;
	
	//�����������Buffer����
    cl_mem InBufferY,  InBufferUV,  InBufferU,  InBufferV;
	cl_mem OutBufferY, OutBufferUV, OutBufferU, OutBufferV;
};

/**********************************************************************
�������ܣ� �˺����ǹ��캯������Ҫ������ر����ĳ�ʼ��
���룺     ��
�����     ��
***********************************************************************/
ScalingRotation::ScalingRotation(int Width, int Height, int newWidth, int newHeight)
{
	
	widthNormalizationFactor = 1.0f / newWidth;
    heightNormalizationFactor = 1.0f / newHeight;
	
	vab = (Variable *)malloc(sizeof(Variable));
	
	//�����־λ
	cl_int status;
	
	//��ѯ����ƽ̨
	status = clGetPlatformIDs(1, &(((Variable *)vab)->platform), NULL);
	CheckError(status);
	 
	//��ѯ�����豸
    status = clGetDeviceIDs((((Variable *)vab)->platform), CL_DEVICE_TYPE_GPU, 1, &(((Variable *)vab)->device), NULL);
	CheckError(status);
	
	(((Variable *)vab)->context) = clCreateContext(NULL, 1, &(((Variable *)vab)->device), NULL, NULL, &status);
	CheckError(status);
	
	(((Variable *)vab)->program) = clCreateProgramWithSource((((Variable *)vab)->context), 876, OpenCLSource, NULL,&status);
    CheckError(status);
	
	//����������
	//const char options[] = " -cl-fast-relaxed-math ";
	const char options[] = "-cl-fast-relaxed-math -cl-mad-enable -cl-single-precision-constant";
	status = clBuildProgram((((Variable *)vab)->program),1,&(((Variable *)vab)->device),options,NULL,NULL);
	if(status < 0)
	{
		
		size_t log_size;
		status = clGetProgramBuildInfo((((Variable *)vab)->program), (((Variable *)vab)->device), CL_PROGRAM_BUILD_LOG, 0, NULL, &log_size);
		CheckError(status);
		char *program_log = (char*)malloc(log_size + 1);
		status = clGetProgramBuildInfo((((Variable *)vab)->program), (((Variable *)vab)->device), CL_PROGRAM_BUILD_LOG, log_size + 1, program_log, NULL);
		CheckError(status);
		cout<<"ProgramBuildInfo:"<<endl<<program_log<<endl;
		
	}
	
	(((Variable *)vab)->kernel_scaling_P) = clCreateKernel((((Variable *)vab)->program), KERNEL_FUNC_P, &status);
	CheckError(status);
	(((Variable *)vab)->kernel_scaling_SP) = clCreateKernel((((Variable *)vab)->program), KERNEL_FUNC_SP ,&status);
	CheckError(status);
	(((Variable *)vab)->kernel_rotationP_90) = clCreateKernel((((Variable *)vab)->program), KERNEL_FUNC_P_90, &status);
	CheckError(status);
	(((Variable *)vab)->kernel_rotationP_180) = clCreateKernel((((Variable *)vab)->program), KERNEL_FUNC_P_180 ,&status);
	CheckError(status);
	(((Variable *)vab)->kernel_rotationP_270) = clCreateKernel((((Variable *)vab)->program), KERNEL_FUNC_P_270, &status);
	CheckError(status);
	(((Variable *)vab)->kernel_rotationSP_90) = clCreateKernel((((Variable *)vab)->program), KERNEL_FUNC_SP_90 ,&status);
	CheckError(status);
	(((Variable *)vab)->kernel_rotationSP_180) = clCreateKernel((((Variable *)vab)->program), KERNEL_FUNC_SP_180, &status);
	CheckError(status);
	(((Variable *)vab)->kernel_rotationSP_270) = clCreateKernel((((Variable *)vab)->program), KERNEL_FUNC_SP_270 ,&status);
	CheckError(status);
	
	(((Variable *)vab)->queue) = clCreateCommandQueue((((Variable *)vab)->context),(((Variable *)vab)->device),CL_QUEUE_PROFILING_ENABLE,&status);
	CheckError(status);
	
	//ͼ������ʽ
	DataForm.image_channel_data_type = CL_UNORM_INT8;
    DataForm.image_channel_order = CL_R;
	DataFormUV.image_channel_data_type = CL_UNORM_INT8;
    DataFormUV.image_channel_order = CL_RG;
	
	//��������ͼ�����
	(((Variable *)vab)->InImageY) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_READ_ONLY|CL_MEM_ALLOC_HOST_PTR, &DataForm, Width, Height, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->InImageU) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_READ_ONLY|CL_MEM_ALLOC_HOST_PTR, &DataForm, Width / 2, Height / 2, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->InImageV) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_READ_ONLY|CL_MEM_ALLOC_HOST_PTR, &DataForm, Width / 2, Height / 2, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->InImageUV) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_READ_ONLY|CL_MEM_ALLOC_HOST_PTR, &DataFormUV, Width / 2, Height / 2, 0, NULL, &status);
	CheckError(status);
	
	//����������ת������ͼ�����
	(((Variable *)vab)->OutScalingImageY) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_WRITE_ONLY, &DataForm, newWidth, newHeight, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->OutScalingImageU) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_WRITE_ONLY, &DataForm, newWidth / 2, newHeight / 2, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->OutScalingImageV) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_WRITE_ONLY, &DataForm, newWidth / 2, newHeight / 2, 0, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->OutScalingImageUV) = clCreateImage2D((((Variable *)vab)->context), CL_MEM_WRITE_ONLY, &DataFormUV, newWidth / 2, newHeight / 2, 0, NULL, &status);
	CheckError(status);
	
	//������ת���������Buffer����
	(((Variable *)vab)->InBufferY) = clCreateBuffer((((Variable *)vab)->context), CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR, newWidth * newHeight, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->InBufferU) = clCreateBuffer((((Variable *)vab)->context), CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR, newWidth * newHeight / 4, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->InBufferV) = clCreateBuffer((((Variable *)vab)->context), CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR, newWidth * newHeight / 4, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->InBufferUV) = clCreateBuffer((((Variable *)vab)->context), CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR, newWidth * newHeight / 2, NULL, &status);
	CheckError(status);
	
	(((Variable *)vab)->OutBufferY) = clCreateBuffer((((Variable *)vab)->context), CL_MEM_WRITE_ONLY | CL_MEM_ALLOC_HOST_PTR, newWidth * newHeight, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->OutBufferU) = clCreateBuffer((((Variable *)vab)->context), CL_MEM_WRITE_ONLY | CL_MEM_ALLOC_HOST_PTR, newWidth * newHeight / 4, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->OutBufferV) = clCreateBuffer((((Variable *)vab)->context), CL_MEM_WRITE_ONLY | CL_MEM_ALLOC_HOST_PTR, newWidth * newHeight / 4, NULL, &status);
	CheckError(status);
	(((Variable *)vab)->OutBufferUV) = clCreateBuffer((((Variable *)vab)->context), CL_MEM_WRITE_ONLY | CL_MEM_ALLOC_HOST_PTR, newWidth * newHeight / 2, NULL, &status);
	CheckError(status);
	
	clFlush((((Variable *)vab)->queue));
	
}

/*****************************************************************************************************************
�������ܣ� �˺���ִ�е���ͼ������ź���ת���Ƚ������Ŵ����������ת����
���룺     �а˸�������������ηֱ�������ͼ���Buffer�����ͼ���Buffer������ͼ����͸ߣ����ź�ͼ��Ŀ��͸ߣ�����
           ͼ��ĸ�ʽ������ΪSP_420ʱ��420SP��ʽ������ΪP_420ʱ��420P��ʽ������ת�Ƕȣ���90��180��270����ѡ���
�����     ��
******************************************************************************************************************/
void ScalingRotation::Processing_ScalingRotation(unsigned char * InData, unsigned char * OutData, int Width, int Height, int newWidth, int newHeight, int Format, int Angle)
{
    
	//�����־λ
	cl_int status;
	
	//����ͼ���������д���������
	const size_t Origin[3] = {0,0,0};
	const size_t RegionY[3] = {Width, Height, 1};
	const size_t RegionUV[3] = {Width / 2, Height / 2, 1};
	
	//���ͼ��������ݶ�ȡ��������
	const size_t newRegionY[3] = {newWidth, newHeight, 1};
	const size_t newRegionUV[3] = {newWidth / 2, newHeight / 2, 1};
	
	switch(Format)
	{
		
		case P_420:
		
		    {
		        
				//���������ݶ��뵽����ͼ����
				size_t rowPitch;
				unsigned char *InDataY = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->InImageY), CL_TRUE, CL_MAP_WRITE, Origin, RegionY, &rowPitch, NULL, 0, NULL, NULL, &status);
	            CheckError(status);
				memcpy(InDataY, InData, Width * Height);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->InImageY), InDataY, 0, NULL, NULL);
	            CheckError(status);
				
				unsigned char *InDataU = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->InImageU), CL_TRUE, CL_MAP_WRITE, Origin, RegionUV, &rowPitch, NULL, 0, NULL, NULL, &status);
				memcpy(InDataU, InData + Width * Height, Width * Height / 4);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->InImageU), InDataU, 0, NULL, NULL);
	            CheckError(status);
				
				unsigned char *InDataV = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->InImageV), CL_TRUE, CL_MAP_WRITE, Origin, RegionUV, &rowPitch, NULL, 0, NULL, NULL, &status);
	            memcpy(InDataV, InData + Width * Height * 5 / 4, Width * Height / 4);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->InImageV), InDataV, 0, NULL, NULL);
	            CheckError(status);
			
	            //����kernel_P����
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 0, sizeof(cl_mem), &(((Variable *)vab)->InImageY));
                CheckError(status);
                status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 1, sizeof(cl_mem), &(((Variable *)vab)->InImageU));
	            CheckError(status);
			    status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 2, sizeof(cl_mem), &(((Variable *)vab)->InImageV));
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 3, sizeof(cl_mem), &(((Variable *)vab)->OutScalingImageY));
	            CheckError(status);
                status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 4, sizeof(cl_mem), &(((Variable *)vab)->OutScalingImageU));
	            CheckError(status);
			    status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 5, sizeof(cl_mem), &(((Variable *)vab)->OutScalingImageV));
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 6, sizeof(cl_float), &widthNormalizationFactor);
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_P), 7, sizeof(cl_float), &heightNormalizationFactor);
	            CheckError(status);
	        
	            //��������ά��
                const int workDimensions_P = 2;
                size_t globalWorkSize_P[workDimensions_P] = {newWidth / 2, newHeight / 2};
			
	            //ִ��kernel_P
                clEnqueueNDRangeKernel((((Variable *)vab)->queue), (((Variable *)vab)->kernel_scaling_P), workDimensions_P, NULL, globalWorkSize_P, NULL, 0, NULL, NULL);
	
                //status = clFinish((((Variable *)vab)->queue));
	            //CheckError(status);
			    
				status = clEnqueueCopyImageToBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageY), (((Variable *)vab)->InBufferY), Origin, newRegionY, 0, 0, NULL, NULL);
	            CheckError(status);
				status = clEnqueueCopyImageToBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageU), (((Variable *)vab)->InBufferU), Origin, newRegionUV, 0, 0, NULL, NULL);
	            CheckError(status);
				status = clEnqueueCopyImageToBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageV), (((Variable *)vab)->InBufferV), Origin, newRegionUV, 0, 0, NULL, NULL);
	            CheckError(status);
			    
	            switch(Angle)
                {
		
		            case 90:
		    
		                {
					        
		              	    //����kernel90����
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_90), 0, sizeof(cl_mem), &(((Variable *)vab)->InBufferY));
                            CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_90), 1, sizeof(cl_mem), &(((Variable *)vab)->InBufferU));
                            CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_90), 2, sizeof(cl_mem), &(((Variable *)vab)->InBufferV));
                            CheckError(status);
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_90), 3, sizeof(cl_mem), &(((Variable *)vab)->OutBufferY));
	                        CheckError(status);
		            		status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_90), 4, sizeof(cl_mem), &(((Variable *)vab)->OutBufferU));
	                        CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_90), 5, sizeof(cl_mem), &(((Variable *)vab)->OutBufferV));
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_90), 6, sizeof(cl_int), &newWidth);
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_90), 7, sizeof(cl_int), &newHeight);
			    
			                //ִ��kernel90
                            const int workDimensions90 = 2;
			            	size_t globalWorkSize90[workDimensions90] = {newWidth / 16, newHeight / 16};
				 
                            clEnqueueNDRangeKernel((((Variable *)vab)->queue), (((Variable *)vab)->kernel_rotationP_90), workDimensions90, NULL, globalWorkSize90, NULL, 0, NULL, NULL); 
			
			              	//status = clFinish((((Variable *)vab)->queue));
	                        //CheckError(status);
							
							unsigned char *OutDataY = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData, OutDataY, newWidth * newHeight);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), OutDataY, 0, NULL, NULL);
	                        CheckError(status);
				
				            unsigned char *OutDataU = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferU), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight / 4, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData + newWidth * newHeight, OutDataU, newWidth * newHeight / 4);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferU), OutDataU, 0, NULL, NULL);
	                        CheckError(status);
				
				            unsigned char *OutDataV = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferV), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight / 4, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData + newWidth * newHeight * 5 / 4, OutDataV, newWidth * newHeight / 4);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferV), OutDataV, 0, NULL, NULL);
	                        CheckError(status);
				 
			            }
					
			            break;
		
		            case 180:
		
		                {
							
							//����kernel180����
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_180), 0, sizeof(cl_mem), &(((Variable *)vab)->InBufferY));
                            CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_180), 1, sizeof(cl_mem), &(((Variable *)vab)->InBufferU));
                            CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_180), 2, sizeof(cl_mem), &(((Variable *)vab)->InBufferV));
                            CheckError(status);
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_180), 3, sizeof(cl_mem), &(((Variable *)vab)->OutBufferY));
	                        CheckError(status);
		            		status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_180), 4, sizeof(cl_mem), &(((Variable *)vab)->OutBufferU));
	                        CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_180), 5, sizeof(cl_mem), &(((Variable *)vab)->OutBufferV));
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_180), 6, sizeof(cl_int), &newWidth);
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_180), 7, sizeof(cl_int), &newHeight);
			    
			                //ִ��kernel180
                            const int workDimensions180 = 2;
			            	size_t globalWorkSize180[workDimensions180] = {newWidth / 16, newHeight / 16};
				 
                            clEnqueueNDRangeKernel((((Variable *)vab)->queue), (((Variable *)vab)->kernel_rotationP_180), workDimensions180, NULL, globalWorkSize180, NULL, 0, NULL, NULL); 
			
			              	status = clFinish((((Variable *)vab)->queue));
	                        CheckError(status);
				            
							
							unsigned char *OutDataY = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData, OutDataY, newWidth * newHeight);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), OutDataY, 0, NULL, NULL);
	                        CheckError(status);
				
				            unsigned char *OutDataU = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferU), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight / 4, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData + newWidth * newHeight, OutDataU, newWidth * newHeight / 4);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferU), OutDataU, 0, NULL, NULL);
	                        CheckError(status);
				
				            unsigned char *OutDataV = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferV), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight / 4, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData + newWidth * newHeight * 5 / 4, OutDataV, newWidth * newHeight / 4);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferV), OutDataV, 0, NULL, NULL);
	                        CheckError(status);
				        
		                }
			
			            break;
		
		            case 270:
		
		                {
				            
							//����kernel270����
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_270), 0, sizeof(cl_mem), &(((Variable *)vab)->InBufferY));
                            CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_270), 1, sizeof(cl_mem), &(((Variable *)vab)->InBufferU));
                            CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_270), 2, sizeof(cl_mem), &(((Variable *)vab)->InBufferV));
                            CheckError(status);
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_270), 3, sizeof(cl_mem), &(((Variable *)vab)->OutBufferY));
	                        CheckError(status);
		            		status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_270), 4, sizeof(cl_mem), &(((Variable *)vab)->OutBufferU));
	                        CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_270), 5, sizeof(cl_mem), &(((Variable *)vab)->OutBufferV));
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_270), 6, sizeof(cl_int), &newWidth);
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationP_270), 7, sizeof(cl_int), &newHeight);
			    
			                //ִ��kernel270
                            const int workDimensions270 = 2;
			            	size_t globalWorkSize270[workDimensions270] = {newWidth / 16, newHeight / 16};
				 
                            clEnqueueNDRangeKernel((((Variable *)vab)->queue), (((Variable *)vab)->kernel_rotationP_270), workDimensions270, NULL, globalWorkSize270, NULL, 0, NULL, NULL); 
			
			              	status = clFinish((((Variable *)vab)->queue));
	                        CheckError(status);
							
							unsigned char *OutDataY = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData, OutDataY, newWidth * newHeight);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), OutDataY, 0, NULL, NULL);
	                        CheckError(status);
				
				            unsigned char *OutDataU = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferU), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight / 4, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData + newWidth * newHeight, OutDataU, newWidth * newHeight / 4);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferU), OutDataU, 0, NULL, NULL);
	                        CheckError(status);
				
				            unsigned char *OutDataV = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferV), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight / 4, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData + newWidth * newHeight * 5 / 4, OutDataV, newWidth * newHeight / 4);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferV), OutDataV, 0, NULL, NULL);
	                        CheckError(status);
			            
		                }
			
			            break;
		
		            default:
		
		                cout<<"Invalid Angle"<<endl;
			
			            break;
		
	            }
			
		    }
		    
			break;
		
		case SP_420:
		
		    {
		        
				//���������ݶ��뵽����ͼ����
				size_t rowPitch;
				unsigned char *InDataY = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->InImageY), CL_TRUE, CL_MAP_WRITE, Origin, RegionY, &rowPitch, NULL, 0, NULL, NULL, &status);
	            CheckError(status);
				memcpy(InDataY, InData, Width * Height);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->InImageY), InDataY, 0, NULL, NULL);
	            CheckError(status);
				
				unsigned char *InDataUV = (unsigned char*)clEnqueueMapImage((((Variable *)vab)->queue), (((Variable *)vab)->InImageUV), CL_TRUE, CL_MAP_WRITE, Origin, RegionUV, &rowPitch, NULL, 0, NULL, NULL, &status);
				memcpy(InDataUV, InData + Width * Height, Width * Height / 2);
				status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->InImageUV), InDataUV, 0, NULL, NULL);
	            CheckError(status);
			
			    //����kernel_P����
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 0, sizeof(cl_mem), &(((Variable *)vab)->InImageY));
                CheckError(status);
                status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 1, sizeof(cl_mem), &(((Variable *)vab)->InImageUV));
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 2, sizeof(cl_mem), &(((Variable *)vab)->OutScalingImageY));
	            CheckError(status);
                status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 3, sizeof(cl_mem), &(((Variable *)vab)->OutScalingImageUV));
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 4, sizeof(cl_float), &widthNormalizationFactor);
	            CheckError(status);
	            status = clSetKernelArg((((Variable *)vab)->kernel_scaling_SP), 5, sizeof(cl_float), &heightNormalizationFactor);
	            CheckError(status);
	        
	            //��������ά��
                const int workDimensions_SP = 2;
                size_t globalWorkSize_SP[workDimensions_SP] = {newWidth / 2, newHeight / 2};
	
	            //ִ��kernel_SP
                clEnqueueNDRangeKernel((((Variable *)vab)->queue), (((Variable *)vab)->kernel_scaling_SP), workDimensions_SP, NULL, globalWorkSize_SP, NULL, 0, NULL, NULL);
	
                status = clFinish((((Variable *)vab)->queue));
	            CheckError(status);
	            
				status = clEnqueueCopyImageToBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageY), (((Variable *)vab)->InBufferY), Origin, newRegionY, 0, 0, NULL, NULL);
	            CheckError(status);
				status = clEnqueueCopyImageToBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutScalingImageUV), (((Variable *)vab)->InBufferUV), Origin, newRegionUV, 0, 0, NULL, NULL);
	            CheckError(status);
			    
	            switch(Angle)
                {
		
		            case 90:
		    
		                {
				            
							//����kernel270����
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_90), 0, sizeof(cl_mem), &(((Variable *)vab)->InBufferY));
                            CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_90), 1, sizeof(cl_mem), &(((Variable *)vab)->InBufferUV));
                            CheckError(status);
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_90), 2, sizeof(cl_mem), &(((Variable *)vab)->OutBufferY));
	                        CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_90), 3, sizeof(cl_mem), &(((Variable *)vab)->OutBufferUV));
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_90), 4, sizeof(cl_int), &newWidth);
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_90), 5, sizeof(cl_int), &newHeight);
			    
			                //ִ��kernel90
                            const int workDimensions90 = 2;
			            	size_t globalWorkSize90[workDimensions90] = {newWidth / 16, newHeight / 16};
				 
                            clEnqueueNDRangeKernel((((Variable *)vab)->queue), (((Variable *)vab)->kernel_rotationSP_90), workDimensions90, NULL, globalWorkSize90, NULL, 0, NULL, NULL); 
			
			              	status = clFinish((((Variable *)vab)->queue));
	                        CheckError(status);
				
							unsigned char *OutDataY = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData, OutDataY, newWidth * newHeight);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), OutDataY, 0, NULL, NULL);
	                        CheckError(status);
				
				            unsigned char *OutDataUV = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferUV), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight / 2, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData + newWidth * newHeight, OutDataUV, newWidth * newHeight / 2);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferUV), OutDataUV, 0, NULL, NULL);
	                        CheckError(status);
				
			            }
				
			            break;
		
		            case 180:
		
		                {
				            
							//����kernel270����
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_180), 0, sizeof(cl_mem), &(((Variable *)vab)->InBufferY));
                            CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_180), 1, sizeof(cl_mem), &(((Variable *)vab)->InBufferUV));
                            CheckError(status);
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_180), 2, sizeof(cl_mem), &(((Variable *)vab)->OutBufferY));
	                        CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_180), 3, sizeof(cl_mem), &(((Variable *)vab)->OutBufferUV));
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_180), 4, sizeof(cl_int), &newWidth);
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_180), 5, sizeof(cl_int), &newHeight);
			    
			                //ִ��kernel90
                            const int workDimensions180 = 2;
			            	size_t globalWorkSize180[workDimensions180] = {newWidth / 16, newHeight / 16};
				 
                            clEnqueueNDRangeKernel((((Variable *)vab)->queue), (((Variable *)vab)->kernel_rotationSP_180), workDimensions180, NULL, globalWorkSize180, NULL, 0, NULL, NULL); 
			
			              	status = clFinish((((Variable *)vab)->queue));
	                        CheckError(status);
				
							unsigned char *OutDataY = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData, OutDataY, newWidth * newHeight);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), OutDataY, 0, NULL, NULL);
	                        CheckError(status);
				
				            unsigned char *OutDataUV = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferUV), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight / 2, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData + newWidth * newHeight, OutDataUV, newWidth * newHeight / 2);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferUV), OutDataUV, 0, NULL, NULL);
	                        CheckError(status);
				
		                }
			
			            break;
		
		            case 270:
		
		                {
				            
							//����kernel270����
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_270), 0, sizeof(cl_mem), &(((Variable *)vab)->InBufferY));
                            CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_270), 1, sizeof(cl_mem), &(((Variable *)vab)->InBufferUV));
                            CheckError(status);
                            status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_270), 2, sizeof(cl_mem), &(((Variable *)vab)->OutBufferY));
	                        CheckError(status);
			            	status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_270), 3, sizeof(cl_mem), &(((Variable *)vab)->OutBufferUV));
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_270), 4, sizeof(cl_int), &newWidth);
	                        CheckError(status);
	                        status = clSetKernelArg((((Variable *)vab)->kernel_rotationSP_270), 5, sizeof(cl_int), &newHeight);
			    
			                //ִ��kernel90
                            const int workDimensions270 = 2;
			            	size_t globalWorkSize270[workDimensions270] = {newWidth / 16, newHeight / 16};
				 
                            clEnqueueNDRangeKernel((((Variable *)vab)->queue), (((Variable *)vab)->kernel_rotationSP_270), workDimensions270, NULL, globalWorkSize270, NULL, 0, NULL, NULL); 
			
			              	status = clFinish((((Variable *)vab)->queue));
	                        CheckError(status);
				
							unsigned char *OutDataY = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData, OutDataY, newWidth * newHeight);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferY), OutDataY, 0, NULL, NULL);
	                        CheckError(status);
				
				            unsigned char *OutDataUV = (unsigned char*)clEnqueueMapBuffer((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferUV), CL_TRUE, CL_MAP_READ, 0, newWidth * newHeight / 2, 0, NULL, NULL, &status);
	                        CheckError(status);
				            memcpy(OutData + newWidth * newHeight, OutDataUV, newWidth * newHeight / 2);
				            status = clEnqueueUnmapMemObject((((Variable *)vab)->queue), (((Variable *)vab)->OutBufferUV), OutDataUV, 0, NULL, NULL);
	                        CheckError(status);
			    
		                }
			
			            break;
		
		            default:
		
		                cout<<"Invalid Angle"<<endl;
			
			            break;
	
	            }
			
		    }
		
	        break;
		
		default:
		
		    cout<<"Invalid Image Format."<<endl;
			
			break;
			
	}
	
}

/***********************************************
�������ܣ� �˺�����������������Ҫ�������ͷ���Դ
���룺     ��
�����     ��
************************************************/
ScalingRotation ::~ScalingRotation()
{
	
	//�ͷ�ͼ�����
    clReleaseMemObject((((Variable *)vab)->InImageY));
    clReleaseMemObject((((Variable *)vab)->InImageU));
	clReleaseMemObject((((Variable *)vab)->InImageV));
	clReleaseMemObject((((Variable *)vab)->InImageUV));
	clReleaseMemObject((((Variable *)vab)->OutScalingImageY));
    clReleaseMemObject((((Variable *)vab)->OutScalingImageU));
	clReleaseMemObject((((Variable *)vab)->OutScalingImageV));
	clReleaseMemObject((((Variable *)vab)->OutScalingImageUV));
	clReleaseMemObject((((Variable *)vab)->InBufferY));
    clReleaseMemObject((((Variable *)vab)->InBufferU));
	clReleaseMemObject((((Variable *)vab)->InBufferV));
	clReleaseMemObject((((Variable *)vab)->InBufferUV));
	clReleaseMemObject((((Variable *)vab)->OutBufferY));
    clReleaseMemObject((((Variable *)vab)->OutBufferU));
	clReleaseMemObject((((Variable *)vab)->OutBufferV));
	clReleaseMemObject((((Variable *)vab)->OutBufferUV));
	
	//�ͷ�OpenCL ��Դ
    clReleaseProgram((((Variable *)vab)->program));
    clReleaseCommandQueue((((Variable *)vab)->queue));
    clReleaseContext((((Variable *)vab)->context));
    clReleaseKernel((((Variable *)vab)->kernel_scaling_P));
	clReleaseKernel((((Variable *)vab)->kernel_scaling_P));
	clReleaseKernel((((Variable *)vab)->kernel_rotationP_90));
	clReleaseKernel((((Variable *)vab)->kernel_rotationP_180));
	clReleaseKernel((((Variable *)vab)->kernel_rotationP_270));
	clReleaseKernel((((Variable *)vab)->kernel_rotationSP_90));
	clReleaseKernel((((Variable *)vab)->kernel_rotationSP_180));
	clReleaseKernel((((Variable *)vab)->kernel_rotationSP_270));
	
}