#ifndef __OFFLINE_KERNEL_SOURCE__
#define __OFFLINE_KERNEL_SOURCE__
const char source[] = "\n\
#ifdef SUPPORT_CL_KHR_FP16\n\
#pragma OPENCL EXTENSION cl_khr_fp16 : enable\n\
#define HALF half\n\
#define HALF2 half2\n\
#define HALF4 half4\n\
#define READ_IMAGE read_imageh\n\
#define WRITE_IMAGE write_imageh\n\
#else\n\
#define HALF float\n\
#define HALF2 float2\n\
#define HALF4 float4\n\
#define READ_IMAGE read_imagef\n\
#define WRITE_IMAGE write_imagef\n\
#endif\n\
__constant const sampler_t g_sampler = CLK_FILTER_NEAREST | CLK_NORMALIZED_COORDS_FALSE | CLK_ADDRESS_CLAMP_TO_EDGE;\n\
__kernel void compute_quality(__read_only image2d_t src, __write_only image2d_t dst){\n\
  int2 coord = (int2)(get_global_id(0), get_global_id(1));\n\
  HALF y = READ_IMAGE(src, g_sampler, coord).x;\n\
  HALF weight = 1.0f;\n\
#ifdef CONTRAST\n\
  // contrast\n\
  HALF contrast = fabs(READ_IMAGE(src, g_sampler, coord + (int2)(  0, -1)).x     // top    \n\
                     + READ_IMAGE(src, g_sampler, coord + (int2)( -1,  0)).x     // left   \n\
                     - y * 4 // center \n\
                     + READ_IMAGE(src, g_sampler, coord + (int2)( +1,  0)).x     // right  \n\
                     + READ_IMAGE(src, g_sampler, coord + (int2)(  0, +1)).x);   // bottom \n\
  CONTRAST(weight, contrast); \n\
#endif\n\
#ifdef EXPOSURE\n\
  //HALF exposure = half_exp(-(y - 0.5f) * (y - 0.5f) * 12.5f * 9.0f);\n\
  HALF exposure = exp(-(y - 0.5f) * (y - 0.5f) * 112.5f);\n\
  EXPOSURE(weight, exposure); \n\
#endif\n\
  WRITE_IMAGE(dst, coord, (HALF4)(y, weight + 1.0E-7f, 0, 1));\n\
}\n\
__constant const HALF g_pyr_down_filter[3] = { .25f, .5f, .25f };\n\
__constant const HALF g_pyr_up_filter[5] = { .0625f, .25f, .375f, .25f, .0625f };\n\
__kernel void pyr_down_row(__read_only image2d_t src, __write_only image2d_t dst) {\n\
  int2 dst_coord = (int2)(get_global_id(0), get_global_id(1));\n\
  int2 src_coord = (int2)(dst_coord.x << 1, dst_coord.y);\n\
  float4 sample = read_imagef(src, g_sampler, src_coord + (int2)(-1, 0)) * g_pyr_down_filter[0]\n\
                + read_imagef(src, g_sampler, src_coord) * g_pyr_down_filter[1]\n\
                + read_imagef(src, g_sampler, src_coord + (int2)(+1, 0)) * g_pyr_down_filter[2];\n\
  write_imagef(dst, dst_coord, sample);\n\
}\n\
__kernel void pyr_down_col(__read_only image2d_t src, __write_only image2d_t dst) {\n\
  int2 dst_coord = (int2)(get_global_id(0), get_global_id(1));\n\
  int2 src_coord = (int2)(dst_coord.x, dst_coord.y << 1);\n\
  float4 sample = read_imagef(src, g_sampler, src_coord + (int2)(0, -1)) * g_pyr_down_filter[0]\n\
                + read_imagef(src, g_sampler, src_coord) * g_pyr_down_filter[1]\n\
                + read_imagef(src, g_sampler, src_coord + (int2)(0, +1)) * g_pyr_down_filter[2];\n\
  write_imagef(dst, dst_coord, sample);\n\
}\n\
__kernel void pyr_up_col(__read_only image2d_t src, __write_only image2d_t dst) {\n\
  int2 src_coord = (int2)(get_global_id(0), get_global_id(1));\n\
  int2 dst_coord = (int2)(src_coord.x, src_coord.y << 1);\n\
  HALF4 top = READ_IMAGE(src, g_sampler, src_coord + (int2)(0, -1));\n\
  HALF4 center = READ_IMAGE(src, g_sampler, src_coord);\n\
  HALF4 bottom = READ_IMAGE(src, g_sampler, src_coord + (int2)(0, +1));\n\
  WRITE_IMAGE(dst, dst_coord, (top * g_pyr_up_filter[0] + center * g_pyr_up_filter[2] + bottom * g_pyr_up_filter[0]) * 2);\n\
  WRITE_IMAGE(dst, dst_coord + (int2)(0, 1), (center * g_pyr_up_filter[1] + bottom * g_pyr_up_filter[1]) * 2);\n\
}\n\
__kernel void pyr_up_row_and_laplacian(__read_only image2d_t org, __read_only image2d_t src, __write_only image2d_t dst) {\n\
  int2 src_coord = (int2)(get_global_id(0), get_global_id(1));\n\
  HALF left = READ_IMAGE(src, g_sampler, src_coord + (int2)(-1, 0)).x;\n\
  HALF center = READ_IMAGE(src, g_sampler, src_coord).x;\n\
  HALF right = READ_IMAGE(src, g_sampler, src_coord + (int2)(+1, 0)).x;\n\
  // write the first pixel\n\
  int2 dst_coord = (int2)(src_coord.x << 1, src_coord.y);\n\
  HALF2 v = READ_IMAGE(org, g_sampler, dst_coord).xy;\n\
  v.x -= (left * g_pyr_up_filter[0] + center * g_pyr_up_filter[2] + right * g_pyr_up_filter[0]) * 2;\n\
  WRITE_IMAGE(dst, dst_coord, (HALF4)(v, (HALF2)(0, 1)));\n\
  // write the second pixel\n\
  dst_coord += (int2)(1, 0);\n\
  v = READ_IMAGE(org, g_sampler, dst_coord).xy;\n\
  v.x -= (center * g_pyr_up_filter[1] + right * g_pyr_up_filter[1]) * 2;\n\
  WRITE_IMAGE(dst, dst_coord, (HALF4)(v, (HALF2)(0, 1)));\n\
}\n\
__kernel void pyr_up_row_and_fusion(__read_only image2d_t org, __read_only image2d_t src,__write_only image2d_t dst) {\n\
  int2 src_coord = (int2)(get_global_id(0), get_global_id(1));\n\
  HALF left = READ_IMAGE(src, g_sampler, src_coord + (int2)(-1, 0)).x;\n\
  HALF center = READ_IMAGE(src, g_sampler, src_coord).x;\n\
  HALF right = READ_IMAGE(src, g_sampler, src_coord + (int2)(+1, 0)).x;\n\
  // write the first pixel\n\
  int2 dst_coord = (int2)(src_coord.x << 1, src_coord.y);\n\
  HALF v = READ_IMAGE(org, g_sampler, dst_coord).x;\n\
  v += (left * g_pyr_up_filter[0] + center * g_pyr_up_filter[2] + right * g_pyr_up_filter[0]) * 2;\n\
  WRITE_IMAGE(dst, dst_coord, (HALF4)(v, 0, 0, 1));\n\
  // write the second pixel\n\
  dst_coord += (int2)(1, 0);\n\
  v = READ_IMAGE(org, g_sampler, dst_coord).x;\n\
  v += (center * g_pyr_up_filter[1] + right * g_pyr_up_filter[1]) * 2;\n\
  WRITE_IMAGE(dst, dst_coord, (HALF4)(v, 0, 0, 1));\n\
}\n\
";
#endif