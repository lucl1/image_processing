#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <float.h>
#include <math.h>
#include "cl_runtime.h"
#include "hdr_lc.h"
#include "online_kernel_source.h"
#include "offline_kernel_binaries.h"

#undef ENABLE_PROFILING_CL_KERNEL

#define SLAVE_COMMAND_QUEUE_SIZE 2

#if defined(__GNUC__)
#define CHECKSTATUS(expr)  __CHECKSTATUS(expr, __FILE__, __LINE__, __func__)
#else /* defined(__MSVC__) */
#define CHECKSTATUS(expr)  __CHECKSTATUS(expr, __FILE__, __LINE__)
#endif

#define MIN(x,y) ((x)>(y)?(y):(x))
#define MAX(x,y) ((x)>(y)?(x):(y))

static inline void __CHECKSTATUS(cl_int err, const char *file, const int line, const char *func = "") {
  if (CL_SUCCESS != err) {
    char msg[255];
    switch (err)
    {
    case CL_DEVICE_NOT_FOUND:
      strcpy(msg, "CL_DEVICE_NOT_FOUND");
      break;
    case CL_DEVICE_NOT_AVAILABLE:
      strcpy(msg, "CL_DEVICE_NOT_AVAILABLE");
      break;
    case CL_COMPILER_NOT_AVAILABLE:
      strcpy(msg, "CL_COMPILER_NOT_AVAILABLE");
      break;
    case CL_MEM_OBJECT_ALLOCATION_FAILURE:
      strcpy(msg, "CL_MEM_OBJECT_ALLOCATION_FAILURE");
      break;
    case CL_OUT_OF_RESOURCES:
      strcpy(msg, "CL_OUT_OF_RESOURCES");
      break;
    case CL_OUT_OF_HOST_MEMORY:
      strcpy(msg, "CL_OUT_OF_HOST_MEMORY");
      break;
    case CL_PROFILING_INFO_NOT_AVAILABLE:
      strcpy(msg, "CL_PROFILING_INFO_NOT_AVAILABLE");
      break;
    case CL_MEM_COPY_OVERLAP:
      strcpy(msg, "CL_MEM_COPY_OVERLAP");
      break;
    case CL_IMAGE_FORMAT_MISMATCH:
      strcpy(msg, "CL_IMAGE_FORMAT_MISMATCH");
      break;
    case CL_IMAGE_FORMAT_NOT_SUPPORTED:
      strcpy(msg, "CL_IMAGE_FORMAT_NOT_SUPPORTED");
      break;
    case CL_BUILD_PROGRAM_FAILURE:
      strcpy(msg, "CL_BUILD_PROGRAM_FAILURE");
      break;
    case CL_MAP_FAILURE:
      strcpy(msg, "CL_MAP_FAILURE");
      break;
    case CL_MISALIGNED_SUB_BUFFER_OFFSET:
      strcpy(msg, "CL_MISALIGNED_SUB_BUFFER_OFFSET");
      break;
    case CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST:
      strcpy(msg, "CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST");
      break;
    case CL_INVALID_VALUE:
      strcpy(msg, "CL_INVALID_VALUE");
      break;
    case CL_INVALID_DEVICE_TYPE:
      strcpy(msg, "CL_INVALID_DEVICE_TYPE");
      break;
    case CL_INVALID_PLATFORM:
      strcpy(msg, "CL_INVALID_PLATFORM");
      break;
    case CL_INVALID_DEVICE:
      strcpy(msg, "CL_INVALID_DEVICE");
      break;
    case CL_INVALID_CONTEXT:
      strcpy(msg, "CL_INVALID_CONTEXT");
      break;
    case CL_INVALID_QUEUE_PROPERTIES:
      strcpy(msg, "CL_INVALID_QUEUE_PROPERTIES");
      break;
    case CL_INVALID_COMMAND_QUEUE:
      strcpy(msg, "CL_INVALID_COMMAND_QUEUE");
      break;
    case CL_INVALID_HOST_PTR:
      strcpy(msg, "CL_INVALID_HOST_PTR");
      break;
    case CL_INVALID_MEM_OBJECT:
      strcpy(msg, "CL_INVALID_MEM_OBJECT");
      break;
    case CL_INVALID_IMAGE_FORMAT_DESCRIPTOR:
      strcpy(msg, "CL_INVALID_IMAGE_FORMAT_DESCRIPTOR");
      break;
    case CL_INVALID_IMAGE_SIZE:
      strcpy(msg, "CL_INVALID_IMAGE_SIZE");
      break;
    case CL_INVALID_SAMPLER:
      strcpy(msg, "CL_INVALID_SAMPLER");
      break;
    case CL_INVALID_BINARY:
      strcpy(msg, "CL_INVALID_BINARY");
      break;
    case CL_INVALID_BUILD_OPTIONS:
      strcpy(msg, "CL_INVALID_BUILD_OPTIONS");
      break;
    case CL_INVALID_PROGRAM:
      strcpy(msg, "CL_INVALID_PROGRAM");
      break;
    case CL_INVALID_PROGRAM_EXECUTABLE:
      strcpy(msg, "CL_INVALID_PROGRAM_EXECUTABLE");
      break;
    case CL_INVALID_KERNEL_NAME:
      strcpy(msg, "CL_INVALID_KERNEL_NAME");
      break;
    case CL_INVALID_KERNEL_DEFINITION:
      strcpy(msg, "CL_INVALID_KERNEL_DEFINITION");
      break;
    case CL_INVALID_KERNEL:
      strcpy(msg, "CL_INVALID_KERNEL");
      break;
    case CL_INVALID_ARG_INDEX:
      strcpy(msg, "CL_INVALID_ARG_INDEX");
      break;
    case CL_INVALID_ARG_VALUE:
      strcpy(msg, "CL_INVALID_ARG_VALUE");
      break;
    case CL_INVALID_ARG_SIZE:
      strcpy(msg, "CL_INVALID_ARG_SIZE");
      break;
    case CL_INVALID_KERNEL_ARGS:
      strcpy(msg, "CL_INVALID_KERNEL_ARGS");
      break;
    case CL_INVALID_WORK_DIMENSION:
      strcpy(msg, "CL_INVALID_WORK_DIMENSION");
      break;
    case CL_INVALID_WORK_GROUP_SIZE:
      strcpy(msg, "CL_INVALID_WORK_GROUP_SIZE");
      break;
    case CL_INVALID_WORK_ITEM_SIZE:
      strcpy(msg, "CL_INVALID_WORK_ITEM_SIZE");
      break;
    case CL_INVALID_GLOBAL_OFFSET:
      strcpy(msg, "CL_INVALID_GLOBAL_OFFSET");
      break;
    case CL_INVALID_EVENT_WAIT_LIST:
      strcpy(msg, "CL_INVALID_EVENT_WAIT_LIST");
      break;
    case CL_INVALID_EVENT:
      strcpy(msg, "CL_INVALID_EVENT");
      break;
    case CL_INVALID_OPERATION:
      strcpy(msg, "CL_INVALID_OPERATION");
      break;
    case CL_INVALID_GL_OBJECT:
      strcpy(msg, "CL_INVALID_GL_OBJECT");
      break;
    case CL_INVALID_BUFFER_SIZE:
      strcpy(msg, "CL_INVALID_BUFFER_SIZE");
      break;
    case CL_INVALID_MIP_LEVEL:
      strcpy(msg, "CL_INVALID_MIP_LEVEL");
      break;
    case CL_INVALID_GLOBAL_WORK_SIZE:
      strcpy(msg, "CL_INVALID_GLOBAL_WORK_SIZE");
      break;
    default:
      sprintf(msg, "Unknown CL error code(%d)", err);
      break;
    }
    printf("CL ERROR: %s in %s, file %s, line %d\n", msg, func, file, line);
    getchar();
    exit(-1);
  }
}

#if defined(__GNUC__)
#define RUN(name, cmd_queue, kernel, work_dim, global_work_offset, global_work_size, local_work_size, num_events_in_wait_list, event_wait_list, event)  __RUN(name, cmd_queue, kernel, work_dim, global_work_offset, global_work_size, local_work_size, num_events_in_wait_list, event_wait_list, event, __FILE__, __LINE__, __func__)
#else /* defined(__MSVC__) */
#define RUN(name, cmd_queue, kernel, work_dim, global_work_offset, global_work_size, local_work_size, num_events_in_wait_list, event_wait_list, event)  __RUN(name, cmd_queue, kernel, work_dim, global_work_offset, global_work_size, local_work_size, num_events_in_wait_list, event_wait_list, event, __FILE__, __LINE__)
#endif

static inline void __RUN(const char *name, cl_command_queue cmd_queue, cl_kernel kernel, cl_uint work_dim, const size_t *global_work_offset, const size_t *global_work_size, const size_t *local_work_size, cl_uint num_events_in_wait_list, const cl_event * event_wait_list, cl_event * event, const char *file, const int line, const char *func = "") {
#ifdef ENABLE_PROFILING_CL_KERNEL
  cl_event e = NULL;
  CHECKSTATUS(clEnqueueNDRangeKernel(cmd_queue, 
    kernel,
    work_dim,
    global_work_offset,
    global_work_size,
    NULL,
    0,
    NULL,
    &e));

  cl_ulong start_time, end_time, queue_time;

  CHECKSTATUS(clWaitForEvents(1, &e));

  CHECKSTATUS(clGetEventProfilingInfo(e,
    CL_PROFILING_COMMAND_START,
    sizeof(cl_ulong),
    &start_time,
    0));

  CHECKSTATUS(clGetEventProfilingInfo(e,
    CL_PROFILING_COMMAND_END,
    sizeof(cl_ulong),
    &end_time,
    0));

  CHECKSTATUS(clGetEventProfilingInfo(e,
    CL_PROFILING_COMMAND_QUEUED,
    sizeof(cl_ulong),
    &queue_time,
    0));

  double execute_time = (double)(end_time - start_time) / 1000000;
  double total_time = (double)(end_time - queue_time) / 1000000;

  printf( "Kernel Name                     Execute time(ms)    Lauch time(ms)      Total time(ms)\n" );
  printf("%-32s%-20.2f%-20.2f%-20.2f\n", name, execute_time, total_time - execute_time, total_time);
  clReleaseEvent(e);
#else
  CHECKSTATUS(clEnqueueNDRangeKernel(cmd_queue, 
    kernel,
    work_dim,
    global_work_offset,
    global_work_size,
    local_work_size,
    num_events_in_wait_list,
    event_wait_list,
    event));
#endif
  clFlush(cmd_queue);
}

static inline int div_up(int total, int grain) {
  return ( total + grain - 1 ) / grain;
}

class CTX {
public:
  int N;
  int width;
  int height;
  float contrast_weight;
  float exposure_weight;
  int pixel_format;
  int max_level;
  int* level_widths;
  int* level_heights;
  cl_mem* Y_dev_ptr; // y of input images and output image
  cl_mem* M_dev_ptr; // temporary buffers
  cl_mem* N_dev_ptr; // temporary buffers
  cl_mem** W_dev_ptr; // temporary buffers
  cl_context context;
  cl_command_queue master_cmd_queue;
  cl_command_queue slave_cmd_queues[SLAVE_COMMAND_QUEUE_SIZE];
  cl_device_id device_id;
  char device_name[256];
  char device_version[256];
  cl_program program;
  cl_kernel kernel_compute_quality;
  cl_kernel kernel_pyr_down_row;
  cl_kernel kernel_pyr_down_col;
  cl_kernel kernel_pyr_up_col;
  cl_kernel kernel_pyr_up_row_and_laplacian;
  cl_kernel kernel_pyr_up_row_and_fusion;
  cl_kernel kernel_merge;
  CTX(int n);
  int createBuffers(int w, int h);
  void releaseBuffers();
  int createKernels(float con_w, float exp_w, int pix_fmt);
  void releaseKernels();
  int process(unsigned char **src_yuv, unsigned char *dst_yuv);
  ~CTX();
};

CTX::CTX(int n) {
  assert(n > 1);
  N = n;

  /* reset others params */
  width = 0;
  height = 0;
  contrast_weight = 0.0f;
  exposure_weight = 0.0f;
  pixel_format = -1;
  max_level = -1;
  level_widths = NULL;
  level_heights = NULL;
  Y_dev_ptr = NULL;
  M_dev_ptr = NULL;
  N_dev_ptr = NULL;
  W_dev_ptr = NULL;
  program = NULL;
  kernel_compute_quality = NULL;
  kernel_pyr_down_row = NULL;
  kernel_pyr_down_col = NULL;
  kernel_pyr_up_col = NULL;
  kernel_pyr_up_row_and_laplacian = NULL;
  kernel_pyr_up_row_and_fusion = NULL;
  kernel_merge = NULL;

  /* initialize cl runtime */
  cl_int status = CL_SUCCESS;
  /* query all the platforms, set the first one as default*/
  cl_uint numPlatformIds = 0;
  status = clGetPlatformIDs(0, NULL, &numPlatformIds);
  if (status == CL_DEVICE_NOT_FOUND) {
    printf("cl platform not found\n");
    exit(-1);
  }
  cl_platform_id *platformIds = new cl_platform_id[numPlatformIds];
  assert(!!platformIds);
  CHECKSTATUS(clGetPlatformIDs(numPlatformIds, platformIds, NULL));
  printf("%d cl platforms found:\n", numPlatformIds);
  char platformName[256];
  char platformVendor[256];
  char platformVersion[256];
  for (unsigned n = 0; n < numPlatformIds; ++n) {
    CHECKSTATUS(clGetPlatformInfo(platformIds[n], CL_PLATFORM_NAME, 256, platformName, NULL));
    CHECKSTATUS(clGetPlatformInfo(platformIds[n], CL_PLATFORM_VENDOR, 256, platformVendor, NULL));
    CHECKSTATUS(clGetPlatformInfo(platformIds[n], CL_PLATFORM_VERSION, 256, platformVersion, NULL));
    if (n == 0) {
      printf("%s %s %s[selected]\n", platformName, platformVendor, platformVersion);
    } else {
      printf("%s %s %s\n", platformName, platformVendor, platformVersion);
    }
  }
  cl_platform_id platformId = platformIds[0];
  delete[] platformIds;
  /* query all the devices, set the first one as default*/
  cl_uint numDeviceIds;
  status = clGetDeviceIDs(platformId, CL_DEVICE_TYPE_GPU, 0, NULL, &numDeviceIds);
  if (status == CL_DEVICE_NOT_FOUND) {
    printf("cl gpu device not found\n");
    exit(-1);
  }
  cl_device_id *deviceIds = new cl_device_id[numDeviceIds];
  assert(!!deviceIds);
  CHECKSTATUS(clGetDeviceIDs(platformId, CL_DEVICE_TYPE_GPU, numDeviceIds, deviceIds, NULL));
  printf("%d cl gpu devices found:\n", numDeviceIds);
  char deviceName[256];
  char deviceVersion[256];
  for(unsigned n = 0; n < numDeviceIds; n++) {
    CHECKSTATUS(clGetDeviceInfo(deviceIds[n], CL_DEVICE_NAME, 256, deviceName, NULL));
    CHECKSTATUS(clGetDeviceInfo(deviceIds[n], CL_DEVICE_VERSION, 256, deviceVersion, NULL));
    if (n == 0) {
	  strcpy(device_name, deviceName);
	  strcpy(device_version, deviceVersion);
	  device_id = deviceIds[n];
      printf("%s %s[selected]\n", deviceName, deviceVersion);
    } else {
      printf("%s %s\n", deviceName, deviceVersion);
    }
  }
  delete[] deviceIds;
  /* intialize the context and command queue */
  cl_context_properties cps[3] = {
    CL_CONTEXT_PLATFORM, ( cl_context_properties )( platformId ), 0
  };
  context = clCreateContext(cps, 1, &device_id, NULL, NULL, &status);
  CHECKSTATUS(status);
#ifdef ENABLE_PROFILING_CL_KERNEL
  master_cmd_queue = clCreateCommandQueue(context, device_id, CL_QUEUE_PROFILING_ENABLE, &status);
  for (int i = 0; i < SLAVE_COMMAND_QUEUE_SIZE; i++) {
    slave_cmd_queues[i] = clCreateCommandQueue(context, device_id, CL_QUEUE_PROFILING_ENABLE, &status);
  }
#else
  master_cmd_queue = clCreateCommandQueue(context, device_id, 0, &status);
  for (int i = 0; i < SLAVE_COMMAND_QUEUE_SIZE; i++) {
    slave_cmd_queues[i] = clCreateCommandQueue(context, device_id, 0, &status);
  }
#endif
#if 0
  cl_uint numSupportedImageFormats = 0;
  CHECKSTATUS(clGetSupportedImageFormats(context, 0, CL_MEM_OBJECT_IMAGE2D, 0, NULL, &numSupportedImageFormats));
  printf("%d Image formats supported\n", numSupportedImageFormats);
  cl_image_format* supportedImageFormats = new cl_image_format[numSupportedImageFormats];
  CHECKSTATUS(clGetSupportedImageFormats(context, 0, CL_MEM_OBJECT_IMAGE2D, numSupportedImageFormats, supportedImageFormats, NULL));
  for (unsigned int i = 0; i < numSupportedImageFormats; i++) {
    switch (supportedImageFormats[i].image_channel_order) {
    case CL_R:
      printf("CL_R");
      break;
    case CL_A:
      printf("CL_A");
      break;
    case CL_RG:
      printf("CL_RG");
      break;
    case CL_RA:
      printf("CL_RA");
      break;
    case CL_RGB:
      printf("CL_RGB");
      break;
    case CL_RGBA:
      printf("CL_RGBA");
      break;
    case CL_BGRA:
      printf("CL_BGRA");
      break;
    case CL_ARGB:
      printf("CL_ARGB");
      break;
    case CL_INTENSITY:
      printf("CL_INTENSITY");
      break;
    case CL_LUMINANCE:
      printf("CL_LUMINANCE");
      break;
    case CL_Rx:
      printf("CL_Rx");
      break;
    case CL_RGx:
      printf("CL_RGx");
      break;
    case CL_RGBx:
      printf("CL_RGBx");
      break;
    default:
      printf("Unknown image channel order");
      break;
    }
    printf(",");
    switch (supportedImageFormats[i].image_channel_data_type)
    {
    case CL_SNORM_INT8:
      printf("CL_SNORM_INT8");
      break;
    case CL_SNORM_INT16:
      printf("CL_SNORM_INT16");
      break;
    case CL_UNORM_INT8:
      printf("CL_UNORM_INT8");
      break;
    case CL_UNORM_INT16:
      printf("CL_UNORM_INT16");
      break;
    case CL_UNORM_SHORT_565:
      printf("CL_UNORM_SHORT_565");
      break;
    case CL_UNORM_SHORT_555:
      printf("CL_UNORM_SHORT_555");
      break;
    case CL_UNORM_INT_101010:
      printf("CL_UNORM_INT_101010");
      break;
    case CL_SIGNED_INT8:
      printf("CL_SIGNED_INT8");
      break;
    case CL_SIGNED_INT16:
      printf("CL_SIGNED_INT16");
      break;
    case CL_SIGNED_INT32:
      printf("CL_SIGNED_INT32");
      break;
    case CL_UNSIGNED_INT8:
      printf("CL_UNSIGNED_INT8");
      break;
    case CL_UNSIGNED_INT16:
      printf("CL_UNSIGNED_INT16");
      break;
    case CL_UNSIGNED_INT32:
      printf("CL_UNSIGNED_INT32");
      break;
    case CL_HALF_FLOAT:
      printf("CL_HALF_FLOAT");
      break;
    case CL_FLOAT:
      printf("CL_FLOAT");
      break;
    default:
      printf("Unknown image channel data type");
      break;
    }
    printf("\n");
  }
  delete supportedImageFormats;
#endif
  printf("cl contxt&cmd_queue created.\n");
}

CTX::~CTX() {
  releaseBuffers();
  releaseKernels();
  for (int i = 0; i < SLAVE_COMMAND_QUEUE_SIZE; i++) {
    if (slave_cmd_queues[i]) {
      CHECKSTATUS(clReleaseCommandQueue(slave_cmd_queues[i]));
      slave_cmd_queues[i] = NULL;
    }
  }
  if (master_cmd_queue) {
    CHECKSTATUS(clReleaseCommandQueue(master_cmd_queue));
    master_cmd_queue = NULL;
  }
  if (context) {
    CHECKSTATUS(clReleaseContext(context));
    context = NULL;
  }
  printf("cl contxt&cmd_queue released.\n");
}

int CTX::createBuffers(int w, int h) {
  assert(w > 4);
  assert(h > 4);

  width = w;
  height = h;

  cl_int status = CL_SUCCESS;
  /* obtain max level of pyramid and image size at each level */
  max_level = (int)(floor((log((float)MIN(width, height)) / log(2.0f)))); // compute the highest possible pyramid
  assert(max_level > 0);
  level_widths = new int[max_level];
  assert(level_widths);
  level_heights = new int[max_level];
  assert(level_heights);
  int level_width = width;
  int level_height = height;
  for (int lvl = 0; lvl < max_level; lvl++) {
    level_widths[lvl] = level_width;
    level_heights[lvl] = level_height;
    level_width = (level_width + 1) >> 1;
    level_height = (level_height + 1) >> 1;
  }
  
  /* input buffers & output buffers */
  cl_image_format image_format_y = { CL_R, CL_UNORM_INT8 };
  Y_dev_ptr = new cl_mem[N];
  assert(Y_dev_ptr);
  for (int i = 0; i < N; i++) {
    Y_dev_ptr[i] = clCreateImage2D(context,
      CL_MEM_READ_WRITE,
      &image_format_y,
      width,
      height,
      0,
      NULL,
      &status);
    CHECKSTATUS(status);
  }

  /* temporary buffers */
  cl_image_format image_format_weight = { CL_RG, CL_HALF_FLOAT };
  M_dev_ptr = new cl_mem[max_level];
  assert(M_dev_ptr);
  N_dev_ptr = new cl_mem[max_level - 1];
  assert(N_dev_ptr);
  W_dev_ptr = new cl_mem*[N];
  assert(W_dev_ptr);
  for (int i = 0; i < N; i++) {
    W_dev_ptr[i] = new cl_mem[max_level];
    assert(W_dev_ptr[i]);
  }
  for (int lvl = 0; lvl < max_level; lvl++) {
    M_dev_ptr[lvl] = clCreateImage2D(context,
      CL_MEM_READ_WRITE,
      &image_format_weight,
      level_widths[lvl],
      level_heights[lvl],
      0,
      NULL,
      &status);
    CHECKSTATUS(status);
    if (lvl >= 1) {
      N_dev_ptr[lvl - 1] = clCreateImage2D(context,
        CL_MEM_READ_WRITE,
        &image_format_weight,
        level_widths[lvl],
        level_heights[lvl - 1],
        0,
        NULL,
        &status);
      CHECKSTATUS(status);
    }
    for (int i = 0; i < N; i++) {
      W_dev_ptr[i][lvl] = clCreateImage2D(context,
        CL_MEM_READ_WRITE,
        &image_format_weight,
        level_widths[lvl],
        level_heights[lvl],
        0,
        NULL,
        &status);
      CHECKSTATUS(status);
    }
  }

  printf("cl buffers created.\n");

  return 0;
}

void CTX::releaseBuffers() {
  if (level_widths) {
    delete level_widths;
  }

  if (level_heights) {
    delete level_heights;
  }

  if (Y_dev_ptr) {
    for (int i = 0; i < N; i++) {
      if (Y_dev_ptr[i]) {
        CHECKSTATUS(::clReleaseMemObject(Y_dev_ptr[i]));
      }
    }
    delete Y_dev_ptr;
  }

  if (M_dev_ptr) {
    for (int lvl = 0; lvl < max_level; lvl++) {
      if (M_dev_ptr[lvl]) {
        CHECKSTATUS(::clReleaseMemObject(M_dev_ptr[lvl]));
      }
    }
    delete M_dev_ptr;
  }

  if (N_dev_ptr) {
    for (int lvl = 0; lvl < max_level - 1; lvl++) {
      if (N_dev_ptr[lvl]) {
        CHECKSTATUS(::clReleaseMemObject(N_dev_ptr[lvl]));
      }
    }
    delete N_dev_ptr;
  }

  if (W_dev_ptr) {
    for (int i = 0; i < N; i++) {
      if (W_dev_ptr[i]) {
        for (int lvl = 0; lvl < max_level; lvl++) {
          if (W_dev_ptr[i][lvl]) {
            CHECKSTATUS(::clReleaseMemObject(W_dev_ptr[i][lvl]));
          }
        }
      }
      delete W_dev_ptr[i];
    }
    delete W_dev_ptr;
  }

  /* reset parameters */
  width = 0;
  height = 0;
  max_level = -1;
  level_widths = NULL;
  level_heights = NULL;
  Y_dev_ptr = NULL;
  M_dev_ptr = NULL;
  N_dev_ptr = NULL;
  W_dev_ptr = NULL;

  printf("cl buffers released.\n");
}

int CTX::createKernels(float con_w, float exp_w, int pix_fmt) {
  cl_int status = CL_SUCCESS;

  assert(con_w >= 0.0f);
  assert(exp_w >= 0.0f);
  assert(pix_fmt == HDR_PIXEL_FORMAT_YUV420_NV12 || pix_fmt == HDR_PIXEL_FORMAT_YUV420_NV21);

  contrast_weight = con_w;
  exposure_weight = exp_w;
  pixel_format = pix_fmt;

  int found = -1;
  for (int i = 0; i < sizeof(binaries) / sizeof(BINARY); i++) {
    if (binaries[i].N == N && 
        fabs(binaries[i].contrast_weight - contrast_weight) <= FLT_EPSILON &&
        fabs(binaries[i].exposure_weight - exposure_weight) <= FLT_EPSILON &&
        binaries[i].pixel_format == pixel_format &&
        strcmp(binaries[i].device_name, device_name) == 0 &&
        strcmp(binaries[i].device_version, device_version) == 0) {
      found = i;
      break;
    }
  }
  if (found >= 0) { // pre-built program binary is found
    const unsigned char* code = binaries[found].bin_data;
    program = clCreateProgramWithBinary(context, 1, &device_id, &binaries[found].bin_size, (const unsigned char**)&(code), NULL, &status);
  } else { // not found, compile it online
    /* create program and kernels according to the parameters */
    char s[128];
    char* code = new char[1024 + strlen(source)];
    assert(code);
    code[0] = '\0';
#ifdef __ANDROID__ // Mali GPU support cl_khr_fp16 extension
    strcat(code, "#define SUPPORT_CL_KHR_FP16\n");
#endif
    /* set pixel format to kernels */
    if (pixel_format == HDR_PIXEL_FORMAT_YUV420_NV21) {
      strcat(code, "#define HDR_PIXEL_FORMAT_YUV420_NV21\n");
    } else {
      strcat(code, "#define HDR_PIXEL_FORMAT_YUV420_NV12\n");
    }
    /* create macros for kernel 'compute_quality' accordig to contrast_weight, saturation_weight and exposure_weight */ 
    if (contrast_weight > 0.0f) {
      if (fabs(contrast_weight - 0.5f) < FLT_EPSILON) {
        strcat(code, "#define CONTRAST(weight, contrast) weight *= sqrt(contrast);\n");
      } else if (fabs(contrast_weight - 1.0f) < FLT_EPSILON) {
        strcat(code, "#define CONTRAST(weight, contrast) weight *= contrast;\n");
      } else {
        sprintf(s, "#define CONTRAST(weight, contrast) weight *= pow(contrast, %f)", contrast_weight);
        strcat(code, s);
      }
    }
    if (exposure_weight > 0.0f) {
      if (fabs(exposure_weight - 0.5f) < FLT_EPSILON) {
        strcat(code, "#define EXPOSURE(weight, exposure) weight *= sqrt(exposure);\n");
      } else if (fabs(exposure_weight - 1.0f) < FLT_EPSILON) {
        strcat(code, "#define EXPOSURE(weight, exposure) weight *= exposure;\n");
      } else {
        sprintf(s, "#define EXPOSURE(weight, exposure) weight *= pow(exposure, %f)", exposure_weight);
        strcat(code, s);
      }
    }
    strcat(code, source);
    /* create source code for kernel 'merge' according to num of images */
    strcat(code, "__kernel void merge(");
    for (int i = 0; i < N; i++) {
      sprintf(s, "__read_only image2d_t src%d,", i);
      strcat(code, s);
    }
    strcat(code, "__write_only image2d_t dst) {\nint2 coord = (int2)(get_global_id(0), get_global_id(1));\n");
    for (int i = 0; i < N; i++) {
      sprintf(s, "float4 p%d = read_imagef(src%d, g_sampler, coord);\n", i, i);
      strcat(code, s);
    }
    strcat(code, "write_imagef(dst, coord, (float4)((p0.x * p0.y");
    for (int i = 1; i < N; i++) {
      sprintf(s, " + p%d.x * p%d.y", i, i);
      strcat(code, s);
    }
    strcat(code, ") / (p0.y");
    for (int i = 1; i < N; i++) {
      sprintf(s, " + p%d.y", i);
      strcat(code, s);
    }
    strcat(code, "), 0, 0, 1));\n}\n");
    /* build the program */
    program = clCreateProgramWithSource(context, 1, (const char **)&code, NULL, &status);
    delete code;
  }
  const char options[] = "-cl-fast-relaxed-math -cl-mad-enable -cl-single-precision-constant";
  status = clBuildProgram(program, 0, NULL, options, NULL, NULL);
  if (status != CL_SUCCESS) {
    if (status == CL_BUILD_PROGRAM_FAILURE) {
      cl_int logStatus;
      char *buildLog = NULL;
      size_t buildLogSize = 0;
      logStatus = clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, buildLogSize,
        buildLog, &buildLogSize);
      if (logStatus != CL_SUCCESS) {
        printf("failed to build the program and get the build info.\n");
      }
      buildLog = new char[buildLogSize];
      assert(!!buildLog);
      memset(buildLog, 0, buildLogSize);
      CHECKSTATUS(clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, buildLogSize, buildLog, NULL));
      printf("\n---------------BUILD LOG--------------\n%s\n", buildLog);
      delete buildLog;
      return -1;
    }
  }

  /* create kernel 'compute_quality' */
  kernel_compute_quality = clCreateKernel(program, "compute_quality", &status);
  CHECKSTATUS(status);
  /* create kernel 'pyr_down_row' */
  kernel_pyr_down_row = clCreateKernel(program, "pyr_down_row", &status);
  CHECKSTATUS(status);
  /* create kernel 'pyr_down_col' */
  kernel_pyr_down_col = clCreateKernel(program, "pyr_down_col", &status);
  CHECKSTATUS(status);
  /* create kernel 'pyr_up_col' */
  kernel_pyr_up_col = clCreateKernel(program, "pyr_up_col", &status);
  CHECKSTATUS(status);
  /* create kernel 'pyr_up_row_and_laplacian' */
  kernel_pyr_up_row_and_laplacian = clCreateKernel(program, "pyr_up_row_and_laplacian", &status);
  CHECKSTATUS(status);
  /* create kernel 'pyr_up_row_and_fusion' */
  kernel_pyr_up_row_and_fusion = clCreateKernel(program, "pyr_up_row_and_fusion", &status);
  CHECKSTATUS(status);
  /* create kernel 'merge' */
  kernel_merge = clCreateKernel(program, "merge", &status);
  CHECKSTATUS(status);

  printf("cl kernels created.\n");

  return 0;
}

void CTX::releaseKernels() {
  if (kernel_compute_quality) {
    CHECKSTATUS(clReleaseKernel(kernel_compute_quality));
  }

  if (kernel_pyr_down_row) {
    CHECKSTATUS(clReleaseKernel(kernel_pyr_down_row));
  }

  if (kernel_pyr_down_col) {
    CHECKSTATUS(clReleaseKernel(kernel_pyr_down_col));
  }

  if (kernel_pyr_up_col) {
    CHECKSTATUS(clReleaseKernel(kernel_pyr_up_col));
  }

  if (kernel_pyr_up_row_and_laplacian) {
    CHECKSTATUS(clReleaseKernel(kernel_pyr_up_row_and_laplacian));
  }

  if (kernel_pyr_up_row_and_fusion) {
    CHECKSTATUS(clReleaseKernel(kernel_pyr_up_row_and_fusion));
  }

  if (kernel_merge) {
    CHECKSTATUS(clReleaseKernel(kernel_merge));
  }

  if (program)  {
    CHECKSTATUS(clReleaseProgram(program));
  }

  program = NULL;
  kernel_compute_quality = NULL;
  kernel_pyr_down_row = NULL;
  kernel_pyr_down_col = NULL;
  kernel_pyr_up_col = NULL;
  kernel_pyr_up_row_and_laplacian = NULL;
  kernel_pyr_up_row_and_fusion = NULL;
  kernel_merge = NULL;

  printf("cl kernels released.\n");
}

int CTX::process(unsigned char **src_yuv, unsigned char *dst_yuv) {
  size_t origin[3] = {0, 0, 0};
  size_t region_y[3] = {width, height, 1};
  size_t region_uv[3] = {(width + 1) >> 1, (height + 1) >> 1, 1};
  size_t globalThreads[3];
  // y fusion
  for (int i = 0; i < N; i ++) {
    if (i == 0) {
      CHECKSTATUS(clEnqueueWriteImage(master_cmd_queue, Y_dev_ptr[i], CL_FALSE, origin, region_y, 0, 0, src_yuv[i], 0, NULL, NULL));
    } else {
      // process the cuurent image only when its data transfer is finished
      clFinish(slave_cmd_queues[i % SLAVE_COMMAND_QUEUE_SIZE]);
    }
    // prepare data transfer for the next image with another command queue
    if (i < N - 1) {
      int idx = (i + 1) % SLAVE_COMMAND_QUEUE_SIZE;
      CHECKSTATUS(clEnqueueWriteImage(slave_cmd_queues[idx], Y_dev_ptr[i + 1], CL_FALSE, origin, region_y, 0, 0, src_yuv[i + 1], 0, NULL, NULL));
      clFlush(slave_cmd_queues[idx]);
    }
    CHECKSTATUS(clEnqueueWriteImage(master_cmd_queue, Y_dev_ptr[i], CL_TRUE, origin, region_y, 0, 0, src_yuv[i], 0, NULL, NULL));
    // construct laplacian pyramid immediately after submiting YUV data, it can hide the latency of data copying of the next image
    globalThreads[0] = width;
    globalThreads[1] = height;
    globalThreads[2] = 1;
    CHECKSTATUS(clSetKernelArg(kernel_compute_quality, 0, sizeof(cl_mem), (void *)&Y_dev_ptr[i]));
    CHECKSTATUS(clSetKernelArg(kernel_compute_quality, 1, sizeof(cl_mem), (void *)&M_dev_ptr[0]));
    RUN("compute_quality", master_cmd_queue, kernel_compute_quality, 3, NULL, globalThreads, NULL, 0, NULL, NULL);
    for (int lvl = 0; lvl < max_level - 1; lvl++) {
      // pyr down by row
      globalThreads[0] = level_widths[lvl + 1];
      globalThreads[1] = level_heights[lvl];
      globalThreads[2] = 1;
      CHECKSTATUS(clSetKernelArg(kernel_pyr_down_row, 0, sizeof(cl_mem), (void *)&M_dev_ptr[lvl]));
      CHECKSTATUS(clSetKernelArg(kernel_pyr_down_row, 1, sizeof(cl_mem), (void *)&N_dev_ptr[lvl]));
      RUN("pyr_down_row", master_cmd_queue, kernel_pyr_down_row, 3, NULL, globalThreads, NULL, 0, NULL, NULL);
      // pyr down by col
      globalThreads[0] = level_widths[lvl + 1];
      globalThreads[1] = level_heights[lvl + 1];
      globalThreads[2] = 1;
      CHECKSTATUS(clSetKernelArg(kernel_pyr_down_col, 0, sizeof(cl_mem), (void *)&N_dev_ptr[lvl]));
      if (lvl == max_level - 2) {
        CHECKSTATUS(clSetKernelArg(kernel_pyr_down_col, 1, sizeof(cl_mem), (void *)&W_dev_ptr[i][lvl + 1]));
      } else {
        CHECKSTATUS(clSetKernelArg(kernel_pyr_down_col, 1, sizeof(cl_mem), (void *)&M_dev_ptr[lvl + 1]));
      }
      RUN("pyr_down_col", master_cmd_queue, kernel_pyr_down_col, 3, NULL, globalThreads, NULL, 0, NULL, NULL);
      // pyr up by col
      globalThreads[0] = level_widths[lvl + 1];
      globalThreads[1] = level_heights[lvl + 1];
      globalThreads[2] = 1;
      if (lvl == max_level - 2) {
        CHECKSTATUS(clSetKernelArg(kernel_pyr_up_col, 0, sizeof(cl_mem), (void *)&W_dev_ptr[i][lvl + 1]));
      } else {
        CHECKSTATUS(clSetKernelArg(kernel_pyr_up_col, 0, sizeof(cl_mem), (void *)&M_dev_ptr[lvl + 1]));
      }
      CHECKSTATUS(clSetKernelArg(kernel_pyr_up_col, 1, sizeof(cl_mem), (void *)&N_dev_ptr[lvl]));
      RUN("pyr_up_col", master_cmd_queue, kernel_pyr_up_col, 3, NULL, globalThreads, NULL, 0, NULL, NULL);
      // pyr up by row and laplacian
      globalThreads[0] = level_widths[lvl + 1];
      globalThreads[1] = level_heights[lvl];
      globalThreads[2] = 1;
      CHECKSTATUS(clSetKernelArg(kernel_pyr_up_row_and_laplacian, 0, sizeof(cl_mem), (void *)&M_dev_ptr[lvl]));
      CHECKSTATUS(clSetKernelArg(kernel_pyr_up_row_and_laplacian, 1, sizeof(cl_mem), (void *)&N_dev_ptr[lvl]));
      CHECKSTATUS(clSetKernelArg(kernel_pyr_up_row_and_laplacian, 2, sizeof(cl_mem), (void *)&W_dev_ptr[i][lvl]));
      RUN("pyr_up_row_and_laplacian", master_cmd_queue, kernel_pyr_up_row_and_laplacian, 3, NULL, globalThreads, NULL, 0, NULL, NULL);
    }
  }

  for (int lvl = 0; lvl < max_level; lvl++) {
    // merge
    globalThreads[0] = level_widths[lvl];
    globalThreads[1] = level_heights[lvl];
    globalThreads[2] = 1;
    for (int i = 0; i < N; i++) {
      CHECKSTATUS(clSetKernelArg(kernel_merge, i, sizeof(cl_mem), (void *)&W_dev_ptr[i][lvl]));
    }
    CHECKSTATUS(clSetKernelArg(kernel_merge, N, sizeof(cl_mem), (void *)&M_dev_ptr[lvl]));
    RUN("merge", master_cmd_queue, kernel_merge, 3, NULL, globalThreads, NULL, 0, NULL, NULL);
  }
  
  for (int lvl = max_level - 1; lvl >= 1; lvl--) {
    // pyr up by col
    globalThreads[0] = level_widths[lvl];
    globalThreads[1] = level_heights[lvl];
    globalThreads[2] = 1;
    if (lvl == max_level - 1) {
      CHECKSTATUS(clSetKernelArg(kernel_pyr_up_col, 0, sizeof(cl_mem), (void *)&M_dev_ptr[lvl]));
    } else {
      CHECKSTATUS(clSetKernelArg(kernel_pyr_up_col, 0, sizeof(cl_mem), (void *)&W_dev_ptr[0][lvl]));
    }
    CHECKSTATUS(clSetKernelArg(kernel_pyr_up_col, 1, sizeof(cl_mem), (void *)&N_dev_ptr[lvl - 1]));
    RUN("pyr_up_col", master_cmd_queue, kernel_pyr_up_col, 3, NULL, globalThreads, NULL, 0, NULL, NULL);
    // pyr up by row and fusion
    globalThreads[0] = level_widths[lvl];
    globalThreads[1] = level_heights[lvl - 1];
    globalThreads[2] = 1;
    CHECKSTATUS(clSetKernelArg(kernel_pyr_up_row_and_fusion, 0, sizeof(cl_mem), (void *)&M_dev_ptr[lvl - 1]));
    CHECKSTATUS(clSetKernelArg(kernel_pyr_up_row_and_fusion, 1, sizeof(cl_mem), (void *)&N_dev_ptr[lvl - 1]));
    if (lvl == 1) {
      CHECKSTATUS(clSetKernelArg(kernel_pyr_up_row_and_fusion, 2, sizeof(cl_mem), (void *)&Y_dev_ptr[0]));
    } else {
      CHECKSTATUS(clSetKernelArg(kernel_pyr_up_row_and_fusion, 2, sizeof(cl_mem), (void *)&W_dev_ptr[0][lvl - 1]));
    }
    RUN("pyr_up_row_and_fusion", master_cmd_queue, kernel_pyr_up_row_and_fusion, 3, NULL, globalThreads, NULL, 0, NULL, NULL);
  }

  // uv fusion(optimize it with NEON if its time is higher than Y fusion's), refer to paper������̬��Ƶ��ؼ����о���
  size_t size_y = region_y[0] * region_y[1];
  size_t size_uv = region_uv[0] * region_uv[1] * 2;
  for (int i = 0; i < size_uv; i++) {
    int max_uv = src_yuv[0][size_y + i] ;
    int max_value = abs(max_uv - 128);
    for (int j = 1; j < N; j++){
      int uv = src_yuv[j][size_y + i];
      int value = abs(uv - 128);
      if (value > max_value) {
        max_uv = uv;
        max_value = value;
      }
    }
    dst_yuv[size_y + i] = max_uv;
  }

  CHECKSTATUS(clEnqueueReadImage(master_cmd_queue, Y_dev_ptr[0], CL_TRUE, origin, region_y, 0, 0, dst_yuv, 0, NULL, NULL));

  return 0;
}

void *hdr_lc_init(int n) {
  CTX *ctx = new CTX(n);
  return ctx;
}

int hdr_lc_set_params(void *ctx, int w, int h, float con_w, float exp_w, int pix_fmt) {
  if (ctx == NULL || w <= 4 || h <= 4 || con_w < 0.0f || exp_w < 0.0f || (pix_fmt != HDR_PIXEL_FORMAT_YUV420_NV12 && pix_fmt != HDR_PIXEL_FORMAT_YUV420_NV21)) {
    return -1;
  }
  if (con_w != ((CTX *)ctx)->contrast_weight || exp_w != ((CTX *)ctx)->exposure_weight || pix_fmt != ((CTX *)ctx)->pixel_format) {
    ((CTX *)ctx)->releaseKernels();
    ((CTX *)ctx)->createKernels(con_w, exp_w, pix_fmt);
  }
  if (w != ((CTX *)ctx)->width || h != ((CTX *)ctx)->height) {
    ((CTX *)ctx)->releaseBuffers();
    ((CTX *)ctx)->createBuffers(w, h);
  }
  return 0;
}

int hdr_lc_get_params(void *ctx, int* w, int* h, float* con_w, float* exp_w, int* pix_fmt) {
  if (ctx == NULL || w == NULL || h == NULL || con_w == NULL || exp_w == NULL || pix_fmt == NULL) {
    return -1;
  }
  *w = ((CTX *)ctx)->width;
  *h = ((CTX *)ctx)->height;
  *con_w = ((CTX *)ctx)->contrast_weight;
  *exp_w = ((CTX *)ctx)->exposure_weight;
  *pix_fmt = ((CTX *)ctx)->pixel_format;
  return 0;
}

int hdr_lc_process(void *ctx, unsigned char **src_yuv, unsigned char *dst_yuv) {
  if (ctx == NULL || src_yuv == NULL || dst_yuv == NULL) {
    return -1;
  }
  return ((CTX *)ctx)->process(src_yuv, dst_yuv);
}

int hdr_lc_release(void *ctx) {
  if (ctx == NULL) {
    return -1;
  }
  delete((CTX *)ctx);
  return 0;
}

const char *hdr_lc_version_code_get() {
  return "1.0";
}
