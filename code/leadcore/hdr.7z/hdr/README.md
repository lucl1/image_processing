# HDR library
It provides a library to generate HDR image from the image sequences (with different exposure), it is based on exposure
fusion algorthm described in ntp-0.cs.ucl.ac.uk/staff/j.kautz/publications/exposure_fusion.pdf, and we modified it that 
can support YUV format, and accelerated it with OpenCL in android platform.

## Change lists
2016/10/12 created by hongming

## Folder organization
-inc         # Header files of the declaration of exported interfaces of libhdr_lc.
-src         # Source files of libhdr_lc with exporsure fusion algorithm.
  -android   # Android make file for building the libhdr_lc.so for android platform.
-test        # An example to illustrate how to use the interfaces of libhdr_lc.
  -android   # Android make file for building the example for android platform.
  -cases     # Test images

## How to generate libhdr_lc.so for android platform ?
  $ cd src/android
  $ ndk-build         # Compile & build, note that you need to prepare the android NDK enviroment
                      # and ensure it works well.
  $ cd libs & ls      # OK, you will see two new folders, and libhdr_lc.so will be created.
    arm64-v8a         # For ARM 64bits
    armeabi-v7a       # For ARM 32bits
   
## How to execute the example(test case) on android platform ?
  $ cd test/android
  $ ndk-build
  $ run.bat           # Window is only supported as host, and you should plugin you android device to the 
                      # host via USB before run the example(test case).

                      # After the execution is finished, you will see an new YUV file named 'result.yuv'
                      # is generated under the folder '/test/cases/house', then use YUVViewer to check it.

## How to use the interfaces of libhdr_lc ?
  The header file 'inc/hdr_lc.h' gives the details about the interfaces of libhdr_lc, 
  and you also can learn it at 'test/hdr_lc.cpp'.