#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <math.h>
#include "quaternion.h"

double dot(const vec4* a, const vec4* b) {
  return a->x * b->x + a->y * b->y + a->z * b->z + a->w * b->w;
}

double dot(const float* a, const vec4* b) {
  return a[0] * b->x + a[1] * b->y + a[2] * b->z + a[3] * b->w;
}

void eye(vec4* c) {
  c->x = 0;
  c->y = 0;
  c->z = 0;
  c->w = 1.0f;
}

void eye(mat3* c) {
  c->s0.x = 1.0f;
  c->s0.y = 0;
  c->s0.z = 0;
  c->s0.w = 0;

  c->s1.x = 0;
  c->s1.y = 1.0f;
  c->s1.z = 0;
  c->s1.w = 0;

  c->s2.x = 0;
  c->s2.y = 0;
  c->s2.z = 1.0f;
  c->s2.w = 0;
}

void normalize(const vec4* a, vec4* c) {
  double mag = sqrt(dot(a, a));
  if (mag < DBL_EPSILON) {
    c->x = 0;
    c->y = 0;
    c->z = 0;
    c->w = 0;
  } else {
    c->x = a->x / mag;
    c->y = a->y / mag;
    c->z = a->z / mag;
    c->w = a->w / mag;
  }
}

void conjugate(const vec4* a, vec4* c) {
  c->x = -a->x;
  c->y = -a->y;
  c->z = -a->z;
  c->w = a->w;
}

// refer to Ogre OgreQuaternion.cpp 'expm'
void expm(const vec4* a, vec4* c) {
  // If q = A*(x*i+y*j+z*k) where (x,y,z) is unit length, then
  // exp(q) = cos(A)+sin(A)*(x*i+y*j+z*k).  If sin(A) is near zero,
  // use exp(q) = cos(A)+A*(x*i+y*j+z*k) since A/sin(A) has limit 1.
  double theta = sqrt(a->x * a->x + a->y * a->y + a->z * a->z);
  c->w = cos(theta);
  double sintheta = sin(theta);
  if (sintheta <= -DBL_EPSILON || sintheta >= DBL_EPSILON) {
    double coeff = sintheta / theta;
    c->x = a->x * coeff;
    c->y = a->y * coeff;
    c->z = a->z * coeff;
  } else {
    c->x = a->x;
    c->y = a->y;
    c->z = a->z;
  }
}

// refer to Ogre OgreQuaternion.cpp 'logm'
void logm(const vec4* a, vec4* c) {
  // If q = cos(A)+sin(A)*(x*i+y*j+z*k) where (x,y,z) is unit length, then
  // log(q) = A*(x*i+y*j+z*k).  If sin(A) is near zero, use log(q) =
  // sin(A)*(x*i+y*j+z*k) since sin(A)/A has limit 1.
  c->w = 0.0;
  if (a->w > -1.0 && a->w < 1.0) {
    double theta = acos(a->w);
    double sintheta = sin(theta);
    if (sintheta <= -DBL_EPSILON || sintheta >= DBL_EPSILON) {
      double coeff = theta / sintheta;
      c->x = a->x * coeff;
      c->y = a->y * coeff;
      c->z = a->z * coeff;
      return;
    }
  }
  c->x = a->x;
  c->y = a->y;
  c->z = a->z;
}

void inverse(const vec4* a, vec4* c) {
  double costheta = dot(a, a);
  if (costheta > 0) {
    conjugate(a, c);
    c->x /= costheta;
    c->y /= costheta;
    c->z /= costheta;
    c->w /= costheta;
  } else {
    c->x = 0;
    c->y = 0;
    c->z = 0;
    c->w = 0;
  }
}

void transpose(const mat3* a, mat3* c) {
  c->s0.x = a->s0.x;
  c->s0.y = a->s1.x;
  c->s0.z = a->s2.x;
  c->s0.w = 0;

  c->s1.x = a->s0.y;
  c->s1.y = a->s1.y;
  c->s1.z = a->s2.y;
  c->s1.w = 0;

  c->s2.x = a->s0.z;
  c->s2.y = a->s1.z;
  c->s2.z = a->s2.z;
  c->s2.w = 0;
}

void multiply(const vec4* a, const vec4* b, vec4* c) {
  c->x = a->w * b->x + a->x * b->w + a->y * b->z - a->z * b->y;
  c->y = a->w * b->y + a->y * b->w + a->z * b->x - a->x * b->z;
  c->z = a->w * b->z + a->z * b->w + a->x * b->y - a->y * b->x;
  c->w = a->w * b->w - a->x * b->x - a->y * b->y - a->z * b->z;
}

void multiply(const mat3* a, const mat3* b, mat3* c) {
  c->s0.x = a->s0.x * b->s0.x + a->s0.y * b->s1.x + a->s0.z * b->s2.x;
  c->s0.y = a->s0.x * b->s0.y + a->s0.y * b->s1.y + a->s0.z * b->s2.y;
  c->s0.z = a->s0.x * b->s0.z + a->s0.y * b->s1.z + a->s0.z * b->s2.z;
  c->s0.w = 0;

  c->s1.x = a->s1.x * b->s0.x + a->s1.y * b->s1.x + a->s1.z * b->s2.x;
  c->s1.y = a->s1.x * b->s0.y + a->s1.y * b->s1.y + a->s1.z * b->s2.y;
  c->s1.z = a->s1.x * b->s0.z + a->s1.y * b->s1.z + a->s1.z * b->s2.z;
  c->s1.w = 0;

  c->s2.x = a->s2.x * b->s0.x + a->s2.y * b->s1.x + a->s2.z * b->s2.x;
  c->s2.y = a->s2.x * b->s0.y + a->s2.y * b->s1.y + a->s2.z * b->s2.y;
  c->s2.z = a->s2.x * b->s0.z + a->s2.y * b->s1.z + a->s2.z * b->s2.z;
  c->s2.w = 0;
}

void multiply(const mat3* a, const mat3* b, float* c) {
  c[0] = a->s0.x * b->s0.x + a->s0.y * b->s1.x + a->s0.z * b->s2.x;
  c[1] = a->s0.x * b->s0.y + a->s0.y * b->s1.y + a->s0.z * b->s2.y;
  c[2] = a->s0.x * b->s0.z + a->s0.y * b->s1.z + a->s0.z * b->s2.z;
  c[3] = 0;

  c[4] = a->s1.x * b->s0.x + a->s1.y * b->s1.x + a->s1.z * b->s2.x;
  c[5] = a->s1.x * b->s0.y + a->s1.y * b->s1.y + a->s1.z * b->s2.y;
  c[6] = a->s1.x * b->s0.z + a->s1.y * b->s1.z + a->s1.z * b->s2.z;
  c[7] = 0;

  c[8] = a->s2.x * b->s0.x + a->s2.y * b->s1.x + a->s2.z * b->s2.x;
  c[9] = a->s2.x * b->s0.y + a->s2.y * b->s1.y + a->s2.z * b->s2.y;
  c[10] = a->s2.x * b->s0.z + a->s2.y * b->s1.z + a->s2.z * b->s2.z;
  c[11] = 0;
}

void divide(const vec4* a, const vec4* b, vec4* c) {
  vec4 invb;
  inverse(b, &invb);
  multiply(&invb, a, c);
}

void add(const vec4* a, const vec4* b, vec4* c) {
  c->x = a->x + b->x;
  c->y = a->y + b->y;
  c->z = a->z + b->z;
  c->w = a->w + b->w;
}

void add(const mat3* a, const mat3* b, mat3* c) {
  c->s0.x = a->s0.x + b->s0.x;
  c->s0.y = a->s0.y + b->s0.y;
  c->s0.z = a->s0.z + b->s0.z;
  c->s0.w = 0;

  c->s1.x = a->s1.x + b->s1.x;
  c->s1.y = a->s1.y + b->s1.y;
  c->s1.z = a->s1.z + b->s1.z;
  c->s1.w = 0;

  c->s2.x = a->s2.x + b->s2.x;
  c->s2.y = a->s2.y + b->s2.y;
  c->s2.z = a->s2.z + b->s2.z;
  c->s2.w = 0;
}

void sub(const vec4* a, const vec4* b, vec4* c) {
  c->x = a->x - b->x;
  c->y = a->y - b->y;
  c->z = a->z - b->z;
  c->w = a->w - b->w;
}

void sub(const mat3* a, const mat3* b, mat3* c) {
  c->s0.x = a->s0.x - b->s0.x;
  c->s0.y = a->s0.y - b->s0.y;
  c->s0.z = a->s0.z - b->s0.z;
  c->s0.w = 0;

  c->s1.x = a->s1.x - b->s1.x;
  c->s1.y = a->s1.y - b->s1.y;
  c->s1.z = a->s1.z - b->s1.z;
  c->s1.w = 0;

  c->s2.x = a->s2.x - b->s2.x;
  c->s2.y = a->s2.y - b->s2.y;
  c->s2.z = a->s2.z - b->s2.z;
  c->s2.w = 0;
}

void slerp(const vec4* a, const vec4* b, double t, vec4 *c) {
  double costheta = dot(a, b);
  if (costheta < 0) {
    costheta = -costheta;
    c->x = -b->x;
    c->y = -b->y;
    c->z = -b->z;
    c->w = -b->w;
  } else {
    *c = *b;
  }
  double f1, f2;
  if (costheta >= 1.0 - DBL_EPSILON) {
    f1 = 1 - t;
    f2 = t;
  } else {
    double theta = acos(costheta);
    double sintheta = sin(theta);
    f1 = sin((1.0 - t) * theta) / sintheta;
    f2 = sin(t * theta) / sintheta;
  }
  c->x = f1 * a->x + f2 * c->x;
  c->y = f1 * a->y + f2 * c->y;
  c->z = f1 * a->z + f2 * c->z;
  c->w = f1 * a->w + f2 * c->w;
}

// refer to crisp rotations.py 'integrate_gyro_quaternion'
void integrate(const vec4* a, double wx, double wy, double wz, double dt, vec4 *c) {
  double half_dt = 0.5 * dt;
  c->x = a->x + half_dt * ( wx * a->w + wz * a->y - wy * a->z);
  c->y = a->y + half_dt * ( wy * a->w - wz * a->x + wx * a->z);
  c->z = a->z + half_dt * ( wz * a->w + wy * a->x - wx * a->y);
  c->w = a->w + half_dt * (-wx * a->x - wy * a->y - wz * a->z);
  normalize(c, c);
}

// refer to matlab quat2dcm
void q2mat(const vec4* a, mat3* c) {
  vec4 b;
  normalize(a, &b);
#if 0
  c->s0.x = 1.0f - 2.0f * (b.y * b.y + b.z * b.z);
  c->s0.y = 2.0f * (b.x * b.y + b.w * b.z);
  c->s0.z = 2.0f * (b.x * b.z - b.w * b.y);
  c->s0.w = 0;
  c->s1.x = 2.0f * (b.x * b.y - b.w * b.z);
  c->s1.y = 1.0f - 2.0f * (b.x * b.x + b.z * b.z);
  c->s1.z = 2.0f * (b.y * b.z + b.w * b.x);
  c->s1.w = 0;
  c->s2.x = 2.0f * (b.x * b.z + b.w * b.y);
  c->s2.y = 2.0f * (b.y * b.z - b.w * b.x);
  c->s2.z = 1.0f - 2.0f * (b.x * b.x + b.y * b.y);
  c->s2.w = 0;
#else
  // refer to matlab quat2dcm
  c->s0.x = b.w * b.w + b.x * b.x - b.y * b.y - b.z * b.z;
  c->s0.y = 2 * b.x * b.y + 2 * b.w * b.z;
  c->s0.z = 2 * b.x * b.z - 2 * b.w * b.y;
  c->s0.w = 0;
  c->s1.x = 2 * b.x * b.y - 2 * b.w * b.z;
  c->s1.y = b.w * b.w - b.x * b.x + b.y * b.y - b.z * b.z;
  c->s1.z = 2 * b.y * b.z + 2 * b.w * b.x;
  c->s1.w = 0;
  c->s2.x = 2 * b.x * b.z + 2 * b.w * b.y;
  c->s2.y = 2 * b.y * b.z - 2 * b.w * b.x;
  c->s2.z = b.w * b.w - b.x * b.x - b.y * b.y + b.z * b.z;
  c->s2.w = 0;
#endif
}

// refer to matlab quat2angle 'xyz'
void q2rot(const vec4* a, double* ax, double* ay, double* az) {
  vec4 b;
  normalize(a, &b);
  double r11 = -2 * (b.y * b.z - b.w * b.x);
  double r12 = b.w * b.w + b.x * b.x - b.y * b.y - b.z * b.z;
  double r21 = 2 * (b.x * b.z + b.w * b.y);
  double r31 = -2 * (b.x * b.y - b.w * b.z);
  double r32 = b.w * b.w - b.x * b.x - b.y * b.y + b.z * b.z;
  *ax = atan2(r11, r12);
  *ay = asin(r21);
  *az = atan2(r31, r32);
}

void rot_x(double angle, mat3 *c) {
  c->s0.x = 1;
  c->s0.y = 0;
  c->s0.z = 0;
  c->s0.w = 0;
  c->s1.x = 0;
  c->s1.y = cos(angle);
  c->s1.z = sin(angle);
  c->s1.w = 0;
  c->s2.x = 0;
  c->s2.y = -sin(angle);
  c->s2.z = cos(angle);
  c->s2.w = 0;
}

void rot_y(double angle, mat3 *c) {
  c->s0.x = cos(angle);
  c->s0.y = 0;
  c->s0.z = -sin(angle);
  c->s0.w = 0;
  c->s1.x = 0;
  c->s1.y = 1;
  c->s1.z = 0;
  c->s1.w = 0;
  c->s2.x = sin(angle);
  c->s2.y = 0;
  c->s2.z = cos(angle);
  c->s2.w = 0;
}

void rot_z(double angle, mat3 *c) {
  c->s0.x = cos(angle);
  c->s0.y = sin(angle);
  c->s0.z = 0;
  c->s0.w = 0;
  c->s1.x = -sin(angle);
  c->s1.y = cos(angle);
  c->s1.z = 0;
  c->s1.w = 0;
  c->s2.x = 0;
  c->s2.y = 0;
  c->s2.z = 1;
  c->s2.w = 0;
}

void display(const vec4* c) {
  printf("%lf %lf %lf %lf\n", c->x, c->y, c->z, c->w);
}

void display(const mat3* c) {
  printf("%lf %lf %lf\n", c->s0.x, c->s0.y, c->s0.z);
  printf("%lf %lf %lf\n", c->s1.x, c->s1.y, c->s1.z);
  printf("%lf %lf %lf\n", c->s2.x, c->s2.y, c->s2.z);
}