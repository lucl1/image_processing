#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <float.h>
#include <math.h>
#include <vector>
#include "cl_runtime.h"
#include "video_stab_lc.h"
#include "quaternion.h"
#include "UKF.h"

using namespace std;

//#define DUMP_SRC_DATA
#define DUMP_DST_DATA
#define BLACK_BORDER_CONSTRAINT_SEARCH_SIZE 1000
#define BLACK_BORDER_CONSTRAINT_SLICE_SIZE 4
//#define ENABLE_PROFILING_CL_KERNEL

#ifdef _WIN32
#include <windows.h>
#define DEBUG(...) printf(__VA_ARGS__)
#define ERROR(...) printf(__VA_ARGS__)
#else
#include <unistd.h>
#include <pthread.h>
#ifdef __ANDROID__
#include <android/sensor.h>
#include <android/looper.h>
#include <android/log.h>
#include <sys/time.h>
#include <sys/resource.h>
#define DEBUG(...) __android_log_print(ANDROID_LOG_DEBUG, "video_stab_lc", __VA_ARGS__)
//#define DEBUG(...) printf(__VA_ARGS__)
#define ERROR(...) __android_log_print(ANDROID_LOG_ERROR, "video_stab_lc", __VA_ARGS__)
//#define ERROR(...) printf(__VA_ARGS__)
//#define ENABLE_IMPORT_MEMORY_ARM
#else
#define DEBUG(...) printf(__VA_ARGS__)
#define ERROR(...) printf(__VA_ARGS__)
#endif
#endif

typedef struct pose {
  double t;
  vec4 q;
} pose;

#ifdef DUMP_SRC_DATA
typedef struct dump_sensor_data {
  double et; // sensor event time
  double gx; // gyro x value (rad/s)
  double gy; // gyro y value (rad/s)
  double gz; // gyro z value (rad/s)
} dump_sensor_data;
typedef struct dump_video_data {
  double st; // frame start time
  double rt; // frame readout time
} dump_video_data;
#endif

#ifdef DUMP_DST_DATA
typedef struct dump_pose_data {
  vec4 p; // original camera pose
  vec4 q; // smoothed camera pose
} dump_pose_data;
#endif

 /* UKF filter functions for camera rotation smoothing */
#define UKF_STATE_SIZE  7
#define UKF_MEASURE_SIZE 4
void ukf_f_func(double *s_k, double dt, double *s_k_1) { // s_k: Kth state, s_k_1: (K+1)th state
  vec4 p, q;
  p.w = s_k[0];
  p.x = s_k[1];
  p.y = s_k[2];
  p.z = s_k[3];
  double gx = s_k[4];
  double gy = s_k[5];
  double gz = s_k[6];
  integrate(&p, gx, gy, gz, dt, &q); // estimate next state
  s_k_1[0] = q.w;
  s_k_1[1] = q.x;
  s_k_1[2] = q.y;
  s_k_1[3] = q.z;
  s_k_1[4] = gx; // constant-velocity model, so use the velocity of Kth's as (K+1)th's
  s_k_1[5] = gy;
  s_k_1[6] = gz;
}
void ukf_h_func(double *s_k, double *z_k) {
  z_k[0] = s_k[0];
  z_k[1] = s_k[1];
  z_k[2] = s_k[2];
  z_k[3] = s_k[3];
}

#if defined(__GNUC__)
#define CHECKSTATUS(expr)  __CHECKSTATUS(expr, __FILE__, __LINE__, __func__)
#else /* defined(__MSVC__) */
#define CHECKSTATUS(expr)  __CHECKSTATUS(expr, __FILE__, __LINE__)
#endif

static inline void __CHECKSTATUS(cl_int err, const char *file, const int line, const char *func = "") {
  if (CL_SUCCESS != err) {
    char msg[255];
    switch (err)
    {
    case CL_DEVICE_NOT_FOUND:
      strcpy(msg, "CL_DEVICE_NOT_FOUND");
      break;
    case CL_DEVICE_NOT_AVAILABLE:
      strcpy(msg, "CL_DEVICE_NOT_AVAILABLE");
      break;
    case CL_COMPILER_NOT_AVAILABLE:
      strcpy(msg, "CL_COMPILER_NOT_AVAILABLE");
      break;
    case CL_MEM_OBJECT_ALLOCATION_FAILURE:
      strcpy(msg, "CL_MEM_OBJECT_ALLOCATION_FAILURE");
      break;
    case CL_OUT_OF_RESOURCES:
      strcpy(msg, "CL_OUT_OF_RESOURCES");
      break;
    case CL_OUT_OF_HOST_MEMORY:
      strcpy(msg, "CL_OUT_OF_HOST_MEMORY");
      break;
    case CL_PROFILING_INFO_NOT_AVAILABLE:
      strcpy(msg, "CL_PROFILING_INFO_NOT_AVAILABLE");
      break;
    case CL_MEM_COPY_OVERLAP:
      strcpy(msg, "CL_MEM_COPY_OVERLAP");
      break;
    case CL_IMAGE_FORMAT_MISMATCH:
      strcpy(msg, "CL_IMAGE_FORMAT_MISMATCH");
      break;
    case CL_IMAGE_FORMAT_NOT_SUPPORTED:
      strcpy(msg, "CL_IMAGE_FORMAT_NOT_SUPPORTED");
      break;
    case CL_BUILD_PROGRAM_FAILURE:
      strcpy(msg, "CL_BUILD_PROGRAM_FAILURE");
      break;
    case CL_MAP_FAILURE:
      strcpy(msg, "CL_MAP_FAILURE");
      break;
    case CL_MISALIGNED_SUB_BUFFER_OFFSET:
      strcpy(msg, "CL_MISALIGNED_SUB_BUFFER_OFFSET");
      break;
    case CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST:
      strcpy(msg, "CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST");
      break;
    case CL_INVALID_VALUE:
      strcpy(msg, "CL_INVALID_VALUE");
      break;
    case CL_INVALID_DEVICE_TYPE:
      strcpy(msg, "CL_INVALID_DEVICE_TYPE");
      break;
    case CL_INVALID_PLATFORM:
      strcpy(msg, "CL_INVALID_PLATFORM");
      break;
    case CL_INVALID_DEVICE:
      strcpy(msg, "CL_INVALID_DEVICE");
      break;
    case CL_INVALID_CONTEXT:
      strcpy(msg, "CL_INVALID_CONTEXT");
      break;
    case CL_INVALID_QUEUE_PROPERTIES:
      strcpy(msg, "CL_INVALID_QUEUE_PROPERTIES");
      break;
    case CL_INVALID_COMMAND_QUEUE:
      strcpy(msg, "CL_INVALID_COMMAND_QUEUE");
      break;
    case CL_INVALID_HOST_PTR:
      strcpy(msg, "CL_INVALID_HOST_PTR");
      break;
    case CL_INVALID_MEM_OBJECT:
      strcpy(msg, "CL_INVALID_MEM_OBJECT");
      break;
    case CL_INVALID_IMAGE_FORMAT_DESCRIPTOR:
      strcpy(msg, "CL_INVALID_IMAGE_FORMAT_DESCRIPTOR");
      break;
    case CL_INVALID_IMAGE_SIZE:
      strcpy(msg, "CL_INVALID_IMAGE_SIZE");
      break;
    case CL_INVALID_SAMPLER:
      strcpy(msg, "CL_INVALID_SAMPLER");
      break;
    case CL_INVALID_BINARY:
      strcpy(msg, "CL_INVALID_BINARY");
      break;
    case CL_INVALID_BUILD_OPTIONS:
      strcpy(msg, "CL_INVALID_BUILD_OPTIONS");
      break;
    case CL_INVALID_PROGRAM:
      strcpy(msg, "CL_INVALID_PROGRAM");
      break;
    case CL_INVALID_PROGRAM_EXECUTABLE:
      strcpy(msg, "CL_INVALID_PROGRAM_EXECUTABLE");
      break;
    case CL_INVALID_KERNEL_NAME:
      strcpy(msg, "CL_INVALID_KERNEL_NAME");
      break;
    case CL_INVALID_KERNEL_DEFINITION:
      strcpy(msg, "CL_INVALID_KERNEL_DEFINITION");
      break;
    case CL_INVALID_KERNEL:
      strcpy(msg, "CL_INVALID_KERNEL");
      break;
    case CL_INVALID_ARG_INDEX:
      strcpy(msg, "CL_INVALID_ARG_INDEX");
      break;
    case CL_INVALID_ARG_VALUE:
      strcpy(msg, "CL_INVALID_ARG_VALUE");
      break;
    case CL_INVALID_ARG_SIZE:
      strcpy(msg, "CL_INVALID_ARG_SIZE");
      break;
    case CL_INVALID_KERNEL_ARGS:
      strcpy(msg, "CL_INVALID_KERNEL_ARGS");
      break;
    case CL_INVALID_WORK_DIMENSION:
      strcpy(msg, "CL_INVALID_WORK_DIMENSION");
      break;
    case CL_INVALID_WORK_GROUP_SIZE:
      strcpy(msg, "CL_INVALID_WORK_GROUP_SIZE");
      break;
    case CL_INVALID_WORK_ITEM_SIZE:
      strcpy(msg, "CL_INVALID_WORK_ITEM_SIZE");
      break;
    case CL_INVALID_GLOBAL_OFFSET:
      strcpy(msg, "CL_INVALID_GLOBAL_OFFSET");
      break;
    case CL_INVALID_EVENT_WAIT_LIST:
      strcpy(msg, "CL_INVALID_EVENT_WAIT_LIST");
      break;
    case CL_INVALID_EVENT:
      strcpy(msg, "CL_INVALID_EVENT");
      break;
    case CL_INVALID_OPERATION:
      strcpy(msg, "CL_INVALID_OPERATION");
      break;
    case CL_INVALID_GL_OBJECT:
      strcpy(msg, "CL_INVALID_GL_OBJECT");
      break;
    case CL_INVALID_BUFFER_SIZE:
      strcpy(msg, "CL_INVALID_BUFFER_SIZE");
      break;
    case CL_INVALID_MIP_LEVEL:
      strcpy(msg, "CL_INVALID_MIP_LEVEL");
      break;
    case CL_INVALID_GLOBAL_WORK_SIZE:
      strcpy(msg, "CL_INVALID_GLOBAL_WORK_SIZE");
      break;
    case CL_INVALID_PROPERTY:
      strcpy(msg, "CL_INVALID_PROPERTY");
      break;
    case CL_INVALID_IMAGE_DESCRIPTOR:
      strcpy(msg, "CL_INVALID_IMAGE_DESCRIPTOR");
      break;
    case CL_INVALID_COMPILER_OPTIONS:
      strcpy(msg, "CL_INVALID_COMPILER_OPTIONS");
      break;
    case CL_INVALID_LINKER_OPTIONS:
      strcpy(msg, "CL_INVALID_LINKER_OPTIONS");
      break;
    case CL_INVALID_DEVICE_PARTITION_COUNT:
      strcpy(msg, "CL_INVALID_DEVICE_PARTITION_COUNT");
      break;
    default:
      sprintf(msg, "Unknown CL error code(%d)", err);
      break;
    }
    ERROR("CL ERROR: %s in %s, file %s, line %d\n", msg, func, file, line);
    getchar();
    exit(-1);
  }
}

#if defined(__GNUC__)
#define RUN(name, cmd_queue, kernel, work_dim, global_work_offset, global_work_size, local_work_size, num_events_in_wait_list, event_wait_list, event)  __RUN(name, cmd_queue, kernel, work_dim, global_work_offset, global_work_size, local_work_size, num_events_in_wait_list, event_wait_list, event, __FILE__, __LINE__, __func__)
#else /* defined(__MSVC__) */
#define RUN(name, cmd_queue, kernel, work_dim, global_work_offset, global_work_size, local_work_size, num_events_in_wait_list, event_wait_list, event)  __RUN(name, cmd_queue, kernel, work_dim, global_work_offset, global_work_size, local_work_size, num_events_in_wait_list, event_wait_list, event, __FILE__, __LINE__)
#endif

static inline void __RUN(const char *name, cl_command_queue cmd_queue, cl_kernel kernel, cl_uint work_dim, const size_t *global_work_offset, const size_t *global_work_size, const size_t *local_work_size, cl_uint num_events_in_wait_list, const cl_event * event_wait_list, cl_event * event, const char *file, const int line, const char *func = "") {
#ifdef ENABLE_PROFILING_CL_KERNEL
  cl_event e = NULL;
  CHECKSTATUS(clEnqueueNDRangeKernel(cmd_queue,
    kernel,
    work_dim,
    global_work_offset,
    global_work_size,
    NULL,
    0,
    NULL,
    &e));

  cl_ulong start_time, end_time, queue_time;

  CHECKSTATUS(clWaitForEvents(1, &e));

  CHECKSTATUS(clGetEventProfilingInfo(e,
    CL_PROFILING_COMMAND_START,
    sizeof(cl_ulong),
    &start_time,
    0));

  CHECKSTATUS(clGetEventProfilingInfo(e,
    CL_PROFILING_COMMAND_END,
    sizeof(cl_ulong),
    &end_time,
    0));

  CHECKSTATUS(clGetEventProfilingInfo(e,
    CL_PROFILING_COMMAND_QUEUED,
    sizeof(cl_ulong),
    &queue_time,
    0));

  double execute_time = (double)(end_time - start_time) / 1000000;
  double total_time = (double)(end_time - queue_time) / 1000000;

  printf( "Kernel Name                     Execute time(ms)    Lauch time(ms)      Total time(ms)\n" );
  printf("%-32s%-20.2f%-20.2f%-20.2f\n", name, execute_time, total_time - execute_time, total_time);
  clReleaseEvent(e);
#else
  CHECKSTATUS(clEnqueueNDRangeKernel(cmd_queue,
    kernel,
    work_dim,
    global_work_offset,
    global_work_size,
    local_work_size,
    num_events_in_wait_list,
    event_wait_list,
    event));
#endif
  clFlush(cmd_queue);
}

static inline int div_up(int total, int grain) {
  return ( total + grain - 1 ) / grain;
}

char source[] = "\n\
__constant const sampler_t g_sampler = CLK_FILTER_LINEAR | CLK_NORMALIZED_COORDS_FALSE | CLK_ADDRESS_CLAMP;\n\
__kernel void inverse_warp(const int crop_x, \n\
                           const int crop_y, \n\
                           const int dst_offset_x, \n\
                           const int dst_offset_y, \n\
                           const float mesh_grid_scanlines, \n\
                           const global float4* mesh_grid_homographies, \n\
                           __read_only image2d_t src_y, \n\
                           __read_only image2d_t src_uv, \n\
                           __write_only image2d_t dst_y, \n\
                           __write_only image2d_t dst_uv){\n\
  // first line \n\
  int2 id = (int2)(get_global_id(0), get_global_id(1)) << 1;\n\
  // Y0 and UV \n\
  int2 dst_coord = id + (int2)(dst_offset_x, dst_offset_y);\n\
  float4 cropped_coord = (float4)(convert_float2(id + (int2)(crop_x, crop_y)), (float2)(1, 0));\n\
  int mesh_grid_offset = 3 * (int)(cropped_coord.y / mesh_grid_scanlines);\n\
  float4 h0 = mesh_grid_homographies[mesh_grid_offset];\n\
  float4 h1 = mesh_grid_homographies[mesh_grid_offset + 1];\n\
  float4 h2 = mesh_grid_homographies[mesh_grid_offset + 2];\n\
  float z = dot(h2, cropped_coord);\n\
  float2 src_coord = (float2)(dot(h0, cropped_coord), dot(h1, cropped_coord)) / z;\n\
  write_imagef(dst_y, dst_coord, read_imagef(src_y, g_sampler, src_coord));\n\
  write_imagef(dst_uv, dst_coord >> 1, read_imagef(src_uv, g_sampler, src_coord / 2));\n\
  // Y1 \n\
  dst_coord.x++;\n\
  cropped_coord.x += 1.0;\n\
  z = dot(h2, cropped_coord);\n\
  src_coord = (float2)(dot(h0, cropped_coord), dot(h1, cropped_coord)) / z;\n\
  write_imagef(dst_y, dst_coord, read_imagef(src_y, g_sampler, src_coord));\n\
  // second line \n\
  // Y2 \n\
  dst_coord.x--;\n\
  dst_coord.y++;\n\
  cropped_coord.x -= 1.0;\n\
  cropped_coord.y += 1.0;\n\
  mesh_grid_offset = 3 * (int)(cropped_coord.y / mesh_grid_scanlines);\n\
  h0 = mesh_grid_homographies[mesh_grid_offset];\n\
  h1 = mesh_grid_homographies[mesh_grid_offset + 1];\n\
  h2 = mesh_grid_homographies[mesh_grid_offset + 2];\n\
  z = dot(h2, cropped_coord);\n\
  src_coord = (float2)(dot(h0, cropped_coord), dot(h1, cropped_coord)) / z;\n\
  write_imagef(dst_y, dst_coord, read_imagef(src_y, g_sampler, src_coord));\n\
  // Y3 \n\
  dst_coord.x++;\n\
  cropped_coord.x += 1.0;\n\
  z = dot(h2, cropped_coord);\n\
  src_coord = (float2)(dot(h0, cropped_coord), dot(h1, cropped_coord)) / z;\n\
  write_imagef(dst_y, dst_coord, read_imagef(src_y, g_sampler, src_coord));\n\
}\n\
";

class CPX { // pose estimator context
public:
  bool auto_updating;
#ifdef _WIN32
  HANDLE mtx;
#else
  pthread_mutex_t mtx;
#ifdef __ANDROID__
  pthread_t sensor_worker_thread;
  bool sensor_worker_running;
#endif
#endif
  // runtime variables
  vector<pose> poses; // camera accumulated poses(calculated from sensor data)
  float last_gx;
  float last_gy;
  float last_gz;
#ifdef DUMP_SRC_DATA
  vector<dump_sensor_data> dump_sensor_datas;
#endif
  // functions
  CPX();
  ~CPX();
  int start();
  int stop();
  int process(double et, float gx, float gy, float gz);
  vec4 search(double st, int* offset);
};

CPX::CPX() {
  auto_updating = true;
#ifdef _WIN32
  mtx = CreateMutex(NULL, FALSE, NULL);
#else
  pthread_mutex_init(&mtx, NULL);
#ifdef __ANDROID__
  sensor_worker_thread = 0;
#endif
#endif
}

CPX::~CPX() {
#ifdef _WIN32
  CloseHandle(mtx);
#else
#ifdef __ANDROID__
  if (sensor_worker_thread) {
    sensor_worker_running = false;
    pthread_join(sensor_worker_thread, NULL);
  }
#endif
  pthread_mutex_destroy(&mtx);
#endif
}

#ifdef __ANDROID__
void* SENSOR_WORKER(void* p) {
  int priority = getpriority(PRIO_PROCESS, 0);
  DEBUG("sensor work thread old_priority = %d\n", priority);
  setpriority(PRIO_PROCESS, 0, -20); // ANDROID_PRIORITY_URGENT_DISPLAY = -8
  //set_sched_policy(0, 1); // SP_FOREGROUND = 1
  priority = getpriority(PRIO_PROCESS, 0);
  DEBUG("sensor work thread new_priority = %d\n", priority);
  assert(p);
  // if android, create thread to recieve sensor data
  ALooper* looper = ALooper_forThread();
  if (looper == NULL) {
    looper = ALooper_prepare(ALOOPER_PREPARE_ALLOW_NON_CALLBACKS);
  }
  assert(looper);
  ASensorManager* mgr = ASensorManager_getInstance();
  assert(mgr);
  ASensorEventQueue* queue = ASensorManager_createEventQueue(mgr, looper, 1, NULL, NULL);
  assert(queue);
  const ASensor* gyro = ASensorManager_getDefaultSensor(mgr, ASENSOR_TYPE_GYROSCOPE);
  if (gyro) {
    ASensorEventQueue_enableSensor(queue, gyro);
    ASensorEventQueue_setEventRate(queue, gyro, ASensor_getMinDelay(gyro));
    int ident, events;
    while (((CPX*)p)->sensor_worker_running && (ident = ALooper_pollAll(-1, NULL, &events, NULL) >= 0)) {
      if (ident == 1) {
        ASensorEvent event;
        while (ASensorEventQueue_getEvents(queue, &event, 1) > 0) {
          if (event.type == ASENSOR_TYPE_GYROSCOPE) {
            ((CPX*)p)->process(event.timestamp / 1000000000.0, event.data[0], event.data[1], event.data[2]);
          }
        }
      }
    }
  } else {
    ERROR("start sensor thread failed, no gyroscope is found.\n");
  }
}
#endif

int CPX::start() {
#ifdef DUMP_SRC_DATA
  dump_sensor_datas.clear();
#endif
  poses.clear();
#ifdef __ANDROID__
  if (auto_updating && !sensor_worker_thread) {
    sensor_worker_running = true;
    pthread_create(&sensor_worker_thread, NULL, &SENSOR_WORKER, (void *)this);
  }
#endif
  return 0;
}

int CPX::stop() {
#ifdef DUMP_SRC_DATA
#ifdef __ANDROID__
  FILE* fp = fopen("/data/misc/media/gyro.txt", "w");
#else
  FILE* fp = fopen("gyro.txt", "w");
#endif
  if (fp) {
    for (int i = 0; i < dump_sensor_datas.size(); i++) {
      fprintf(fp, "%lf,%f,%f,%f,\n", dump_sensor_datas[i].et, dump_sensor_datas[i].gx, dump_sensor_datas[i].gy, dump_sensor_datas[i].gz);
    }
  }
  fclose(fp);
#endif
#ifdef __ANDROID__
  if (sensor_worker_thread) {
    sensor_worker_running = false;
    pthread_join(sensor_worker_thread, NULL);
    sensor_worker_thread = 0;
  }
#endif
  return 0;
}

int CPX::process(double et, float gx, float gy, float gz) {
#ifdef DUMP_SRC_DATA
  dump_sensor_data dsd;
  dsd.et = et;
  dsd.gx = gx;
  dsd.gy = gy;
  dsd.gz = gz;
  dump_sensor_datas.push_back(dsd);
  return 0;
#endif
  vec4 q;
#ifdef _WIN32
  WaitForSingleObject(mtx, INFINITE);
#else
  pthread_mutex_lock(&mtx);
#endif
  int size = poses.size();
#ifdef _WIN32
  ReleaseMutex(mtx);
#else
  pthread_mutex_unlock(&mtx);
#endif
  if (size > 0) {
    double dt = et - poses[size - 1].t;
    integrate(&poses[size - 1].q, last_gx, last_gy, last_gz, dt, &q);
  } else {
    eye(&q);
  }
  pose o;
  o.t = et;
  o.q = q;
#ifdef _WIN32
  WaitForSingleObject(mtx, INFINITE);
#else
  pthread_mutex_lock(&mtx);
#endif
  poses.push_back(o);
  last_gx = gx;
  last_gy = gy;
  last_gz = gz;
#ifdef _WIN32
  ReleaseMutex(mtx);
#else
  pthread_mutex_unlock(&mtx);
#endif
  return 0;
}

vec4 CPX::search(double st, int* offset) {
  do {
#ifdef _WIN32
    WaitForSingleObject(mtx, INFINITE);
#else
    pthread_mutex_lock(&mtx);
#endif
    int size = poses.size();
#ifdef _WIN32
    ReleaseMutex(mtx);
#else
    pthread_mutex_unlock(&mtx);
#endif
    while (*offset < size && poses[*offset].t < st) {
      (*offset)++;
    }
    if (*offset < size) { // found
      break;
    }
    DEBUG("sync gyro & video failed, now sleep 5ms to wait for gyro data...\n");
#ifdef _WIN32
    Sleep(5);
#else
    usleep(5000);
#endif
  } while (1);
  *offset = (*offset) > 0 ? ((*offset) - 1) : (*offset);
  vec4 p;
  slerp(&poses[*offset].q, &poses[(*offset) + 1].q, (st - poses[*offset].t) / (poses[(*offset) + 1].t - poses[(*offset)].t), &p);
  return p;
}

class CSX { // video stabilizer context
public:
  // parameters
  int src_width;
  int src_height;
  int dst_width;
  int dst_height;
  int crop_width;
  int crop_height;
  int constraint_width;
  int constraint_height;
  double camera_horizontal_view_angle;
  double camera_vertical_view_angle;
  double cam2gyro_rotation_x;
  double cam2gyro_rotation_y;
  double cam2gyro_rotation_z;
  int pixel_format;
  double ukf_process_noise;
  double ukf_measure_noise;
  double ukf_kappa;
  double ukf_alpha;
  double ukf_beta;
  int mesh_grid_rows; // how many rows in the mesh grid
  float mesh_grid_scanlines; // how many scanlines in each mesh grid row: mesh_grid_scanlines = src_width / mesh_grid_rows
  // temporary variables
  mat3 KA;
  mat3 invAinvK;
  // runtime variables
  int last_pose_idx;
  int last_video_idx;
  double last_video_st;
  UKF* ukf;
  double ukf_X[UKF_STATE_SIZE];
  double ukf_P[UKF_STATE_SIZE * UKF_STATE_SIZE];
  // opencl variables
  cl_context context;
  cl_command_queue cmd_queue;
  cl_device_id device_id;
  char device_name[256];
  char device_version[256];
  cl_program program;
  cl_kernel kernel;
  cl_mem mesh_grid_homographies_dev_ptr;
  vec4 *mesh_grid_deltas_host_ptr;
#ifndef ENABLE_IMPORT_MEMORY_ARM
  cl_mem src_y_dev_ptr;
  cl_mem src_uv_dev_ptr;
  cl_mem dst_y_dev_ptr;
  cl_mem dst_uv_dev_ptr;
#endif
#ifdef DUMP_SRC_DATA
  vector<dump_video_data> dump_video_datas;
  FILE *dump_video_frames;
#endif
#ifdef DUMP_DST_DATA
  vector<dump_pose_data> dump_pose_datas;
#endif
  // functions
  CSX();
  ~CSX();
  int createUKFfilter(double process_noise, double measure_noise, double kappa, double alpha, double beta);
  void releaseUKFfilter();
  int createBuffers(int w, int h, int cw, int ch, int mgrs);
  void releaseBuffers();
  int createKernels(int pix_fmt);
  void releaseKernels();
  int start();
  int stop();
  int process(CPX *cpx, double st, double rt, unsigned char *src_yuv, unsigned char *dst_yuv);
};

CSX::CSX() {
  // reset parameters
  src_width = 0;
  src_height = 0;
  dst_width = 0;
  dst_height = 0;
  crop_width = 0;
  crop_height = 0;
  constraint_width = 0;
  constraint_height = 0;
  camera_horizontal_view_angle = 0.0f;
  camera_vertical_view_angle = 0.0f;
  cam2gyro_rotation_x = 0.0f;
  cam2gyro_rotation_y = 0.0f;
  cam2gyro_rotation_z = 0.0f;
  pixel_format = -1;
  ukf = NULL;
  ukf_process_noise = -1;
  ukf_measure_noise = -1;
  ukf_kappa = -1;
  ukf_alpha = -1;
  ukf_beta = -1;
  mesh_grid_rows = -1;
  context = NULL;
  cmd_queue = NULL;
  program = NULL;
  kernel = NULL;
  mesh_grid_homographies_dev_ptr = NULL;
  mesh_grid_deltas_host_ptr = NULL;
#ifndef ENABLE_IMPORT_MEMORY_ARM
  src_y_dev_ptr = NULL;
  src_uv_dev_ptr = NULL;
  dst_y_dev_ptr = NULL;
  dst_uv_dev_ptr = NULL;
#endif

  /* initialize cl runtime */
  cl_int status = CL_SUCCESS;
  /* query all the platforms, set the first one as default*/
  cl_uint numPlatformIds = 0;
  status = clGetPlatformIDs(0, NULL, &numPlatformIds);
  if (status == CL_DEVICE_NOT_FOUND) {
    DEBUG("cl platform not found\n");
    exit(-1);
  }
  cl_platform_id *platformIds = new cl_platform_id[numPlatformIds];
  assert(!!platformIds);
  CHECKSTATUS(clGetPlatformIDs(numPlatformIds, platformIds, NULL));
  DEBUG("%d cl platforms found:\n", numPlatformIds);
  char platformName[256];
  char platformVendor[256];
  char platformVersion[256];
  for (unsigned n = 0; n < numPlatformIds; ++n) {
    CHECKSTATUS(clGetPlatformInfo(platformIds[n], CL_PLATFORM_NAME, 256, platformName, NULL));
    CHECKSTATUS(clGetPlatformInfo(platformIds[n], CL_PLATFORM_VENDOR, 256, platformVendor, NULL));
    CHECKSTATUS(clGetPlatformInfo(platformIds[n], CL_PLATFORM_VERSION, 256, platformVersion, NULL));
    if (n == 0) {
      DEBUG("%s %s %s[selected]\n", platformName, platformVendor, platformVersion);
    } else {
      DEBUG("%s %s %s\n", platformName, platformVendor, platformVersion);
    }
  }
  cl_platform_id platformId = platformIds[0];
  delete[] platformIds;
  /* query all the devices, set the first one as default*/
  cl_uint numDeviceIds;
  status = clGetDeviceIDs(platformId, CL_DEVICE_TYPE_GPU, 0, NULL, &numDeviceIds);
  if (status == CL_DEVICE_NOT_FOUND) {
    DEBUG("cl gpu device not found\n");
    exit(-1);
  }
  cl_device_id *deviceIds = new cl_device_id[numDeviceIds];
  assert(!!deviceIds);
  CHECKSTATUS(clGetDeviceIDs(platformId, CL_DEVICE_TYPE_GPU, numDeviceIds, deviceIds, NULL));
  DEBUG("%d cl gpu devices found:\n", numDeviceIds);
  char deviceName[256];
  char deviceVersion[256];
  for(unsigned n = 0; n < numDeviceIds; n++) {
    CHECKSTATUS(clGetDeviceInfo(deviceIds[n], CL_DEVICE_NAME, 256, deviceName, NULL));
    CHECKSTATUS(clGetDeviceInfo(deviceIds[n], CL_DEVICE_VERSION, 256, deviceVersion, NULL));
    if (n == 0) {
      strcpy(device_name, deviceName);
      strcpy(device_version, deviceVersion);
      device_id = deviceIds[n];
      DEBUG("%s %s[selected]\n", deviceName, deviceVersion);
    } else {
      DEBUG("%s %s\n", deviceName, deviceVersion);
    }
  }
  delete[] deviceIds;
  /* intialize the context and command queue */
  cl_context_properties cps[3] = {
    CL_CONTEXT_PLATFORM, ( cl_context_properties )( platformId ), 0
  };
  context = clCreateContext(cps, 1, &device_id, NULL, NULL, &status);
  CHECKSTATUS(status);
#ifdef ENABLE_PROFILING_CL_KERNEL
  cmd_queue = clCreateCommandQueue(context, device_id, CL_QUEUE_PROFILING_ENABLE, &status);
#else
  cmd_queue = clCreateCommandQueue(context, device_id, 0, &status);
#endif
#if 0
  cl_uint numSupportedImageFormats = 0;
  CHECKSTATUS(clGetSupportedImageFormats(context, 0, CL_MEM_OBJECT_IMAGE2D, 0, NULL, &numSupportedImageFormats));
  printf("%d Image formats supported\n", numSupportedImageFormats);
  cl_image_format* supportedImageFormats = new cl_image_format[numSupportedImageFormats];
  CHECKSTATUS(clGetSupportedImageFormats(context, 0, CL_MEM_OBJECT_IMAGE2D, numSupportedImageFormats, supportedImageFormats, NULL));
  for (unsigned int i = 0; i < numSupportedImageFormats; i++) {
    switch (supportedImageFormats[i].image_channel_order) {
    case CL_R:
      DEBUG("CL_R");
      break;
    case CL_A:
      DEBUG("CL_A");
      break;
    case CL_RG:
      DEBUG("CL_RG");
      break;
    case CL_RA:
      DEBUG("CL_RA");
      break;
    case CL_RGB:
      DEBUG("CL_RGB");
      break;
    case CL_RGBA:
      DEBUG("CL_RGBA");
      break;
    case CL_BGRA:
      DEBUG("CL_BGRA");
      break;
    case CL_ARGB:
      DEBUG("CL_ARGB");
      break;
    case CL_INTENSITY:
      DEBUG("CL_INTENSITY");
      break;
    case CL_LUMINANCE:
      DEBUG("CL_LUMINANCE");
      break;
    case CL_Rx:
      DEBUG("CL_Rx");
      break;
    case CL_RGx:
      DEBUG("CL_RGx");
      break;
    case CL_RGBx:
      DEBUG("CL_RGBx");
      break;
    default:
      DEBUG("Unknown image channel order");
      break;
    }
    printf(",");
    switch (supportedImageFormats[i].image_channel_data_type)
    {
    case CL_SNORM_INT8:
      DEBUG("CL_SNORM_INT8");
      break;
    case CL_SNORM_INT16:
      DEBUG("CL_SNORM_INT16");
      break;
    case CL_UNORM_INT8:
      DEBUG("CL_UNORM_INT8");
      break;
    case CL_UNORM_INT16:
      DEBUG("CL_UNORM_INT16");
      break;
    case CL_UNORM_SHORT_565:
      DEBUG("CL_UNORM_SHORT_565");
      break;
    case CL_UNORM_SHORT_555:
      DEBUG("CL_UNORM_SHORT_555");
      break;
    case CL_UNORM_INT_101010:
      DEBUG("CL_UNORM_INT_101010");
      break;
    case CL_SIGNED_INT8:
      DEBUG("CL_SIGNED_INT8");
      break;
    case CL_SIGNED_INT16:
      DEBUG("CL_SIGNED_INT16");
      break;
    case CL_SIGNED_INT32:
      DEBUG("CL_SIGNED_INT32");
      break;
    case CL_UNSIGNED_INT8:
      DEBUG("CL_UNSIGNED_INT8");
      break;
    case CL_UNSIGNED_INT16:
      DEBUG("CL_UNSIGNED_INT16");
      break;
    case CL_UNSIGNED_INT32:
      DEBUG("CL_UNSIGNED_INT32");
      break;
    case CL_HALF_FLOAT:
      DEBUG("CL_HALF_FLOAT");
      break;
    case CL_FLOAT:
      DEBUG("CL_FLOAT");
      break;
    default:
      DEBUG("Unknown image channel data type");
      break;
    }
    DEBUG("\n");
  }
  delete supportedImageFormats;
#endif
  DEBUG("cl context created.\n");
}

CSX::~CSX() {
  releaseBuffers();
  releaseKernels();
  if (cmd_queue) {
    CHECKSTATUS(clReleaseCommandQueue(cmd_queue));
    cmd_queue = NULL;
  }
  if (context) {
    CHECKSTATUS(clReleaseContext(context));
    context = NULL;
  }
  releaseUKFfilter();
  DEBUG("cl context released.\n");
}

int CSX::createUKFfilter(double process_noise, double measure_noise, double kappa, double alpha, double beta) {
  assert(process_noise > 0);
  assert(measure_noise > 0);
  assert(kappa >= 0);
  assert(alpha >= 0);
  assert(beta >= 0);
  ukf_process_noise = process_noise;
  ukf_measure_noise = measure_noise;
  ukf_kappa = kappa;
  ukf_alpha = alpha;
  ukf_beta = beta;
  ukf = UKF_init(ukf_f_func, ukf_h_func, UKF_STATE_SIZE, UKF_MEASURE_SIZE, ukf_process_noise, ukf_measure_noise, ukf_kappa, ukf_alpha, ukf_beta);
  assert(ukf);
  return 0;
}

void CSX::releaseUKFfilter() {
  if (ukf) {
    UKF_release(ukf);
    ukf = NULL;
  }
}

int CSX::createBuffers(int sw, int sh, int dw, int dh, int mgrs) {
  cl_int status = CL_SUCCESS;
  assert(sw > 0);
  assert(sh > 0);
  assert(dw > 0);
  assert(dh > 0);
  assert(mgrs > 0 && mgrs <= sh);
  src_width = sw;
  src_height = sh;
  dst_width = dw;
  dst_height = dh;
  mesh_grid_rows = mgrs;
  mesh_grid_scanlines = sh / (float)mgrs;
  /* create a buffer for storing the delta rotation for each mesh grid row of each frame */
  mesh_grid_deltas_host_ptr = new vec4[mesh_grid_rows];
  assert(mesh_grid_deltas_host_ptr);
  /* create a buffer for storing homography matrix of each mesh grid row of each frame */
  mesh_grid_homographies_dev_ptr = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR, mesh_grid_rows * sizeof(float) * 12, NULL, &status); // 4 x 3
  CHECKSTATUS(status);
#ifndef ENABLE_IMPORT_MEMORY_ARM
  /* create input images */
  cl_image_format src_y_fmt;
  src_y_fmt.image_channel_data_type = CL_UNORM_INT8;
  src_y_fmt.image_channel_order = CL_R;
  cl_image_desc src_y_desc;
  memset(&src_y_desc, 0, sizeof(src_y_desc));
  src_y_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
  src_y_desc.image_width = src_width;
  src_y_desc.image_height = src_height;
  src_y_desc.image_row_pitch = 0;
  src_y_dev_ptr = clCreateImage(context, CL_MEM_READ_ONLY, &src_y_fmt, &src_y_desc, NULL, &status);
  CHECKSTATUS(status);
  cl_image_format src_uv_fmt;
  src_uv_fmt.image_channel_data_type = CL_UNORM_INT8;
  src_uv_fmt.image_channel_order = CL_RG;
  cl_image_desc src_uv_desc;
  memset(&src_uv_desc, 0, sizeof(src_uv_desc));
  src_uv_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
  src_uv_desc.image_width = (src_width + 1) >> 1;
  src_uv_desc.image_height = (src_height + 1) >> 1;
  src_uv_desc.image_row_pitch = 0;
  src_uv_dev_ptr = clCreateImage(context, CL_MEM_READ_ONLY, &src_uv_fmt, &src_uv_desc, NULL, &status);
  CHECKSTATUS(status);
  /* create output images */
  cl_image_format dst_y_fmt;
  dst_y_fmt.image_channel_data_type = CL_UNORM_INT8;
  dst_y_fmt.image_channel_order = CL_R;
  cl_image_desc dst_y_desc;
  memset(&dst_y_desc, 0, sizeof(dst_y_desc));
  dst_y_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
  dst_y_desc.image_width = dst_width;
  dst_y_desc.image_height = dst_height;
  dst_y_desc.image_row_pitch = 0;
  dst_y_dev_ptr = clCreateImage(context, CL_MEM_WRITE_ONLY, &dst_y_fmt, &dst_y_desc, NULL, &status);
  cl_image_format dst_uv_fmt;
  dst_uv_fmt.image_channel_data_type = CL_UNORM_INT8;
  dst_uv_fmt.image_channel_order = CL_RG;
  cl_image_desc dst_uv_desc;
  memset(&dst_uv_desc, 0, sizeof(dst_uv_desc));
  dst_uv_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
  dst_uv_desc.image_width = (dst_width + 1) >> 1;
  dst_uv_desc.image_height = (dst_height + 1) >> 1;
  dst_uv_desc.image_row_pitch = 0;
  dst_uv_dev_ptr = clCreateImage(context, CL_MEM_WRITE_ONLY, &dst_uv_fmt, &dst_uv_desc, NULL, &status);
  CHECKSTATUS(status);
  size_t origin[3] = {0, 0, 0};
  size_t region_y[3] = {dst_width, dst_height, 1};
  size_t region_uv[3] = {(dst_width + 1) >> 1, (dst_height + 1) >> 1, 1};
  unsigned char *zero = new unsigned char[region_y[0] * region_y[1]];
  assert(zero);
  memset(zero, 0, sizeof(unsigned char) * region_y[0] * region_y[1]);
  CHECKSTATUS(clEnqueueWriteImage(cmd_queue, dst_y_dev_ptr, CL_TRUE, origin, region_y, 0, 0, zero, 0, NULL, NULL));
  memset(zero, 128, sizeof(unsigned char) * region_uv[0] * region_uv[1] * 2);
  CHECKSTATUS(clEnqueueWriteImage(cmd_queue, dst_uv_dev_ptr, CL_TRUE, origin, region_uv, 0, 0, zero, 0, NULL, NULL));
  delete zero;
#endif
  DEBUG("cl buffers created.\n");
  return 0;
}

void CSX::releaseBuffers() {
  if (mesh_grid_deltas_host_ptr) {
    delete mesh_grid_deltas_host_ptr;
    mesh_grid_deltas_host_ptr = NULL;
  }
  if (mesh_grid_homographies_dev_ptr) {
    CHECKSTATUS(::clReleaseMemObject(mesh_grid_homographies_dev_ptr));
    mesh_grid_homographies_dev_ptr = NULL;
  }
#ifndef ENABLE_IMPORT_MEMORY_ARM
  if (src_y_dev_ptr) {
    CHECKSTATUS(::clReleaseMemObject(src_y_dev_ptr));
    src_y_dev_ptr = NULL;
  }
  if (src_uv_dev_ptr) {
    CHECKSTATUS(::clReleaseMemObject(src_uv_dev_ptr));
    src_uv_dev_ptr = NULL;
  }
  if (dst_y_dev_ptr) {
    CHECKSTATUS(::clReleaseMemObject(dst_y_dev_ptr));
    dst_y_dev_ptr = NULL;
  }
  if (dst_uv_dev_ptr) {
    CHECKSTATUS(::clReleaseMemObject(dst_uv_dev_ptr));
    dst_uv_dev_ptr = NULL;
  }
#endif
  DEBUG("cl buffers released.\n");
}

int CSX::createKernels(int pix_fmt) {
  cl_int status = CL_SUCCESS;
  assert(pix_fmt == VIDEO_STAB_PIXEL_FORMAT_YUV420_NV12 || pix_fmt == VIDEO_STAB_PIXEL_FORMAT_YUV420_NV21);
  pixel_format = pix_fmt;
  /* build programs */
  char *code = source;
  program = clCreateProgramWithSource(context, 1, (const char **)&code, NULL, &status);
  char options[] = "-cl-fast-relaxed-math -cl-mad-enable -cl-single-precision-constant";
  status = clBuildProgram(program, 0, NULL, options, NULL, NULL);
  if (status != CL_SUCCESS) {
    if (status == CL_BUILD_PROGRAM_FAILURE) {
      cl_int logStatus;
      char *buildLog = NULL;
      size_t buildLogSize = 0;
      logStatus = clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, buildLogSize,
        buildLog, &buildLogSize);
      if (logStatus != CL_SUCCESS) {
        DEBUG("failed to build the program and get the build info.\n");
      }
      buildLog = new char[buildLogSize];
      assert(!!buildLog);
      memset(buildLog, 0, buildLogSize);
      CHECKSTATUS(clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, buildLogSize, buildLog, NULL));
      DEBUG("\n---------------BUILD LOG--------------\n%s\n", buildLog);
      delete buildLog;
      return -1;
    }
  }
  /* create kernel 'interop' */
  kernel = clCreateKernel(program, "inverse_warp", &status);
  CHECKSTATUS(status);
  DEBUG("cl kernels created.\n");
  return 0;
}

void CSX::releaseKernels() {
  if (kernel) {
    CHECKSTATUS(clReleaseKernel(kernel));
    kernel = NULL;
  }
  if (program) {
    CHECKSTATUS(clReleaseProgram(program));
    program = NULL;
  }
  DEBUG("cl kernels released.\n");
}

int CSX::start() {
  // reset runtime variables
  last_pose_idx = 0;
  last_video_idx = 0;
#ifdef DUMP_SRC_DATA
  dump_video_datas.clear();
  dump_video_frames = fopen("/data/misc/media/video.yuv", "wb");
  assert(dump_video_frames);
#endif
#ifdef DUMP_DST_DATA
  dump_pose_datas.clear();
#endif
  return 0;
}

int CSX::stop() {
  FILE *fp = NULL;
#ifdef DUMP_SRC_DATA
#ifdef __ANDROID__
  fp = fopen("/data/misc/media/framestamp.txt", "w");
#else
  fp = fopen("framestamp.txt", "w");
#endif
  if (fp) {
    for (int i = 0; i < dump_video_datas.size(); i++) {
      fprintf(fp, "%lf,%lf,\n", dump_video_datas[i].st, dump_video_datas[i].rt);
    }
    fclose(fp);
  }
  if (dump_video_frames) {
    fclose(dump_video_frames);
    dump_video_frames = NULL;
  }
#endif
#ifdef DUMP_DST_DATA
#ifdef __ANDROID__
  fp = fopen("/data/misc/media/pose.txt", "w");
#else
  fp = fopen("pose.txt", "w");
#endif
  if (fp) {
    for (int i = 0; i < dump_pose_datas.size(); i++) {
      fprintf(fp, "%d,%f,%f,%f,%f,%f,%f,%f,%f,\n", i, dump_pose_datas[i].p.x, dump_pose_datas[i].p.y, dump_pose_datas[i].p.z, dump_pose_datas[i].p.w,dump_pose_datas[i].q.x, dump_pose_datas[i].q.y, dump_pose_datas[i].q.z, dump_pose_datas[i].q.w);
    }
    fclose(fp);
  }
#endif
  return 0;
}

int CSX::process(CPX *cpx, double st, double rt, unsigned char *src_yuv, unsigned char *dst_yuv) {
#ifdef DUMP_SRC_DATA
  dump_video_data dvd;
  dvd.st = st;
  dvd.rt = rt;
  dump_video_datas.push_back(dvd);
  if (dump_video_frames) {
    fwrite(src_yuv, 1, src_width * src_height, dump_video_frames);
  }
  return 0;
#endif
  cl_int status = CL_SUCCESS;
#ifdef ENABLE_IMPORT_MEMORY_ARM
  // prepare input cl buffers
  cl_image_format src_y_fmt;
  src_y_fmt.image_channel_data_type = CL_UNORM_INT8;
  src_y_fmt.image_channel_order = CL_R;
  cl_image_desc src_y_desc;
  memset(&src_y_desc, 0, sizeof(src_y_desc));
  src_y_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
  src_y_desc.image_width = src_width;
  src_y_desc.image_height = src_height;
  src_y_desc.image_row_pitch = src_y_desc.image_width;
  src_y_desc.buffer = clImportMemoryARM(context, CL_MEM_READ_ONLY, NULL, src_yuv, src_y_desc.image_width * src_y_desc.image_height, &status);
  CHECKSTATUS(status);
  cl_mem src_y_dev_ptr = clCreateImage(context, 0, &src_y_fmt, &src_y_desc, NULL, &status);
  CHECKSTATUS(status);
  cl_image_format src_uv_fmt;
  src_uv_fmt.image_channel_data_type = CL_UNORM_INT8;
  src_uv_fmt.image_channel_order = CL_RG;
  cl_image_desc src_uv_desc;
  memset(&src_uv_desc, 0, sizeof(src_uv_desc));
  src_uv_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
  src_uv_desc.image_width = (src_width + 1) >> 1;
  src_uv_desc.image_height = (src_height + 1) >> 1;
  src_y_desc.image_row_pitch = src_uv_desc.image_width << 1;
  src_uv_desc.buffer = clImportMemoryARM(context, CL_MEM_READ_ONLY, NULL, src_yuv + src_y_desc.image_width * src_y_desc.image_height, src_uv_desc.image_width * src_uv_desc.image_height << 1, &status);
  CHECKSTATUS(status);
  cl_mem src_uv_dev_ptr = clCreateImage(context, 0, &src_uv_fmt, &src_uv_desc, NULL, &status);
  CHECKSTATUS(status);
  // prepare output cl buffers
  cl_image_format dst_y_fmt;
  dst_y_fmt.image_channel_data_type = CL_UNORM_INT8;
  dst_y_fmt.image_channel_order = CL_R;
  cl_image_desc dst_y_desc;
  memset(&dst_y_desc, 0, sizeof(dst_y_desc));
  dst_y_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
  dst_y_desc.image_width = dst_width;
  dst_y_desc.image_height = dst_height;
  dst_y_desc.image_row_pitch = dst_y_desc.image_width;
  dst_y_desc.buffer = clImportMemoryARM(context, CL_MEM_WRITE_ONLY, NULL, dst_yuv, dst_y_desc.image_width * dst_y_desc.image_height, &status);
  CHECKSTATUS(status);
  cl_mem dst_y_dev_ptr = clCreateImage(context, 0, &dst_y_fmt, &dst_y_desc, NULL, &status);
  CHECKSTATUS(status);
  cl_image_format dst_uv_fmt;
  dst_uv_fmt.image_channel_data_type = CL_UNORM_INT8;
  dst_uv_fmt.image_channel_order = CL_RG;
  cl_image_desc dst_uv_desc;
  memset(&dst_uv_desc, 0, sizeof(dst_uv_desc));
  dst_uv_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
  dst_uv_desc.image_width = (dst_width + 1) >> 1;
  dst_uv_desc.image_height = (dst_height + 1) >> 1;
  dst_uv_desc.image_row_pitch = dst_uv_desc.image_width << 1;
  dst_uv_desc.buffer = clImportMemoryARM(context, CL_MEM_WRITE_ONLY, NULL, dst_yuv + dst_y_desc.image_width * dst_y_desc.image_height, dst_uv_desc.image_width * dst_uv_desc.image_height << 1, &status);
  CHECKSTATUS(status);
  cl_mem dst_uv_dev_ptr = clCreateImage(context, 0, &dst_uv_fmt, &dst_uv_desc, NULL, &status);
  CHECKSTATUS(status);
#else
  size_t origin[3] = {0, 0, 0};
  size_t region_src_y[3] = {src_width, src_height, 1};
  size_t region_src_uv[3] = {(src_width + 1) >> 1, (src_height + 1) >> 1, 1};
  size_t region_dst_y[3] = {dst_width, dst_height, 1};
  size_t region_dst_uv[3] = {(dst_width + 1) >> 1, (dst_height + 1) >> 1, 1};
  CHECKSTATUS(clEnqueueWriteImage(cmd_queue, src_y_dev_ptr, CL_FALSE, origin, region_src_y, 0, 0, src_yuv, 0, NULL, NULL));
  CHECKSTATUS(clEnqueueWriteImage(cmd_queue, src_uv_dev_ptr, CL_FALSE, origin, region_src_uv, 0, 0, src_yuv + region_src_y[0] * region_src_y[1], 0, NULL, NULL));
#endif
  clFlush(cmd_queue);

  // map
  float *mesh_grid_homographies_host_ptr = (float *)clEnqueueMapBuffer(cmd_queue, mesh_grid_homographies_dev_ptr, CL_TRUE, CL_MEM_WRITE_ONLY, 0, mesh_grid_rows * sizeof(float) * 12, 0, NULL, NULL, &status);
  CHECKSTATUS(status);

  // find the gyroreading index group around the given time st
  vec4 p = cpx->search(st, &last_pose_idx); // physical camera quaternion

  // calculate delta rotation quaternion for all mesh grid rows to remove rolling shutter effect
  // deltas_host_ptr[y]: delta rotation quaternion obtained from video_frame_start(st) to video_frame_scanline_readout(st + mesh_grid_row * (rt - st) / mesh_grid_rows)
  for (int mesh_grid_row = 0; mesh_grid_row < mesh_grid_rows; mesh_grid_row++) {
    vec4 s = cpx->search(st + (double)mesh_grid_row * (rt - st) / mesh_grid_rows, &last_pose_idx);
    // [xp yp]' = K * A * Rp * [X Y Z]'
    // [xs ys]' = K * A * Rs * [X Y Z]'
    // [xp yp]' = K * A * Rp * invRs * invA * invK * [xs ys]'
    // ��Rs = Rp * invRs = quatmultily(dcm2quat(invRs), dcm2quat(Rp)) (post-multiply)
    vec4 invs;
    inverse(&s, &invs);
    multiply(&invs, &p, &mesh_grid_deltas_host_ptr[mesh_grid_row]);
  }

  // calculate smoothed camera path using UKF filter
  vec4 q; // smoothed camera quaternion
  if (last_video_idx == 0) {
    // initialize UKF state variable & its covariance
    ukf_X[0] = p.w; // quaternion w
    ukf_X[1] = p.x; // quaternion x
    ukf_X[2] = p.y; // quaternion y
    ukf_X[3] = p.z; // quaternion z
    ukf_X[4] = 0; // gx
    ukf_X[5] = 0; // gy
    ukf_X[6] = 0; // gz
    for (int j = 0; j < UKF_STATE_SIZE; j++) { // reset state covariance with identity matrix
      for (int i = 0; i < UKF_STATE_SIZE; i++) {
        ukf_P[i + j * UKF_STATE_SIZE] = (i == j ? 1.0f : 0);
      }
    }
  } else {
    double ukf_Z[UKF_MEASURE_SIZE];
    ukf_Z[0] = p.w;
    ukf_Z[1] = p.x;
    ukf_Z[2] = p.y;
    ukf_Z[3] = p.z;
    UKF_step(ukf, ukf_X, ukf_Z, ukf_P, st - last_video_st);
  }
  q.w = ukf_X[0];
  q.x = ukf_X[1];
  q.y = ukf_X[2];
  q.z = ukf_X[3];
  normalize(&q, &q);

  // [xq yq]' = K * A * Rq * [X Y Z]'
  // [xp yp]' = K * A * Rp * [X Y Z]'
  // [xq yq]' = K * A * Rq * invRp * invA * invK * [xp yp]'
  // ��Rq = Rq * invRp = quatmultiply(dcm2quat(invRp), dcm2quat(Rq)) (post-multiply)
  vec4 invp;
  inverse(&p, &invp);
  vec4 qinvp;
  multiply(&invp, &q, &qinvp);

  // find best q sothat black board constraints can be satisified
  // refer to paper "Real-Time 3D Rotation Smoothing forVideo Stabilization" Chao Jia, Zeina Sinno, and Brian L. Evans
  vec4 v = q; // original smoothed camera quaternion
  int left = 0, right = BLACK_BORDER_CONSTRAINT_SEARCH_SIZE, middle = BLACK_BORDER_CONSTRAINT_SEARCH_SIZE, found = -1; // binary search
  int constraint_x = (src_width - constraint_width) >> 1;
  int constraint_y = (src_height - constraint_height) >> 1;
  vec4 slice_lpts[BLACK_BORDER_CONSTRAINT_SLICE_SIZE + 1], slice_olpt, slice_nlpt; // old/new coordinates of left/right border points(knee-points) of each slice
  vec4 slice_rpts[BLACK_BORDER_CONSTRAINT_SLICE_SIZE + 1], slice_orpt, slice_nrpt;
  vec4 slice_deltas[BLACK_BORDER_CONSTRAINT_SLICE_SIZE + 1];
  //  initialize the knee-points of each slice
  for (int slice = 0; slice < BLACK_BORDER_CONSTRAINT_SLICE_SIZE; slice++) {
    double y = constraint_y + slice * (double)constraint_height / BLACK_BORDER_CONSTRAINT_SLICE_SIZE;
    // left border point(knee-point)
    slice_lpts[slice].x = constraint_x;
    slice_lpts[slice].y = y;
    slice_lpts[slice].z = 1.0;
    slice_lpts[slice].w = 0.0;
    // right border point(knee-point)
    slice_rpts[slice].x = constraint_x + constraint_width - 1;
    slice_rpts[slice].y = y;
    slice_rpts[slice].z = 1.0;
    slice_rpts[slice].w = 0.0;
    // delta rotation
    slice_deltas[slice] = mesh_grid_deltas_host_ptr[(int)(y / mesh_grid_scanlines)];
  }
  // the last two border points(knee-points)
  slice_lpts[BLACK_BORDER_CONSTRAINT_SLICE_SIZE].x = constraint_x;
  slice_lpts[BLACK_BORDER_CONSTRAINT_SLICE_SIZE].y = constraint_y + constraint_height - 1;
  slice_lpts[BLACK_BORDER_CONSTRAINT_SLICE_SIZE].z = 1.0;
  slice_lpts[BLACK_BORDER_CONSTRAINT_SLICE_SIZE].w = 0.0;
  slice_rpts[BLACK_BORDER_CONSTRAINT_SLICE_SIZE].x = constraint_x + constraint_width - 1;
  slice_rpts[BLACK_BORDER_CONSTRAINT_SLICE_SIZE].y = constraint_y + constraint_height - 1;
  slice_rpts[BLACK_BORDER_CONSTRAINT_SLICE_SIZE].z = 1.0;
  slice_rpts[BLACK_BORDER_CONSTRAINT_SLICE_SIZE].w = 0.0;
  slice_deltas[BLACK_BORDER_CONSTRAINT_SLICE_SIZE] = mesh_grid_deltas_host_ptr[(int)((double)(constraint_y + constraint_height - 1) / mesh_grid_scanlines)];
  do {
    // try to generate an new q and update invpq
    float beta = middle / (float)BLACK_BORDER_CONSTRAINT_SEARCH_SIZE;
    slerp(&p, &v, beta, &q);
    multiply(&invp, &q, &qinvp);
    // check the slice knee points
    bool out_of_constraint_region = false;
    for (int slice = 0; slice <= BLACK_BORDER_CONSTRAINT_SLICE_SIZE; slice++) {
      vec4 qinvpdelta;
      multiply(&slice_deltas[slice], &qinvp, &qinvpdelta);
      vec4 invqinvpdelta;
      inverse(&qinvpdelta, &invqinvpdelta);
      mat3 r;
      q2mat(&invqinvpdelta, &r);
      mat3 h;
      multiply(&KA, &r, &h);
      mat3 homography;
      multiply(&h, &invAinvK, &homography);
      slice_olpt = slice_lpts[slice];
      slice_nlpt.z = dot(&homography.s2, &slice_olpt);
      slice_nlpt.x = dot(&homography.s0, &slice_olpt) / slice_nlpt.z;
      slice_nlpt.y = dot(&homography.s1, &slice_olpt) / slice_nlpt.z;
      slice_orpt = slice_rpts[slice];
      slice_nrpt.z = dot(&homography.s2, &slice_orpt);
      slice_nrpt.x = dot(&homography.s0, &slice_orpt) / slice_nrpt.z;
      slice_nrpt.y = dot(&homography.s1, &slice_orpt) / slice_nrpt.z;
      if (slice_nlpt.x < 0 || slice_nlpt.x > src_width - 1 ||
          slice_nlpt.y < 0 || slice_nlpt.y > src_height - 1 ||
          slice_nrpt.x < 0 || slice_nrpt.x > src_width - 1 ||
          slice_nrpt.y < 0 || slice_nrpt.y > src_height - 1) {
        out_of_constraint_region = true;
        break;
      }
    }
    // OK, now check all of knee-points of each slice are out of constraint region ?
    if (!out_of_constraint_region) {
      if (found == middle) { // aready found, just look back over it, now we can exit the loop at this time.
        break;
      }
      found = middle;
      left = middle + 1;
    } else {
      right = middle - 1;
    }
    if (left > right) {
      if (found < 0 || middle == found) {
        break;
      }
      middle = found; // ok, look back over it, sothat the last updated invpq and q satisfied black-board constraint
    } else {
       middle = (left + right) / 2;
    }
  } while (1);
  ukf_X[0] = q.w;
  ukf_X[1] = q.x;
  ukf_X[2] = q.y;
  ukf_X[3] = q.z;

  // figure out homography matrixes of the other scanlines(except the first and last scanline)
  for (int mesh_grid_row = 0; mesh_grid_row < mesh_grid_rows; mesh_grid_row++) {
    // [xq yq]' = K * A * Rq * invRp * invA * invK * K * A * Rp * invRs * invA * invK * [xs ys]'
    // [xq yq]' = K * A * Rq * invRp * Rp * invRs * invA * invK * [xs ys]'
    // [xq yq]' = K * A * ��Rq * ��Rs * invA * invK * [xs ys]'
    // ��R = ��Rq * ��Rs = quatmultiply(dcm2quat(��Rs), dcm2quat(��Rq)) (post-multiply)
    vec4 qinvpdelta;
    multiply(&mesh_grid_deltas_host_ptr[mesh_grid_row], &qinvp, &qinvpdelta);
    vec4 invqinvpdelta;
    inverse(&qinvpdelta, &invqinvpdelta); // inverse the homography matrix, because we will use inverse warping to correct the current frame
    mat3 r;
    q2mat(&invqinvpdelta, &r);
    mat3 h;
    multiply(&KA, &r, &h);
    multiply(&h, &invAinvK, &mesh_grid_homographies_host_ptr[mesh_grid_row * 12]);
  }

  // unmap before executing kernel
  CHECKSTATUS(clEnqueueUnmapMemObject(cmd_queue, mesh_grid_homographies_dev_ptr, mesh_grid_homographies_host_ptr, 0, NULL, NULL));

  // perspective pransformation
  int crop_x = (src_width - crop_width) >> 1;
  int crop_y = (src_height - crop_height) >> 1;
  int dst_offset_x = (dst_width - crop_width) >> 1;
  int dst_offset_y = (dst_height - crop_height) >> 1;
  size_t globalThreads[3];
  globalThreads[0] = (crop_width + 1) >> 1;
  globalThreads[1] = (crop_height + 1) >> 1;
  globalThreads[2] = 1;
  CHECKSTATUS(clSetKernelArg(kernel, 0, sizeof(cl_int), (void *)&crop_x));
  CHECKSTATUS(clSetKernelArg(kernel, 1, sizeof(cl_int), (void *)&crop_y));
  CHECKSTATUS(clSetKernelArg(kernel, 2, sizeof(cl_int), (void *)&dst_offset_x));
  CHECKSTATUS(clSetKernelArg(kernel, 3, sizeof(cl_int), (void *)&dst_offset_y));
  CHECKSTATUS(clSetKernelArg(kernel, 4, sizeof(cl_float), (void *)&mesh_grid_scanlines));
  CHECKSTATUS(clSetKernelArg(kernel, 5, sizeof(cl_mem), (void *)&mesh_grid_homographies_dev_ptr));
  CHECKSTATUS(clSetKernelArg(kernel, 6, sizeof(cl_mem), (void *)&src_y_dev_ptr));
  CHECKSTATUS(clSetKernelArg(kernel, 7, sizeof(cl_mem), (void *)&src_uv_dev_ptr));
  CHECKSTATUS(clSetKernelArg(kernel, 8, sizeof(cl_mem), (void *)&dst_y_dev_ptr));
  CHECKSTATUS(clSetKernelArg(kernel, 9, sizeof(cl_mem), (void *)&dst_uv_dev_ptr));
  RUN("inverse_warping", cmd_queue, kernel, 3, NULL, globalThreads, NULL, 0, NULL, NULL);

  // output stabilized video frame
#ifdef ENABLE_IMPORT_MEMORY_ARM
  clFinish(cmd_queue);
  CHECKSTATUS(::clReleaseMemObject(src_y_dev_ptr));
  CHECKSTATUS(::clReleaseMemObject(src_uv_dev_ptr));
  CHECKSTATUS(::clReleaseMemObject(dst_y_dev_ptr));
  CHECKSTATUS(::clReleaseMemObject(dst_uv_dev_ptr));
  CHECKSTATUS(::clReleaseMemObject(src_y_desc.buffer));
  CHECKSTATUS(::clReleaseMemObject(src_uv_desc.buffer));
  CHECKSTATUS(::clReleaseMemObject(dst_y_desc.buffer));
  CHECKSTATUS(::clReleaseMemObject(dst_uv_desc.buffer));
#else
  clEnqueueReadImage(cmd_queue, dst_y_dev_ptr, CL_FALSE, origin, region_dst_y, 0, 0, dst_yuv, 0, NULL, NULL);
  clEnqueueReadImage(cmd_queue, dst_uv_dev_ptr, CL_TRUE, origin, region_dst_uv, 0, 0, dst_yuv + region_dst_y[0] * region_dst_y[1], 0, NULL, NULL);
#endif

  last_video_st = st;
  last_video_idx++;

#ifdef DUMP_DST_DATA
  dump_pose_data dpd;
  dpd.p = p;
  dpd.q = q;
  dump_pose_datas.push_back(dpd);
#endif
  return 0;
}

void *video_stab_lc_pose_init() {
  CPX *cpx = new CPX();
  return cpx;
}

int video_stab_lc_pose_release(void *cpx) {
  if (cpx == NULL) {
    ERROR("video_stab_lc_pose_release: invalid parameters.\n");
    return -1;
  }
  delete((CPX *)cpx);
  return 0;
}

int video_stab_lc_pose_set_params(void *cpx,
    bool auto_updating
) {
  if (cpx == NULL) {
    ERROR("video_stab_lc_pose_set_params: invalid parameters.\n");
    return -1;
  }
  ((CPX *)cpx)->auto_updating = auto_updating;
  return 0;
}

int video_stab_lc_pose_get_params(void *cpx
   , bool *auto_updating
) {
  if (cpx == NULL) {
    ERROR("video_stab_lc_pose_get_params: invalid parameters.\n");
    return -1;
  }
  *auto_updating = ((CPX *)cpx)->auto_updating;
  return 0;
}

int video_stab_lc_pose_start(void *cpx) {
  if (cpx == NULL) {
    ERROR("video_stab_lc_pose_start: invalid parameters.\n");
    return -1;
  }
  return ((CPX *)cpx)->start();
}

int video_stab_lc_pose_stop(void *cpx) {
  if (cpx == NULL) {
    ERROR("video_stab_lc_pose_stop: invalid parameters.\n");
    return -1;
  }
  return ((CPX *)cpx)->stop();
}

int video_stab_lc_pose_process(void *cpx,
    double et,  // unit: seconds
    float gx,  // gyro x value
    float gy,  // gyro y value
    float gz   // gyro z value
) {
  if (cpx == NULL) {
    ERROR("video_stab_lc_pose_process: invalid parameters.\n");
    return -1;
  }
  return ((CPX *)cpx)->process(et, gx, gy, gz);
}

void *video_stab_lc_stab_init() {
  CSX *csx = new CSX();
  return csx;
}

int video_stab_lc_stab_release(void *csx) {
  if (csx == NULL) {
    ERROR("video_stab_lc_stab_release: invalid parameters.\n");
    return -1;
  }
  delete((CSX *)csx);
  return 0;
}

int video_stab_lc_stab_set_params(void *csx,
    int src_width,
    int src_height,
    int dst_width,
    int dst_height,
    int crop_width,
    int crop_height,
    int constraint_width,
    int constraint_height,
    double camera_horizontal_view_angle,
    double camera_vertical_view_angle,
    double cam2gyro_rotation_x,
    double cam2gyro_rotation_y,
    double cam2gyro_rotation_z,
    int pixel_format,
    double ukf_process_noise,
    double ukf_measure_noise,
    double ukf_kappa,
    double ukf_alpha,
    double ukf_beta,
    int mesh_grid_rows) {
  if (csx == NULL || src_width <= 0 || src_height <= 0 || dst_width <= 0 || dst_height <= 0 || crop_width <= 0 || crop_height <= 0 || crop_width > src_width ||
      crop_height > src_height || crop_width > dst_width || crop_height > dst_height || constraint_width <= 0 || constraint_height <= 0 || constraint_width > src_width ||
      constraint_height > src_height || camera_horizontal_view_angle <= 0.0 || camera_vertical_view_angle <= 0.0 || ukf_process_noise <= 0 ||  ukf_measure_noise <= 0 ||
      ukf_kappa < 0 || ukf_alpha < 0 || ukf_beta < 0 || mesh_grid_rows < 0 || mesh_grid_rows > src_height || (pixel_format != VIDEO_STAB_PIXEL_FORMAT_YUV420_NV12 &&
      pixel_format != VIDEO_STAB_PIXEL_FORMAT_YUV420_NV21)) {
    ERROR("video_stab_lc_stab_set_params: invalid parameters.\n");
    return -1;
  }

  if (pixel_format != ((CSX *)csx)->pixel_format) {
    ((CSX *)csx)->releaseKernels();
    ((CSX *)csx)->createKernels(pixel_format);
  }

  if (src_width != ((CSX *)csx)->src_width || src_height != ((CSX *)csx)->src_height ||
      dst_width != ((CSX *)csx)->dst_width || dst_height != ((CSX *)csx)->dst_height ||
      mesh_grid_rows != ((CSX *)csx)->mesh_grid_rows) {
    ((CSX *)csx)->releaseBuffers();
    ((CSX *)csx)->createBuffers(src_width, src_height, dst_width, dst_height, mesh_grid_rows);
  }

 if (ukf_process_noise != ((CSX *)csx)->ukf_process_noise || ukf_measure_noise != ((CSX *)csx)->ukf_measure_noise ||
     ukf_kappa != ((CSX *)csx)->ukf_kappa || ukf_alpha != ((CSX *)csx)->ukf_alpha || ukf_beta != ((CSX *)csx)->ukf_beta) {
    ((CSX *)csx)->releaseUKFfilter();
    ((CSX *)csx)->createUKFfilter(ukf_process_noise, ukf_measure_noise, ukf_kappa, ukf_alpha, ukf_beta);
  }

  double fx = 0.5 * src_width / tan(0.5 * camera_horizontal_view_angle * 3.141592653589793 / 180.0);
  double fy = 0.5 * src_height / tan(0.5 * camera_vertical_view_angle * 3.141592653589793 / 180.0);
  double u0 = 0.5 * (src_width - 1);
  double v0 = 0.5 * (src_height - 1);

  // camera intrinsic matrix
  mat3 K;
  K.s0.x = fx;
  K.s0.y = 0;
  K.s0.z = u0;
  K.s0.w = 0;
  K.s1.x = 0;
  K.s1.y = fy;
  K.s1.z = v0;
  K.s1.w = 0;
  K.s2.x = 0;
  K.s2.y = 0;
  K.s2.z = 1;
  K.s2.w = 0;
  //display(&K);

  mat3 invK;
  invK.s0.x = 1 / fx;
  invK.s0.y = 0;
  invK.s0.z = -u0 / fx;
  invK.s0.w = 0;
  invK.s1.x = 0;
  invK.s1.y = 1 / fy;
  invK.s1.z = -v0 / fy;
  invK.s1.w = 0;
  invK.s2.x = 0;
  invK.s2.y = 0;
  invK.s2.z = 1;
  invK.s2.w = 0;
  //display(&invK);

  mat3 A;
  eye(&A);
  double alpha = sqrt(cam2gyro_rotation_x * cam2gyro_rotation_x + cam2gyro_rotation_y * cam2gyro_rotation_y + cam2gyro_rotation_z * cam2gyro_rotation_z);
  if (alpha > DBL_EPSILON) {
    double nx = cam2gyro_rotation_x / alpha;
    double ny = cam2gyro_rotation_y / alpha;
    double nz = cam2gyro_rotation_z / alpha;
    A.s0.x = cos(alpha) + nx * nx * (1 - cos(alpha));
    A.s0.y = -nz * sin(alpha) + nx * ny * (1 - cos(alpha));
    A.s0.z = ny * sin(alpha) + nx * nz * (1 - cos(alpha));
    A.s0.w = 0;
    A.s1.x = nz * sin(alpha) + nx * ny * (1 - cos(alpha));
    A.s1.y = cos(alpha) + ny * ny * (1 - cos(alpha));
    A.s1.z = -nx * sin(alpha) + ny * nz * (1 - cos(alpha));
    A.s1.w = 0;
    A.s2.x = -ny * sin(alpha) + nx * nz * (1 - cos(alpha));
    A.s2.y = nx * sin(alpha) + ny * nz * (1 - cos(alpha));
    A.s2.z = cos(alpha) + nz * nz * (1 - cos(alpha));
    A.s2.w = 0;
  }
  //display(&A);

  mat3 invA;
  invA.s0.x = A.s0.x;
  invA.s0.y = A.s1.x;
  invA.s0.z = A.s2.x;
  invA.s0.w = 0;
  invA.s1.x = A.s0.y;
  invA.s1.y = A.s1.y;
  invA.s1.z = A.s2.y;
  invA.s1.w = 0;
  invA.s2.x = A.s0.z;
  invA.s2.y = A.s1.z;
  invA.s2.z = A.s2.z;
  invA.s2.w = 0;
  //display(&invA);

  ((CSX *)csx)->crop_width = crop_width;
  ((CSX *)csx)->crop_height = crop_height;
  ((CSX *)csx)->constraint_width = constraint_width;
  ((CSX *)csx)->constraint_height = constraint_height;
  ((CSX *)csx)->camera_horizontal_view_angle = camera_horizontal_view_angle;
  ((CSX *)csx)->camera_vertical_view_angle = camera_vertical_view_angle;
  ((CSX *)csx)->cam2gyro_rotation_x = cam2gyro_rotation_x;
  ((CSX *)csx)->cam2gyro_rotation_y = cam2gyro_rotation_y;
  ((CSX *)csx)->cam2gyro_rotation_z = cam2gyro_rotation_z;

  multiply(&K, &A, &((CSX *)csx)->KA);
  //display(&((CSX *)csx)->KA);
  multiply(&invA, &invK, &((CSX *)csx)->invAinvK);
  //display(&((CSX *)csx)->invAinvK);

  return 0;
}

int video_stab_lc_stab_get_params(void *csx,
    int *src_width,
    int *src_height,
    int *dst_width,
    int *dst_height,
    int *crop_width,
    int *crop_height,
    int *constraint_width,
    int *constraint_height,
    double *camera_horizontal_view_angle,
    double *camera_vertical_view_angle,
    double *cam2gyro_rotation_x,
    double *cam2gyro_rotation_y,
    double *cam2gyro_rotation_z,
    int *pixel_format,
    double *ukf_process_noise,
    double *ukf_measure_noise,
    double *ukf_kappa,
    double *ukf_alpha,
    double *ukf_beta,
    int *mesh_grid_rows
    ) {
  if (csx == NULL || src_width == NULL || src_height == NULL || dst_width == NULL || dst_height == NULL || crop_width == NULL || crop_height == NULL ||
      constraint_width == NULL || constraint_height == NULL || camera_horizontal_view_angle == NULL || camera_vertical_view_angle == NULL ||
      cam2gyro_rotation_x == NULL || cam2gyro_rotation_y == NULL || cam2gyro_rotation_z == NULL || pixel_format == NULL || ukf_process_noise == NULL ||
      ukf_measure_noise == NULL || ukf_kappa == NULL || ukf_alpha == NULL || ukf_beta == NULL || mesh_grid_rows == NULL) {
    ERROR("video_stab_lc_stab_get_params: invalid parameters.\n");
    return -1;
  }
  *src_width = ((CSX *)csx)->src_width;
  *src_height = ((CSX *)csx)->src_height;
  *dst_width = ((CSX *)csx)->dst_width;
  *dst_height = ((CSX *)csx)->dst_height;
  *crop_width = ((CSX *)csx)->crop_width;
  *crop_height = ((CSX *)csx)->crop_height;
  *constraint_width = ((CSX *)csx)->constraint_width;
  *constraint_height = ((CSX *)csx)->constraint_height;
  *camera_horizontal_view_angle = ((CSX *)csx)->camera_horizontal_view_angle;
  *camera_vertical_view_angle = ((CSX *)csx)->camera_vertical_view_angle;
  *cam2gyro_rotation_x = ((CSX *)csx)->cam2gyro_rotation_x;
  *cam2gyro_rotation_y = ((CSX *)csx)->cam2gyro_rotation_y;
  *cam2gyro_rotation_z = ((CSX *)csx)->cam2gyro_rotation_z;
  *pixel_format = ((CSX *)csx)->pixel_format;
  *ukf_process_noise = ((CSX *)csx)->ukf_process_noise;
  *ukf_measure_noise = ((CSX *)csx)->ukf_measure_noise;
  *ukf_kappa = ((CSX *)csx)->ukf_kappa;
  *ukf_alpha = ((CSX *)csx)->ukf_alpha;
  *ukf_beta = ((CSX *)csx)->ukf_beta;
  *mesh_grid_rows = ((CSX *)csx)->mesh_grid_rows;
  return 0;
}

int video_stab_lc_stab_start(void *csx) {
  if (csx == NULL) {
    ERROR("video_stab_lc_stab_start: invalid parameters.\n");
    return -1;
  }
  return ((CSX *)csx)->start();
}

int video_stab_lc_stab_stop(void *csx) {
  if (csx == NULL) {
    ERROR("video_stab_lc_stab_stop: invalid parameters.\n");
    return -1;
  }
  return ((CSX *)csx)->stop();
}

int video_stab_lc_stab_process(void *csx, void *cpx, double st, double rt, unsigned char *src_yuv, unsigned char *dst_yuv) {
  if (csx == NULL || cpx == NULL || src_yuv == NULL || dst_yuv == NULL) {
    ERROR("video_stab_lc_stab_process: invalid parameters.\n");
    return -1;
  }
  return ((CSX *)csx)->process((CPX *)cpx, st, rt, src_yuv, dst_yuv);
}

const char *video_stab_lc_version_code_get() {
  return "1.0";
}