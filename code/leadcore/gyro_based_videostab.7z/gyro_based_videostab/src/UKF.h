#ifndef __UKF__
#define __UKF__
typedef void (*UKF_f_func)(double* s_k, double dt, double* s_k_1);
typedef void (*UKF_h_func)(double* s_k, double* z_k);

typedef struct UKF {
  UKF_f_func f_func;
  UKF_h_func h_func;
  int state_size;
  int measure_size;
  double process_noise;
  double measure_noise;
  double lambda;
  double mean_weight;
  double covariance_weight;
  double both_weight;
  double *state; // state vector
  double *measure; // measurement vector
  double *state_covariance; // state matrix
  double *measure_covariance; // measurement matrix
  double *cross_covariance; // cross matrix
  double *kalman_gain;
  double *sigma_points; // sigma points matrix
  double *f_sigma_points;
  double *h_sigma_points;
  // temperary vector & matrix
  double *A; // state_size x state_size
  double *B; // state_size x 1
  double *C; // measure_size x 1
  double *D; // measure_size x measure_size
  double *E; // measure_size x state_size
} UKF;

UKF *UKF_init(UKF_f_func f_func, UKF_h_func h_func, int state_size, int measure_size, double process_noise, double measure_noise, double kappa = 0.0, double alpha = 1e-3, double beta = 2.0);
void UKF_release(UKF *ctx);
int UKF_step(UKF *ctx, double* state, double* measure, double *covariance, double dt);
#endif