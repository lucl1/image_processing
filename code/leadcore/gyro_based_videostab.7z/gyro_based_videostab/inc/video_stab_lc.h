#ifndef __VIDEO_STAB_H__
#define __VIDEO_STAB_H__
#define VIDEO_STAB_PIXEL_FORMAT_YUV420_NV12 0
#define VIDEO_STAB_PIXEL_FORMAT_YUV420_NV21 1
extern "C" {
  /* pose estimator interfaces */
  void *video_stab_lc_pose_init();
  int video_stab_lc_pose_release(void *cpx);
  int video_stab_lc_pose_set_params(void *cpx,
    bool auto_updating = true // only android support updating camera pose automatically
    );
  int video_stab_lc_pose_get_params(void *cpx,
    bool *auto_updating // only android support it, otherwise ignore it
    );
  int video_stab_lc_pose_start(void *cpx); // call it before the first video frame is processed
  int video_stab_lc_pose_stop(void *cpx); // stop it after all video frames are processed
  // update camera pose by using gyroscope sensor data manually,
  // but don't call it if on Android and auto_updating = true.
  int video_stab_lc_pose_process(void *cpx,
    double event_timestamp,  // unit: seconds
    float gx,  // gyro x value
    float gy,  // gyro y value
    float gz   // gyro z value
    );
  /* video stabilizer interfaces */
  void *video_stab_lc_stab_init();
  int video_stab_lc_stab_release(void *csx);
  int video_stab_lc_stab_set_params(void *csx,
    int src_width,
    int src_height,
    int dst_width,
    int dst_height,
    int crop_width,
    int crop_height,
    int constraint_width,
    int constraint_height,
    double camera_horizontal_view_angle,
    double camera_vertical_view_angle,
    double cam2gyro_rotation_x,
    double cam2gyro_rotation_y,
    double cam2gyro_rotation_z,
    int pixel_format = VIDEO_STAB_PIXEL_FORMAT_YUV420_NV12,
    double ukf_process_noise = 3e-10, // covariance of process. "smoothness": lower the value, smoother the curve
    double ukf_measure_noise = 0.002, // covariance of measurement. "tracking": lower the value, faster the track
    double ukf_kappa = 0.0, // tunable, but don't change it if you don't know what it mean in Unscented Kalman Filter
    double ukf_alpha = 1e-3,  // tunable, but don't change it if you don't know what it mean in Unscented Kalman Filter
    double ukf_beta = 2.0,  // tunable, but don't change it if you don't know what it mean in Unscented Kalman Filter
    int mesh_grid_rows = 40 // we use the mesh grid during inverse warping, so you should tell me how many rows in the mesh grid ?
    );
  int video_stab_lc_stab_get_params(void *csx,
    int *src_width,
    int *src_height,
    int *dst_width,
    int *dst_height,
    int *crop_width,
    int *crop_height,
    int *constraint_width,
    int *constraint_height,
    double *camera_horizontal_view_angle,
    double *camera_vertical_view_angle,
    double *cam2gyro_rotation_x,
    double *cam2gyro_rotation_y,
    double *cam2gyro_rotation_z,
    int *pixel_format,
    double *ukf_process_noise,
    double *ukf_measure_noise,
    double *ukf_kappa,
    double *ukf_alpha,
    double *ukf_beta,
    int *mesh_grid_rows
    );
  int video_stab_lc_stab_start(void *csx); // call it after video_stab_lc_pose_start
  int video_stab_lc_stab_stop(void *csx); // call it before video_stab_lc_pose_stop
  // stabilize video frame
  int video_stab_lc_stab_process(void *csx,
    void *cpx,
    double start_timestamp,    // unit: seconds
    double readout_timestamp,  // unit: seconds
    unsigned char *src_yuv,
    unsigned char *dst_yuv
    );
  const char *video_stab_lc_version_code_get();
}
#endif
/* example
  // step1. create context for pose estimator and set parameters
  void *cpx = video_stab_lc_pose_init();
  assert(cpx);
  video_stab_lc_pose_set_params(ctx, true); // only on android platform, we can set auto_updating = true to poll gyroscope
                                            // data to estimate pose automatically, otherwise it will be ignored.
  void *preview_csx = video_stab_lc_stab_init(); // create video stabilizer context for camera preview stream
  assert(preview_csx);
  video_stab_lc_stab_set_params(preview_csx,
    preview_src_width,
    preview_src_height,
    preview_dst_width,
    preview_dst_height,
    preview_crop_width,
    preview_crop_height,
    preview_constraint_width,
    preview_constraint_height,
    camera_horizontal_view_angle,
    camera_vertical_view_angle,
    cam2gyro_rotation_x,
    cam2gyro_rotation_y,
    cam2gyro_rotation_z,
    VIDEO_STAB_PIXEL_FORMAT_YUV420_NV12
    );
  );
  void *record_csx = video_stab_lc_stab_init(); // create video stabilizer context for video recording stream
  assert(record_csx);
  video_stab_lc_stab_set_params(record_csx,
    record_src_width,
    record_src_height,
    record_dst_width,
    record_dst_height,
    record_crop_width,
    record_crop_height,
    record_constraint_width,
    record_constraint_height,
    camera_horizontal_view_angle,
    camera_vertical_view_angle,
    cam2gyro_rotation_x,
    cam2gyro_rotation_y,
    cam2gyro_rotation_z,
    VIDEO_STAB_PIXEL_FORMAT_YUV420_NV12
    );
  );
  ....
  // step2. stabilize video frames
  video_stab_lc_pose_start(cpx); // called before video_stab_lc_stab_start()
  preview thread {
    video_stab_lc_stab_start(preview_csx);
    foreach frame of preview stream {
      video_stab_lc_stab_process(preview_csx,
        cpx,
        frame_start_timestamp,
        frame_readout_timestamp,
        src_yuv_data_ptr,
        dst_yuv_data_ptr
        );
    }
    video_stab_lc_stab_stop(preview_csx);
  }
  video recording thread {
    video_stab_lc_stab_start(record_csx);
    foreach frame of video recording stream {
      video_stab_lc_stab_process(record_csx,
        cpx, // share one pose estimator with preview stream
        frame_start_timestamp,
        frame_readout_timestamp,
        src_yuv_data_ptr,
        dst_yuv_data_ptr
        );
    }
    video_stab_lc_stab_stop(record_csx);
  }
  video_stab_lc_pose_stop(cpx); // called after video_stab_lc_stab_stop()
  ....
  // step3. release contexts and resources if never use them
  video_stab_lc_stab_release(preview_csx);
  video_stab_lc_stab_release(record_csx);
  video_stab_lc_pose_release(cpx);
*/