#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>
#include <limits>
#include "depth_detection_lc.h"
#include "utils.h"

#ifdef _WIN32
#include <windows.h>
int set_cpu_affinity(int cpu_idx) {
  DWORD mask = 0;
  if (cpu_idx > 0) {
    mask = 1L << cpu_idx;
  }
  return SetThreadAffinityMask(GetCurrentThread(), mask);
}
int worker_thread_callback(int thread_idx, int thread_num) {
  int cpu_idx = thread_idx % 2; // intel i3 only have two cores
  if(set_cpu_affinity(cpu_idx) != 0) {
    printf("worker thread %d: set cpu affinity(%d) failed\n", thread_idx, cpu_idx);
  } else {
    printf("worker thread %d: set cpu affinity(%d) successed\n", thread_idx, cpu_idx);
  }
  return 0;
}
#else
#include <sched.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
int set_cpu_affinity(int cpu_idx) {
  cpu_set_t set;
  CPU_ZERO(&set);
  CPU_SET(cpu_idx, &set);
  return sched_setaffinity(gettid(), sizeof(cpu_set_t), &set);
}
int worker_thread_callback(int thread_idx, int thread_num) {
  /* set cpu affinity mask to thread */
#ifdef __ANDROID__
  int cpu_idx = thread_idx + 4; // for lc1881: 0~3 are little core, 4~8 are big cores
#else
  int cpu_idx = thread_idx;
#endif
  if(set_cpu_affinity(cpu_idx) != 0) {
    printf("worker thread %d: set cpu affinity(%d) failed(errno=%d)\n", thread_idx, cpu_idx, errno);
  } else {
    printf("worker thread %d: set cpu affinity(%d) successed\n", thread_idx, cpu_idx);
  }
}
#endif

int main(int argc, char* argv[]) {
  if (argc < 13) {
    printf("usage: %s min_disp num_disp subpixel_shiftbits src_left_image_path src_right_image_path disparity_image_path disparity_file_path "
           "reference_file_path opencl_kernel_file_path opencl_kernel_is_source rect_width rect_height rect_data_file_path\n", argv[0]);
    return -1;
  }
  /* initialize depth detection processor */
  void *ctx = depth_detection_lc_init(argv[9], atoi(argv[10]), worker_thread_callback, 4);
  assert(ctx);

  /* load left and right image data & prepare memory for storing disparity data */
  int width, height, w, h;
  unsigned char *src_image_addr[2] = { NULL, NULL };
  if (read_gray_from_bitmap(argv[4], &src_image_addr[0], &width, &height)) {
    printf("read %s failed\n", argv[4]);
    return -1;
  }
  if (read_gray_from_bitmap(argv[5], &src_image_addr[1], &w, &h)) {
    printf("read %s failed\n", argv[5]);
    return -1;
  }
  assert(width == w && height == h);
  /* set parameters to depth detection processor */
  DEPTH_DETECTION_PARAM param;
  memset(&param, 0, sizeof(param));
  param.min_disp = atoi(argv[1]);
  param.num_disp = atoi(argv[2]);
  param.subpixel_shiftbits = atoi(argv[3]);
  //param.block_matching_methold = 1;
  //param.cost_aggreation_win_size = 8;
  param.scanline_optimization_penalty1 = 8;
  param.scanline_optimization_penalty2 = 109;
  param.left_right_consistency_check_tolerance = 0;
  //param.textureless_filter_threshold = 108;
  param.median_filter_win_size = 2;
  param.src_width = width;
  param.src_height = height;
  param.rect_width = atoi(argv[11]);
  param.rect_height = atoi(argv[12]);
  if (param.rect_width > 0 && param.rect_height > 0) {
    width = param.rect_width;
    height = param.rect_height;
    sprintf(param.rect_data_file_path, "%s", argv[13]);
  }
  depth_detection_lc_set_params(ctx, param);
  /* process and obtain their disparity image at each frame */
  unsigned short *disp_addr = new unsigned short[width * height];
  assert(disp_addr);
  const int TEST_TIMES = 10;
  double TEST_COSTS = 0.0;
  for (int i = 0; i < TEST_TIMES; i++) {
    printf("loop %d:\n", i);
    uint64_t now = get_timestamp();
    depth_detection_lc_get_disp(ctx, src_image_addr, disp_addr);
    double duration = get_duration(now) * 1000.0f;
    printf("time-cost of depth detection: %.2f ms\n", duration);
    if (i > 0) {
      TEST_COSTS += duration;
    }
  }
  printf("average time-cost of depth detection: %.2f ms\n", TEST_COSTS / (TEST_TIMES - 1));

  /* destroy the context and release related resources if never use them */
  depth_detection_lc_release(ctx);
  delete src_image_addr[0];
  delete src_image_addr[1];

  /* convert disparity(with subpixel) to gray image, and output it to bmp file */
  unsigned char *disp2gray_addr = new unsigned char[width * height];
  assert(disp2gray_addr);
  for (int i = 0; i < width * height; i++) {
    disp2gray_addr[i] = disp_addr[i] >> param.subpixel_shiftbits;
  }
  if (write_gray_to_bitmap(argv[6], disp2gray_addr, width, height)) {
    printf("write %s failed\n", argv[6]);
    return -1;
  }
  delete disp2gray_addr;

  /* output disparity to data file */
  FILE *fp = fopen(argv[7], "wb");
  if (!fp) {
    printf("write %s failed\n", argv[7]);
    return -1;
  }
  fwrite(disp_addr, sizeof(unsigned short), width * height, fp);
  fclose(fp);

  /* calc matching rate between result and reference */
  fp = fopen(argv[8], "rb");
  if (fp) {
    unsigned short *reference = new unsigned short[width * height];
    assert(reference);
    fread(reference, sizeof(unsigned short), width * height, fp);
    fclose(fp);
    int matched = 0;
    for (int i = 0; i < width * height; i++) {
      if (reference[i] == disp_addr[i]) {
        matched++;
      }
    }
    delete reference;
    printf("reference match rate %.3f%% .\n", (float)matched / (width * height) * 100);
  }
  
  delete disp_addr;

  printf("done\n");

#ifdef _WIN32
  getchar();
#endif
  return 0;
}
