#ifndef __DEPTH_DETECTION_H__
#define __DEPTH_DETECTION_H__
struct DEPTH_DETECTION_PARAM {
  /* disparity computation paramters */
  unsigned short min_disp; // min disparity: its value should be greater than 0, suggested value = 0
  unsigned short num_disp; // num disparity: its value set is [16, 32, 48, 64, 80, 96, 112, 128, 144, 160, 176, 192, 208, 
                           // 224, 240, 256], suggested value = 64
  unsigned short min_valid_disp; // min_valid_disp = min_disp by default
  unsigned short num_valid_disp; // max_valid_disp = max_disp by default
  unsigned char subpixel_shiftbits; // shift bits of subpixel part of depth: its range is [0, 16 - log2(param.min_disp + param.num_disp - 1)]
                                    // which depends min_disp and num_disp, suggested value = 4
  unsigned char block_matching_methold; // 0: 9x9 sparse modified census transform 1: 9x9 sparse census transform
  unsigned char cost_aggreation_win_size;
  unsigned char scanline_optimization_penalty1; // suggested value = 20, don't change it if you don't know what they mean.
  unsigned char scanline_optimization_penalty2; // suggested value = 100, don't change it if you don't know what they mean.
  unsigned char left_right_consistency_check_tolerance; // tolerance of absolute difference of left-right disparity, suggested value = 1
  unsigned char textureless_filter_threshold; // mean deviation of a block depends block_matching_methold
  unsigned char median_filter_win_size; // win size of median filter: 0 = 3x3, 1 = 5x5, 2 = 9x9, suggested value = 0
  /* rectification parameters */
  int src_width; // width of input image buffer of left&right camera.
  int src_height; // height of input image buffer of left&right camera.
  int rect_width; // cropped width after rectification, set to 0 if unnessary to do rectification.
  int rect_height; // cropped height after rectification, set to 0 if unnessary to do rectification.
  char rect_data_file_path[256]; // map data for left&right image epipolar rectification, we use two half-type value represents new coordiates(x, y),
                                    // so its file size is rect_width * rect_height * 2 * sizeof(half), ignored if it's unnessary to do rectification.
  /* disp2depth params */
  float rect_focal_length;
  float rect_baseline;
  float rect_left_cx;
  float rect_right_cx;
  float rect_cy;
  /* disp2scan params */
  int scan_height;
  float range_min;
  float range_max;
  float angle_min; // unessary to set it, it will be calculated automatically after depth_detection_lc_set_params() is called.
  float angle_max; // unessary to set it, it will be calculated automatically after depth_detection_lc_set_params() is called.
  float angle_increment; // unessary to set it, it will be calculated automatically after depth_detection_lc_set_params() is called.
};
typedef int(* WORKER_THREAD_CALLBACK) (int thread_idx, int thread_num);
extern "C" {
  void *depth_detection_lc_init(
    const char *kernel_file_path,
    bool kernel_is_source,
    WORKER_THREAD_CALLBACK worker_thread_callback,
    int worker_thread_num  // max worker thread num = 64
    );
  int depth_detection_lc_release(void *ctx);
  int depth_detection_lc_set_params(void *ctx, DEPTH_DETECTION_PARAM param);
  int depth_detection_lc_get_params(void *ctx, DEPTH_DETECTION_PARAM *param);
  // src_left_addr&src_right_addr are the address of Y component of left&right image: 
  // size = width * height, dst_addr is used to store disparity data: size = width * height
  int depth_detection_lc_get_disp(
    void *ctx,
    unsigned char *src_image_addr[2],
    unsigned short *disp_addr
    );
  int depth_detection_lc_get_rect_image_and_disp(
    void *ctx,
    unsigned char *src_image_addr[2],
    unsigned char *rect_image_addr[2],  // output rectified left/right images and disparity data
    unsigned short *disp_addr
    );
  int depth_detection_lc_get_depth(
    void *ctx,
    unsigned char *src_image_addr[2],
    unsigned short *depth_addr
    );
  int depth_detection_lc_get_rect_image_and_depth(
    void *ctx,
    unsigned char *src_image_addr[2],
    unsigned char *rect_image_addr[2], // output rectified left/right images and depth data
    unsigned short *depth_addr
    ); 
  int depth_detection_lc_get_scan(
    void *ctx,
    unsigned char *src_image_addr[2],
    float *scan_addr
    );
  int depth_detection_lc_get_rect_image_and_scan(
    void *ctx,
    unsigned char *src_image_addr[2],
    unsigned char *rect_image_addr[2], // output rectified left/right images and laser scan data
    float *scan_addr
    );
  const char *depth_detection_lc_version_code_get();
}
#endif
/* example
  #include <sched.h>
  #include <unistd.h>
  #include <sys/time.h>
  #include <sys/resource.h>
  int set_cpu_affinity(int cpu_idx) {
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu_idx, &set);
    return sched_setaffinity(gettid(), sizeof(cpu_set_t), &set);
  }
  int worker_thread_callback(int thread_idx, int thread_num) {
  #ifdef __ANDROID__
    int cpu_idx = thread_idx + 4; // for lc1881: 0~3 are little core, 4~8 are big cores
  #else
    int cpu_idx = thread_idx;
  #endif
    if(set_cpu_affinity(cpu_idx) != 0) {
      printf("worker thread %d: set cpu affinity(%d) failed\n", thread_idx, cpu_idx);
    } else {
      printf("worker thread %d: set cpu affinity(%d) successed\n", thread_idx, cpu_idx);
    }
  }
  // step 1. initialize depth detection context
  void *ctx = depth_detection_lc_init("/data/local/tmp/depth_detection_lc.cl", true, worker_thread_callback, 4);
  assert(ctx);
  // step 2.set parameters to depth detection context
  DEPTH_DETECTION_PARAM param;
  memset(&param, 0, sizeof(param));
  param.min_disp = 0;
  param.num_disp = 64;
  param.subpixel_shiftbits = 4;
  param.scanline_optimization_penalty1 = 20;
  param.scanline_optimization_penalty2 = 100;
  param.left_right_consistency_check_tolerance = 2;
  param.median_filter_win_size = 0;
  param.src_width = 640;
  param.src_height = 480;
  param.rect_width = 512;
  param.rect_height = 320;
  sprintf(param.rect_data_file_path[0], "%s", "/data/local/tmp/left_rect_mesh_data.dat");
  sprintf(param.rect_data_file_path[1], "%s", "/data/local/tmp/right_rect_mesh_data.dat");
  depth_detection_lc_set_params(ctx, param);
  // step 3. output disparity of left image and right image
  unsigned short *disp_addr = new unsigned short[param.rect_width * param.rect_height];
  foreach video frame
    unsigned char *src_image_addr[2] = {left_image_addr, right_image_addr};
    depth_detection_lc_calc_disp(ctx, src_image_addr, disp_addr);
  end
  delete dst_addr;
  // step4. destroy the context and release its resources if never use it
  depth_detection_lc_release(ctx);
*/
