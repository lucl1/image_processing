# DEPTH DETECTION library  
Note that: the library is device-independent, but the test case is device-dependent  
  
## Change lists  
2019/03/19 created by MingHong  
  
## Folder organization  
-inc&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Header files of the declaration of exported interfaces of libdepth_detection_lc.  
-src&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Source files of the implementation of libdepth_detection_lc.  
&nbsp;&nbsp;-android&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Android make file for building the libdepth_detection_lc.so for android platform.  
-test&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# An example to illustrate how to use the interfaces of libdepth_detection_lc.  
&nbsp;&nbsp;-android&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Android make file for building the example for android platform.  
&nbsp;&nbsp;-cases&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Test image(color format is NV12)  
  
## How to generate libuv_denoise_lc.so for android platform ?  
  $ cd src/android  
  $ ndk-build&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Compile & build, note that you need to prepare the android NDK enviroment  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# and ensure it works well.  
  $ cd libs & ls&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# OK, you will see two new folders, and libdepth_detection_lc.so will be created.  
&nbsp;&nbsp;arm64-v8a&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# For ARM 64bits  
&nbsp;&nbsp;armeabi-v7a&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# For ARM 32bits  
  
## How to execute the example(test case) on android platform ?  
  $ cd test/android  
  $ ndk-build  
  $ run.bat&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Window is only supported as host, and you should plugin you android device to the  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# host via USB before run the example(test case).  
  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# After the execution is finished, you will see an new YUV file named 'dst.yuv'  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# is generated under the folder '/test/cases/Road', then use YUVViewer to check it.  
  
## How to use the interfaces of libdepth_detection_lc ?  
  The header file 'inc/depth_detection_lc.h' gives the details about the interfaces of libdepth_detection_lc,  
  and you also can learn it at 'test/test.cpp'.