#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// horizontal forward&backward of scanline optimization, its original formula is shown as following:
// L(x,y,d) = C(x,y,d) + min {L(x-1,y,d), L(x-1,y,d-1)+ PENALTY1, L(x-1,y,d+1)+ PENALTY1, L(x-1,y,i) + PENALTY2} - L(x-1,y,i)
// According to our code, it can be modified as following:
// dst(x,y,d) = src(x,y,d) + min {P, N + PENALTY1, M + PENALTY2} - M
// N = min(L(x-1,y,d-1), L(x-1,y,d+1)) // minimum cost of two previous neighbors
// M = L(x-1,y,i) // minimum cost of all previous neigbors
#ifdef __ARM_NEON__
#include <arm_neon.h>
__extension__ static __inline uint8x16_t __attribute__ ((__always_inline__))
 min_vect(uint8x16_t data) {
  uint8x8_t _data = vmin_u8(vget_low_u8(data), vget_high_u8(data));
  uint8x8_t __data = vpmin_u8(_data, _data);
  uint8x8_t ___data = vpmin_u8(__data, __data);
  uint8x8_t ____data = vpmin_u8(___data, ___data);
  return vcombine_u8(____data, ____data);
}
int scanline_optimization(
  unsigned char *src,
  unsigned char *dst,
  unsigned char *row,
  int width,
  int height,
  unsigned short num_disp,
  unsigned short penalty1,
  unsigned short penalty2,
  int slice_start,
  int slice_end
  ) {
  if (num_disp > 1024) {
    printf("num_disp should be less than %d.\n", 1024);
    return -1;
  }
  int group_disp = num_disp / 16;
  if (group_disp == 1) {
    for (int y = slice_start; y < slice_end; y++) {
      uint8x16_t P = vdupq_n_u8(0);
      uint8x16_t M = vdupq_n_u8(0);
      for (int x = 0; x < width; x++) {
        int offset = (y * width + x) << 4;
        uint8x16_t N = vminq_u8(
          vextq_u8(vdupq_n_u8(vgetq_lane_u8(P, 0)), P, 15), 
          vextq_u8(P, vdupq_n_u8(vgetq_lane_u8(P, 15)), 1)
          );
        uint8x16_t Q = vqaddq_u8(M, vdupq_n_u8(penalty2));
        P = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset), vminq_u8(P, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + (x << 4), P);
        // minimum
        M = min_vect(P);
      }
      P = vdupq_n_u8(0);
      M = vdupq_n_u8(0);
      for (int x = width - 1; x >= 0; x--) {
        int offset = (y * width + x) << 4;
        uint8x16_t N = vminq_u8(
          vextq_u8(vdupq_n_u8(vgetq_lane_u8(P, 0)), P, 15), 
          vextq_u8(P, vdupq_n_u8(vgetq_lane_u8(P, 15)), 1)
          );
        uint8x16_t Q = vqaddq_u8(M, vdupq_n_u8(penalty2));
        P = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset), vminq_u8(P, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset, vqaddq_u8(vld1q_u8(row + (x << 4)), P));
        // minimum
        M = min_vect(P);
      }
    }
  } else if (group_disp == 2) {
    for (int y = slice_start; y < slice_end; y++) {
      uint8x16_t P0 = vdupq_n_u8(0);
      uint8x16_t P1 = vdupq_n_u8(0);
      uint8x16_t M = vdupq_n_u8(0);
      for (int x = 0; x < width; x++) {
        int offset = (y * width + x) << 5;
        // 0
        uint8x16_t N = vminq_u8(
          vextq_u8(vdupq_n_u8(vgetq_lane_u8(P0, 0)), P0, 15), 
          vextq_u8(P0, P1, 1)
          );
        uint8x16_t Q = vqaddq_u8(M, vdupq_n_u8(penalty2));
        uint8x16_t C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset), vminq_u8(P0, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + (x << 5), C);
        // 1
        N = vminq_u8(
          vextq_u8(P0, P1, 15),
          vextq_u8(P1, vdupq_n_u8(vgetq_lane_u8(P1, 15)), 1)
          );
        P0 = C;
        P1 = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 16), vminq_u8(P1, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + (x << 5) + 16, P1);
        // minimum
        M = min_vect(vminq_u8(P0, P1));
      }
      P0 = vdupq_n_u8(0);
      P1 = vdupq_n_u8(0);
      M = vdupq_n_u8(0);
      for (int x = width - 1; x >= 0; x--) {
        int offset = (y * width + x) << 5;
        // 0
        uint8x16_t N = vminq_u8(
          vextq_u8(vdupq_n_u8(vgetq_lane_u8(P0, 0)), P0, 15), 
          vextq_u8(P0, P1, 1)
          );
        uint8x16_t Q = vqaddq_u8(M, vdupq_n_u8(penalty2));
        uint8x16_t C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset), vminq_u8(P0, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset, vqaddq_u8(vld1q_u8(row + (x << 5)), P0));
        // 1
        N = vminq_u8(
          vextq_u8(P0, P1, 15),
          vextq_u8(P1, vdupq_n_u8(vgetq_lane_u8(P1, 15)), 1)
          );
        P0 = C;
        P1 = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 16), vminq_u8(P1, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset + 16, vqaddq_u8(vld1q_u8(row + (x << 5) + 16), P1));
        // minimum
        M = min_vect(vminq_u8(P0, P1));
      }
    }
  } else if (group_disp == 3) {
    for (int y = slice_start; y < slice_end; y++) {
      uint8x16_t P0 = vdupq_n_u8(0);
      uint8x16_t P1 = vdupq_n_u8(0);
      uint8x16_t P2 = vdupq_n_u8(0);
      uint8x16_t M = vdupq_n_u8(0);
      for (int x = 0; x < width; x++) {
        int offset = (y * width + x) * 48;
        // 0
        uint8x16_t N = vminq_u8(
          vextq_u8(vdupq_n_u8(vgetq_lane_u8(P0, 0)), P0, 15), 
          vextq_u8(P0, P1, 1)
          );
        uint8x16_t Q = vqaddq_u8(M, vdupq_n_u8(penalty2));
        uint8x16_t C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset), vminq_u8(P0, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + x * 48, C);
        // 1
        N = vminq_u8(
          vextq_u8(P0, P1, 15),
          vextq_u8(P1, P2, 1)
          );
        P0 = C;
        C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 16), vminq_u8(P1, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + x * 48 + 16, C);
        // 1
        N = vminq_u8(
          vextq_u8(P1, P2, 15),
          vextq_u8(P2, vdupq_n_u8(vgetq_lane_u8(P2, 15)), 1)
          );
        P1 = C;
        P2 = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 32), vminq_u8(P2, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + x * 48 + 32, P2);
        // minimum
        M = min_vect(vminq_u8(vminq_u8(P0, P1), P2));
      }
      P0 = vdupq_n_u8(0);
      P1 = vdupq_n_u8(0);
      P2 = vdupq_n_u8(0);
      M = vdupq_n_u8(0);
      for (int x = width - 1; x >= 0; x--) {
        int offset = (y * width + x) * 48;
        // 0
        uint8x16_t N = vminq_u8(
          vextq_u8(vdupq_n_u8(vgetq_lane_u8(P0, 0)), P0, 15), 
          vextq_u8(P0, P1, 1)
          );
        uint8x16_t Q = vqaddq_u8(M, vdupq_n_u8(penalty2));
        uint8x16_t C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset), vminq_u8(P0, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset, vqaddq_u8(vld1q_u8(row + x * 48), C));
        // 1
        N = vminq_u8(
          vextq_u8(P0, P1, 15),
          vextq_u8(P1, P2, 1)
          );
        P0 = C;
        C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 16), vminq_u8(P1, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset + 16, vqaddq_u8(vld1q_u8(row + x * 48 + 16), C));
        // 2
        N = vminq_u8(
          vextq_u8(P1, P2, 15),
          vextq_u8(P2, vdupq_n_u8(vgetq_lane_u8(P2, 15)), 1)
          );
        P1 = C;
        P2 = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 32), vminq_u8(P2, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset + 32, vqaddq_u8(vld1q_u8(row + x * 48 + 32), P2));
        // minimum
        M = min_vect(vminq_u8(vminq_u8(P0, P1), P2));
      }
    }
  } else if (group_disp == 4) {
    for (int y = slice_start; y < slice_end; y++) {
      uint8x16_t P0 = vdupq_n_u8(0);
      uint8x16_t P1 = vdupq_n_u8(0);
      uint8x16_t P2 = vdupq_n_u8(0);
      uint8x16_t P3 = vdupq_n_u8(0);
      uint8x16_t M = vdupq_n_u8(0);
      for (int x = 0; x < width; x++) {
        int offset = (y * width + x) << 6;
        // 0
        uint8x16_t N = vminq_u8(
          vextq_u8(vdupq_n_u8(vgetq_lane_u8(P0, 0)), P0, 15), 
          vextq_u8(P0, P1, 1)
          );
        uint8x16_t Q = vqaddq_u8(M, vdupq_n_u8(penalty2));
        uint8x16_t C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset), vminq_u8(P0, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + (x << 6), C);
        // 1
        N = vminq_u8(
          vextq_u8(P0, P1, 15),
          vextq_u8(P1, P2, 1)
          );
        P0 = C;
        C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 16), vminq_u8(P1, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + (x << 6) + 16, C);
        // 2
        N = vminq_u8(
          vextq_u8(P1, P2, 15),
          vextq_u8(P2, P3, 1)
          );
        P1 = C;
        C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 32), vminq_u8(P2, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + (x << 6) + 32, C);
        // 3
        N = vminq_u8(
          vextq_u8(P2, P3, 15),
          vextq_u8(P3, vdupq_n_u8(vgetq_lane_u8(P3, 15)), 1)
          );
        P2 = C;
        P3 = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 48), vminq_u8(P3, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + (x << 6) + 48, P3);
        // minimum
        M = min_vect(vminq_u8(vminq_u8(vminq_u8(P0, P1), P2), P3));
      }
      P0 = vdupq_n_u8(0);
      P1 = vdupq_n_u8(0);
      P2 = vdupq_n_u8(0);
      P3 = vdupq_n_u8(0);
      M = vdupq_n_u8(0);
      for (int x = width - 1; x >= 0; x--) {
        int offset = (y * width + x) << 6;
        // 0
        uint8x16_t N = vminq_u8(
          vextq_u8(vdupq_n_u8(vgetq_lane_u8(P0, 0)), P0, 15), 
          vextq_u8(P0, P1, 1)
          );
        uint8x16_t Q = vqaddq_u8(M, vdupq_n_u8(penalty2));
        uint8x16_t C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset), vminq_u8(P0, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset, vqaddq_u8(vld1q_u8(row + (x << 6)), C));
        // 1
        N = vminq_u8(
          vextq_u8(P0, P1, 15),
          vextq_u8(P1, P2, 1)
          );
        P0 = C;
        C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 16), vminq_u8(P1, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset + 16, vqaddq_u8(vld1q_u8(row + (x << 6) + 16), C));
        // 2
        N = vminq_u8(
          vextq_u8(P1, P2, 15),
          vextq_u8(P2, P3, 1)
          );
        P1 = C;
        C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 32), vminq_u8(P2, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset + 32, vqaddq_u8(vld1q_u8(row + (x << 6) + 32), C));
        // 3
        N = vminq_u8(
          vextq_u8(P2, P3, 15),
          vextq_u8(P3, vdupq_n_u8(vgetq_lane_u8(P3, 15)), 1)
          );
        P2 = C;
        P3 = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + 48), vminq_u8(P3, vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset + 48, vqaddq_u8(vld1q_u8(row + (x << 6) + 48), C));
        // minimum
        M = min_vect(vminq_u8(vminq_u8(vminq_u8(P0, P1), P2), P3));
      }
    }
  } else {
    for (int y = slice_start; y < slice_end; y++) {
      uint8x16_t P[64];
      for (int i = 0; i < group_disp; i++) {
        P[i] = vdupq_n_u8(0);
      }
      uint8x16_t M = vdupq_n_u8(0);
      for (int x = 0; x < width; x++) {
        int offset = (y * width + x) * num_disp;
        // 0
        uint8x16_t N = vminq_u8(
          vextq_u8(vdupq_n_u8(vgetq_lane_u8(P[0], 0)), P[0], 15), 
          vextq_u8(P[0], P[1], 1)
          );
        uint8x16_t Q = vqaddq_u8(M, vdupq_n_u8(penalty2));
        uint8x16_t C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset), vminq_u8(P[0], vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + x * num_disp, C);
        uint8x16_t mins = C;
        // 1 ~ GROUP_DISP - 2
        for (int i = 1; i <= group_disp - 2; i++) {
          N = vminq_u8(
            vextq_u8(P[i - 1], P[i], 15),
            vextq_u8(P[i], P[i + 1], 1)
            );
          P[i - 1] = C;
          C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + i * 16), vminq_u8(P[i], vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
          vst1q_u8(row + x * num_disp + i * 16, C);
          mins = vminq_u8(mins, C);
        }
        // GROUP_DISP - 1
        N = vminq_u8(
          vextq_u8(P[group_disp - 2], P[group_disp - 1], 15),
          vextq_u8(P[group_disp - 1], vdupq_n_u8(vgetq_lane_u8(P[group_disp - 1], 15)), 1)
          );
        P[group_disp - 2] = C;
        P[group_disp - 1] = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + (group_disp - 1) * 16), vminq_u8(P[group_disp - 1], vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(row + x * num_disp + (group_disp - 1) * 16, P[group_disp - 1]);
        mins = vminq_u8(mins, P[group_disp - 1]);
        // minimum
        M = min_vect(mins);
      }
      for (int i = 0; i < group_disp; i++) {
        P[i] = vdupq_n_u8(0);
      }
      M = vdupq_n_u8(0);
      for (int x = width - 1; x >= 0; x--) {
        int offset = (y * width + x) * num_disp;
        // 0
        uint8x16_t N = vminq_u8(
          vextq_u8(vdupq_n_u8(vgetq_lane_u8(P[0], 0)), P[0], 15), 
          vextq_u8(P[0], P[1], 1)
          );
        uint8x16_t Q = vqaddq_u8(M, vdupq_n_u8(penalty2));
        uint8x16_t C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset), vminq_u8(P[0], vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset, vqaddq_u8(vld1q_u8(row + x * num_disp), C));
        uint8x16_t mins = C;
        // 1 ~ GROUP_DISP - 2
        for (int i = 1; i <= group_disp - 2; i++) {
          N = vminq_u8(
            vextq_u8(P[i - 1], P[i], 15),
            vextq_u8(P[i], P[i + 1], 1)
            );
          P[i - 1] = C;
          C = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + i * 16), vminq_u8(P[i], vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
          vst1q_u8(dst + offset + i * 16, vqaddq_u8(vld1q_u8(row + x * num_disp + i * 16), C));
          mins = vminq_u8(mins, C);
        }
        // GROUP_DISP - 1
        N = vminq_u8(
          vextq_u8(P[group_disp - 2], P[group_disp - 1], 15),
          vextq_u8(P[group_disp - 1], vdupq_n_u8(vgetq_lane_u8(P[group_disp - 1], 15)), 1)
          );
        P[group_disp - 2] = C;
        P[group_disp - 1] = vqsubq_u8(vqaddq_u8(vld1q_u8(src + offset + (group_disp - 1) * 16), vminq_u8(P[group_disp - 1], vminq_u8(vqaddq_u8(N, vdupq_n_u8(penalty1)), Q))), M);
        vst1q_u8(dst + offset + (group_disp - 1) * 16, vqaddq_u8(vld1q_u8(row + x * num_disp + (group_disp - 1) * 16), C));
        mins = vminq_u8(mins, P[group_disp - 1]);
        // minimum
        M = min_vect(mins);
      }
    }
  }
  return 0;
}
#else
// otherwise, use naive version, but bad performance
#define MIN(X,Y) ((X) < (Y) ? (X) : (Y))
#define MAX(X,Y) ((X) > (Y) ? (X) : (Y))
int scanline_optimization(
  unsigned char *src,
  unsigned char *dst,
  unsigned char *row,
  int width,
  int height,
  unsigned short num_disp,
  unsigned short penalty1,
  unsigned short penalty2,
  int slice_start,
  int slice_end 
  ) {
  if (num_disp > 1024) {
    printf("num_disp should be less than %d.\n", 1024);
    return -1;
  }
  for (int y = slice_start; y < slice_end; y++) {
    int P[1024];
    memset(P, 0, sizeof(int) * num_disp);
    int M = 0;
    for (int x = 0; x < width; x++) {
      int offset = (y * width + x) * num_disp;
      // 0
      int N = MIN(P[0], P[1]);
      int Q = MIN(M + penalty2, 255);
      int C = MAX(MIN(src[offset] + MIN(P[0], MIN(MIN(N + penalty1, 255), Q)), 255) - M, 0);
      row[x * num_disp] = C;
      int mins = C;
      // 1 ~ NUM_DISP - 2
      for (int i = 1; i <= num_disp - 2; i++) {
        N = MIN(P[i - 1], P[i + 1]);
        P[i - 1] = C;
        C = MAX(MIN(src[offset + i] + MIN(P[i], MIN(MIN(N + penalty1, 255), Q)), 255) - M, 0);
        row[x * num_disp + i] = C;
        mins = MIN(mins, C);
      }
      // NUM_DISP - 1
      N = MIN(P[num_disp - 2], P[num_disp - 1]);
      P[num_disp - 2] = C;
      P[num_disp - 1] = MAX(MIN(src[offset + num_disp - 1] + MIN(P[num_disp - 1], MIN(MIN(N + penalty1, 255), Q)), 255) - M, 0);
      row[x * num_disp + num_disp - 1] = P[num_disp - 1];
      mins = MIN(mins, P[num_disp - 1]);
      // minimum
      M = mins;
    }
    memset(P, 0, sizeof(int) * num_disp);
    M = 0;
    for (int x = width - 1; x >= 0; x--) {
      int offset = (y * width + x) * num_disp;
      // 0
      int N = MIN(P[0], P[1]);
      int Q = MIN(M + penalty2, 255);
      int C = MAX(MIN(src[offset] + MIN(P[0], MIN(MIN(N + penalty1, 255), Q)), 255) -  M, 0);
      dst[offset] = MIN(row[x * num_disp] + C, 255);
      int mins = C;
      // 1 ~ NUM_DISP - 2
      for (int i = 1; i <= num_disp - 2; i++) {
        N = MIN(P[i - 1], P[i + 1]);
        P[i - 1] = C;
        C = MAX(MIN(src[offset + i] + MIN(P[i], MIN(MIN(N + penalty1, 255), Q)), 255) -  M, 0);
        dst[offset + i] = MIN(row[x * num_disp + i] + C, 255);
        mins = MIN(mins, C);
      }
      // NUM_DISP - 1
      N = MIN(P[num_disp - 2], P[num_disp - 1]);
      P[num_disp - 2] = C;
      P[num_disp - 1] = MAX(MIN(src[offset + num_disp - 1] + MIN(P[num_disp - 1], MIN(MIN(N + penalty1, 255), Q)), 255) -  M, 0);
      dst[offset + num_disp - 1] = MIN(row[x * num_disp + num_disp - 1] + P[num_disp - 1], 255);
      mins = MIN(mins, P[num_disp - 1]);
      // minimum
      M = mins;
    }
  }
  return 0;
}
#endif