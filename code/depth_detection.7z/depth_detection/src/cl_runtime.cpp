#if defined(__APPLE__)
    #include <dlfcn.h>

    static void* AppleCLGetProcAddress(const char* name)
    {
        static void * image = NULL;
        if (!image)
        {
            image = dlopen("/System/Library/Frameworks/OpenCL.framework/Versions/Current/OpenCL", RTLD_LAZY | RTLD_GLOBAL);
            if (!image)
                return NULL;
        }

        return dlsym(image, name);
    }
    #define CL_GET_PROC_ADDRESS(name) AppleCLGetProcAddress(name)
#endif // __APPLE__

#if defined(_WIN32)
    #include <windows.h>
    static void* WinGetProcAddress(const char* name)
    {
        static HMODULE opencl_module = NULL;
        if (!opencl_module)
        {
            opencl_module = GetModuleHandleA("OpenCL.dll");
            if (!opencl_module)
            {
                opencl_module = LoadLibraryA("OpenCL.dll");
                if (!opencl_module)
                    return NULL;
            }
        }
        return (void*)GetProcAddress(opencl_module, name);
    }
    #define CL_GET_PROC_ADDRESS(name) WinGetProcAddress(name)
#endif // _WIN32

#if defined(__linux__)&&!defined(__ANDROID__)
    #include <dlfcn.h>
    #include <stdio.h>
    #include <string.h>

    static void* GetProcAddress (const char* name)
    {
        static void* h = NULL;
        if (!h)
        {
            h = dlopen("libOpenCL.so", RTLD_LAZY | RTLD_GLOBAL);
            if (!h)
                return NULL;
        }

        return dlsym(h, name);
    }
    #define CL_GET_PROC_ADDRESS(name) GetProcAddress(name)
#endif

#if defined(__ANDROID__)
    #include <dlfcn.h>
    #include <sys/stat.h>
#if defined(_X64_)
    static const char *default_so_paths[] = {
                                            "/system/lib64/libOpenCL.so",
                                            "/system/lib64/egl/libGLES_mali.so",
                                            "/system/vendor/lib64/libOpenCL.so",
                                            "/system/vendor/lib64/egl/libGLES_mali.so"
                                          };
#else
    static const char *default_so_paths[] = {
                                            "/system/lib/libOpenCL.so",
                                            "/system/lib/egl/libGLES_mali.so",
                                            "/system/vendor/lib/libOpenCL.so",
                                            "/system/vendor/lib/egl/libGLES_mali.so"
                                          };
#endif
    static int access_file(const char *filename)
    {
        struct stat buffer;
        return (stat(filename, &buffer) == 0);
    }

    static void* GetProcAddress (const char* name)
    {
        static void* h = NULL;
        unsigned int i;
        if (!h)
        {
            const char* name;
            for(i = 0; i < (sizeof(default_so_paths) / sizeof(char*)); i++)
            {
                if(access_file(default_so_paths[i])) {
                    name = (char *)default_so_paths[i];
                    h = dlopen(name, RTLD_LAZY);
                    if (h) break;
                }
            }
            if (!h)
                return NULL;
        }

        return dlsym(h, name);
    }
    #define CL_GET_PROC_ADDRESS(name) GetProcAddress(name)
#endif  //android

#ifndef CL_GET_PROC_ADDRESS
#define CL_GET_PROC_ADDRESS(name) NULL
#endif

#include "cl_runtime.h"
#include "utils.h"

template <typename T>
T CL_CHECK_PROC_ADDRESS(const char *name) {
   T s = (T)CL_GET_PROC_ADDRESS(name);
   if (!s) {
     printf("OpenCL API %s not found\n", name);
   }
   return s;
}

#define CL_FN(ret, fn, args) ret (CL_API_CALL *fn)args = CL_CHECK_PROC_ADDRESS<ret (CL_API_CALL *)args>(#fn);
#include "cl_function.h"

void __CHECK__(cl_int err, const char *file, const int line, const char *func) {
  if (CL_SUCCESS != err) {
    char msg[255];
    switch (err)
    {
    case CL_DEVICE_NOT_FOUND:
      strcpy(msg, "CL_DEVICE_NOT_FOUND");
      break;
    case CL_DEVICE_NOT_AVAILABLE:
      strcpy(msg, "CL_DEVICE_NOT_AVAILABLE");
      break;
    case CL_COMPILER_NOT_AVAILABLE:
      strcpy(msg, "CL_COMPILER_NOT_AVAILABLE");
      break;
    case CL_MEM_OBJECT_ALLOCATION_FAILURE:
      strcpy(msg, "CL_MEM_OBJECT_ALLOCATION_FAILURE");
      break;
    case CL_OUT_OF_RESOURCES:
      strcpy(msg, "CL_OUT_OF_RESOURCES");
      break;
    case CL_OUT_OF_HOST_MEMORY:
      strcpy(msg, "CL_OUT_OF_HOST_MEMORY");
      break;
    case CL_PROFILING_INFO_NOT_AVAILABLE:
      strcpy(msg, "CL_PROFILING_INFO_NOT_AVAILABLE");
      break;
    case CL_MEM_COPY_OVERLAP:
      strcpy(msg, "CL_MEM_COPY_OVERLAP");
      break;
    case CL_IMAGE_FORMAT_MISMATCH:
      strcpy(msg, "CL_IMAGE_FORMAT_MISMATCH");
      break;
    case CL_IMAGE_FORMAT_NOT_SUPPORTED:
      strcpy(msg, "CL_IMAGE_FORMAT_NOT_SUPPORTED");
      break;
    case CL_BUILD_PROGRAM_FAILURE:
      strcpy(msg, "CL_BUILD_PROGRAM_FAILURE");
      break;
    case CL_MAP_FAILURE:
      strcpy(msg, "CL_MAP_FAILURE");
      break;
    case CL_MISALIGNED_SUB_BUFFER_OFFSET:
      strcpy(msg, "CL_MISALIGNED_SUB_BUFFER_OFFSET");
      break;
    case CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST:
      strcpy(msg, "CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST");
      break;
    case CL_INVALID_VALUE:
      strcpy(msg, "CL_INVALID_VALUE");
      break;
    case CL_INVALID_DEVICE_TYPE:
      strcpy(msg, "CL_INVALID_DEVICE_TYPE");
      break;
    case CL_INVALID_PLATFORM:
      strcpy(msg, "CL_INVALID_PLATFORM");
      break;
    case CL_INVALID_DEVICE:
      strcpy(msg, "CL_INVALID_DEVICE");
      break;
    case CL_INVALID_CONTEXT:
      strcpy(msg, "CL_INVALID_CONTEXT");
      break;
    case CL_INVALID_QUEUE_PROPERTIES:
      strcpy(msg, "CL_INVALID_QUEUE_PROPERTIES");
      break;
    case CL_INVALID_COMMAND_QUEUE:
      strcpy(msg, "CL_INVALID_COMMAND_QUEUE");
      break;
    case CL_INVALID_HOST_PTR:
      strcpy(msg, "CL_INVALID_HOST_PTR");
      break;
    case CL_INVALID_MEM_OBJECT:
      strcpy(msg, "CL_INVALID_MEM_OBJECT");
      break;
    case CL_INVALID_IMAGE_FORMAT_DESCRIPTOR:
      strcpy(msg, "CL_INVALID_IMAGE_FORMAT_DESCRIPTOR");
      break;
    case CL_INVALID_IMAGE_SIZE:
      strcpy(msg, "CL_INVALID_IMAGE_SIZE");
      break;
    case CL_INVALID_SAMPLER:
      strcpy(msg, "CL_INVALID_SAMPLER");
      break;
    case CL_INVALID_BINARY:
      strcpy(msg, "CL_INVALID_BINARY");
      break;
    case CL_INVALID_BUILD_OPTIONS:
      strcpy(msg, "CL_INVALID_BUILD_OPTIONS");
      break;
    case CL_INVALID_PROGRAM:
      strcpy(msg, "CL_INVALID_PROGRAM");
      break;
    case CL_INVALID_PROGRAM_EXECUTABLE:
      strcpy(msg, "CL_INVALID_PROGRAM_EXECUTABLE");
      break;
    case CL_INVALID_KERNEL_NAME:
      strcpy(msg, "CL_INVALID_KERNEL_NAME");
      break;
    case CL_INVALID_KERNEL_DEFINITION:
      strcpy(msg, "CL_INVALID_KERNEL_DEFINITION");
      break;
    case CL_INVALID_KERNEL:
      strcpy(msg, "CL_INVALID_KERNEL");
      break;
    case CL_INVALID_ARG_INDEX:
      strcpy(msg, "CL_INVALID_ARG_INDEX");
      break;
    case CL_INVALID_ARG_VALUE:
      strcpy(msg, "CL_INVALID_ARG_VALUE");
      break;
    case CL_INVALID_ARG_SIZE:
      strcpy(msg, "CL_INVALID_ARG_SIZE");
      break;
    case CL_INVALID_KERNEL_ARGS:
      strcpy(msg, "CL_INVALID_KERNEL_ARGS");
      break;
    case CL_INVALID_WORK_DIMENSION:
      strcpy(msg, "CL_INVALID_WORK_DIMENSION");
      break;
    case CL_INVALID_WORK_GROUP_SIZE:
      strcpy(msg, "CL_INVALID_WORK_GROUP_SIZE");
      break;
    case CL_INVALID_WORK_ITEM_SIZE:
      strcpy(msg, "CL_INVALID_WORK_ITEM_SIZE");
      break;
    case CL_INVALID_GLOBAL_OFFSET:
      strcpy(msg, "CL_INVALID_GLOBAL_OFFSET");
      break;
    case CL_INVALID_EVENT_WAIT_LIST:
      strcpy(msg, "CL_INVALID_EVENT_WAIT_LIST");
      break;
    case CL_INVALID_EVENT:
      strcpy(msg, "CL_INVALID_EVENT");
      break;
    case CL_INVALID_OPERATION:
      strcpy(msg, "CL_INVALID_OPERATION");
      break;
    case CL_INVALID_GL_OBJECT:
      strcpy(msg, "CL_INVALID_GL_OBJECT");
      break;
    case CL_INVALID_BUFFER_SIZE:
      strcpy(msg, "CL_INVALID_BUFFER_SIZE");
      break;
    case CL_INVALID_MIP_LEVEL:
      strcpy(msg, "CL_INVALID_MIP_LEVEL");
      break;
    case CL_INVALID_GLOBAL_WORK_SIZE:
      strcpy(msg, "CL_INVALID_GLOBAL_WORK_SIZE");
      break;
    case CL_INVALID_PROPERTY:
      strcpy(msg, "CL_INVALID_PROPERTY");
      break;
    case CL_INVALID_IMAGE_DESCRIPTOR:
      strcpy(msg, "CL_INVALID_IMAGE_DESCRIPTOR");
      break;
    case CL_INVALID_COMPILER_OPTIONS:
      strcpy(msg, "CL_INVALID_COMPILER_OPTIONS");
      break;
    case CL_INVALID_LINKER_OPTIONS:
      strcpy(msg, "CL_INVALID_LINKER_OPTIONS");
      break;
    case CL_INVALID_DEVICE_PARTITION_COUNT:
      strcpy(msg, "CL_INVALID_DEVICE_PARTITION_COUNT");
      break;
    default:
      sprintf(msg, "Unknown CL error code(%d)", err);
      break;
    }
    printf("CL ERROR: %s in %s, file %s, line %d\n", msg, func, file, line);
    getchar();
    exit(-1);
  }
}

void __RUN__(const char *name, cl_command_queue cmd_queue, cl_kernel kernel, cl_uint work_dim, const size_t *global_work_offset, const size_t *global_work_size, const size_t *local_work_size, cl_uint num_events_in_wait_list, const cl_event * event_wait_list, cl_event * event, const char *file, const int line, const char *func) {
#if defined(__PROFILING__)
  cl_event e = NULL;
  CHECK(clEnqueueNDRangeKernel(cmd_queue,
    kernel,
    work_dim,
    global_work_offset,
    global_work_size,
    local_work_size,
    0,
    NULL,
    &e));

  cl_ulong start_time, end_time, queue_time;

  CHECK(clWaitForEvents(1, &e));

  CHECK(clGetEventProfilingInfo(e,
    CL_PROFILING_COMMAND_START,
    sizeof(cl_ulong),
    &start_time,
    0));

  CHECK(clGetEventProfilingInfo(e,
    CL_PROFILING_COMMAND_END,
    sizeof(cl_ulong),
    &end_time,
    0));

  CHECK(clGetEventProfilingInfo(e,
    CL_PROFILING_COMMAND_QUEUED,
    sizeof(cl_ulong),
    &queue_time,
    0));

  double execute_time = (double)(end_time - start_time) / 1000000;
  double total_time = (double)(end_time - queue_time) / 1000000;

  printf( "Kernel Name                     Execute time(ms)    Lauch time(ms)      Total time(ms)\n" );
  printf("%-32s%-20.2f%-20.2f%-20.2f\n", name, execute_time, total_time - execute_time, total_time);
  clReleaseEvent(e);
#elif defined(__MEASURING__)
  uint64_t start_time = get_timestamp();
  CHECK(clEnqueueNDRangeKernel(cmd_queue,
    kernel,
    work_dim,
    global_work_offset,
    global_work_size,
    local_work_size,
    0,
    NULL,
    NULL));
  clFinish(cmd_queue);
  double total_time = get_duration(start_time) * 1000.0f;
  printf( "Kernel Name                     Total time(ms)\n" );
  printf("%-32s%-20.2f\n", name, total_time);
#else
  CHECK(clEnqueueNDRangeKernel(cmd_queue,
    kernel,
    work_dim,
    global_work_offset,
    global_work_size,
    local_work_size,
    num_events_in_wait_list,
    event_wait_list,
    event));
#endif
  clFlush(cmd_queue);
}
