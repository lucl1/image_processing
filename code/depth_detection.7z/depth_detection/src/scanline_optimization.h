// horizontal forward&backward of scanline optimization
int scanline_optimization(
  unsigned char *src,
  unsigned char *dst,
  unsigned char *row,
  int width,
  int height,
  unsigned short num_disp,
  unsigned short penalty1,
  unsigned short penalty2,
  int slice_start,
  int slice_end);
