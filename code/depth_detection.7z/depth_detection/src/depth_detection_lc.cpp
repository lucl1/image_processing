#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h>
#include <limits>
#include "depth_detection_lc.h"
#include "scanline_optimization.h"
#include "cl_runtime.h"
#include "utils.h"

using namespace std;

#ifdef _WIN32
#include <windows.h>
#define DEBUG(...) printf(__VA_ARGS__)
#define ERROR(...) printf(__VA_ARGS__)
#define WARNING(...) printf(__VA_ARGS__)
#define isfinite(x) _finite(x)
#define isnan(x) _isnan(x)
#else
#include <pthread.h>
#include <semaphore.h>
#ifdef __ANDROID__
#include <android/log.h>
//#define DEBUG(...) __android_log_print(ANDROID_LOG_DEBUG, "depth_detection_lc", __VA_ARGS__)
#define DEBUG(...) printf(__VA_ARGS__)
//#define ERROR(...) __android_log_print(ANDROID_LOG_ERROR, "depth_detection_lc", __VA_ARGS__)
#define ERROR(...) printf(__VA_ARGS__)
#define WARNING(...) printf(__VA_ARGS__)
#else
#define DEBUG(...) printf(__VA_ARGS__)
#define ERROR(...) printf(__VA_ARGS__)
#define WARNING(...) printf(__VA_ARGS__)
#endif
#endif

#ifdef _WIN32
#define DUMP
#endif

const int MAX_MEDIAN_FILTER_WIN_SIZE = 3;
const int MEDIAN_FILTER_WIN_SIZE[MAX_MEDIAN_FILTER_WIN_SIZE] = {3, 5, 9};

struct WORKER_THREAD_CTX;
class DEPTH_DETCTION_CTX {
public:
  // functions
  DEPTH_DETCTION_CTX(
    const char *_kernel_file_path,
    bool _kernel_is_source,
    WORKER_THREAD_CALLBACK _worker_thread_callback,
    int _worker_thread_num
    );
  ~DEPTH_DETCTION_CTX();
  int create_worker_threads();
  void release_worker_threads();
  int create_buffers();
  void release_buffers();
  int create_kernels();
  void release_kernels();
  int process(
    unsigned char **src_image_addr,
    unsigned char **rect_image_addr,
    unsigned short *disp_addr,
    unsigned short *depth_addr,
    float *scan_addr
    );
private:
  /* opencl context variables */
  cl_context context;
  cl_command_queue master_queue;
  cl_command_queue worker_queue;
  cl_device_id device_id;
  char device_name[256];
  char device_version[256];
  char kernel_file_path[256];
  bool kernel_is_source;
  cl_kernel kernel_epipolar_rectification;
  cl_kernel kernel_mean_filter_3x3_except_borders;
  cl_kernel kernel_mean_filter_3x3_for_borders;
  cl_kernel kernel_sct_9x9_except_borders;
  cl_kernel kernel_sct_9x9_for_borders;
  cl_kernel kernel_sct_9x9_block_matching;
  cl_kernel kernel_cost_aggregation_x;
  cl_kernel kernel_cost_aggregation_y;
  cl_kernel kernel_scanline_optimization;
  cl_kernel kernel_winner_takes_all;
  cl_kernel kernel_left_right_consistency_check;
  cl_kernel kernel_sct_9x9_textureless_filter_except_borders;
  cl_kernel kernel_sct_9x9_textureless_filter_for_borders;
  cl_kernel kernel_median_filter_x_except_borders;
  cl_kernel kernel_median_filter_x_for_borders;
  cl_kernel kernel_median_filter_y;
  cl_kernel kernel_disp2depth;
  /* opencl buffers */
  cl_mem T[3]; // for initial matching cost or aggregated matching cost
  cl_mem src_image; // only for storing un-rectified left&right images
  cl_mem rect_data; // only for storing rectified left&right map data
  cl_mem rect_image; // only for storing rectified left&right images
public:
  /* worker thread variables */
  WORKER_THREAD_CALLBACK worker_thread_callback;
  int worker_thread_num;
  WORKER_THREAD_CTX *worker_thread_ctx;
  /* algorithm parameters */
  DEPTH_DETECTION_PARAM param;
  int width;
  int height;
};

DEPTH_DETCTION_CTX::DEPTH_DETCTION_CTX(
  const char *_kernel_file_path,
  bool _kernel_is_source,
  WORKER_THREAD_CALLBACK _worker_thread_callback,
  int _worker_thread_num
  ) {
  /* reset opencl context variables */
  context = NULL;
  master_queue = NULL;
  worker_queue = NULL;
  strcpy(kernel_file_path, _kernel_file_path);
  kernel_is_source = _kernel_is_source;
  kernel_epipolar_rectification = NULL;
  kernel_mean_filter_3x3_except_borders = NULL;
  kernel_mean_filter_3x3_for_borders = NULL;
  kernel_sct_9x9_except_borders = NULL;
  kernel_sct_9x9_for_borders = NULL;
  kernel_sct_9x9_block_matching = NULL;
  kernel_cost_aggregation_x = NULL;
  kernel_cost_aggregation_y = NULL;
  kernel_scanline_optimization = NULL;
  kernel_winner_takes_all = NULL;
  kernel_left_right_consistency_check = NULL;
  kernel_sct_9x9_textureless_filter_except_borders = NULL;
  kernel_sct_9x9_textureless_filter_for_borders = NULL;
  kernel_median_filter_x_except_borders = NULL;
  kernel_median_filter_x_for_borders = NULL;
  kernel_median_filter_y = NULL;
  kernel_disp2depth = NULL;
  /* reset opencl buffers */
  for (int i = 0; i < 3; i++) {
    T[i] = NULL;
  }
  src_image = NULL;
  rect_data = NULL;
  rect_image = NULL;
  /* reset algorithm parameters */
  memset(&param, 0, sizeof(DEPTH_DETECTION_PARAM));
  param.min_disp = 0;
  param.num_disp = 0;
  param.src_width = -1;
  param.src_height = -1;
  param.rect_width = -1;
  param.rect_height = -1;
  width = 0;
  height = 0;
  /* create worker threads */
  worker_thread_callback = _worker_thread_callback;
  worker_thread_num = _worker_thread_num;
  if (create_worker_threads()) {
    exit(-1);
  }
  /* prepare cl environment */
  cl_int status = CL_SUCCESS;
  // query all the platforms, set the first one as default
  cl_uint numPlatformIds = 0;
  status = clGetPlatformIDs(0, NULL, &numPlatformIds);
  if (status == CL_DEVICE_NOT_FOUND) {
    ERROR("cl platform not found\n");
    exit(-1);
  }
  cl_platform_id *platformIds = new cl_platform_id[numPlatformIds];
  assert(!!platformIds);
  CHECK(clGetPlatformIDs(numPlatformIds, platformIds, NULL));
  DEBUG("%d cl platforms found:\n", numPlatformIds);
  cl_platform_id platformId = NULL;
  cl_uint numDeviceIds = 0;
  for (unsigned i = 0; i < numPlatformIds; ++i) {
    char name[256];
    char vendor[256];
    char version[256];
    platformId = platformIds[i];
    CHECK(clGetPlatformInfo(platformId, CL_PLATFORM_NAME, 256, name, NULL));
    CHECK(clGetPlatformInfo(platformId, CL_PLATFORM_VENDOR, 256, vendor, NULL));
    CHECK(clGetPlatformInfo(platformId, CL_PLATFORM_VERSION, 256, version, NULL));
    /* query all the devices, set the first one as default*/
    status = clGetDeviceIDs(platformId, CL_DEVICE_TYPE_GPU, 0, NULL, &numDeviceIds);
    if (status == CL_DEVICE_NOT_FOUND) {
      DEBUG("%s %s %s\n", name, vendor, version);
    } else {
      DEBUG("%s %s %s[selected]\n", name, vendor, version);
      break;
    }
  }
  if (numDeviceIds == 0) {
    ERROR("no platform has gpu device\n");
    exit(-1);
  }
  delete[] platformIds;
  cl_device_id *deviceIds = new cl_device_id[numDeviceIds];
  assert(!!deviceIds);
  CHECK(clGetDeviceIDs(platformId, CL_DEVICE_TYPE_GPU, numDeviceIds, deviceIds, NULL));
  DEBUG("%d cl gpu devices found:\n", numDeviceIds);
  for (unsigned i = 0; i < numDeviceIds; i++) {
    device_id = deviceIds[i];
    CHECK(clGetDeviceInfo(deviceIds[i], CL_DEVICE_NAME, 256, device_name, NULL));
    CHECK(clGetDeviceInfo(deviceIds[i], CL_DEVICE_VERSION, 256, device_version, NULL));
    DEBUG("%s %s[selected]\n", device_name, device_version);
    break;
  }
  delete[] deviceIds;
  // create the context and command queue
  cl_context_properties cps[3] = {
    CL_CONTEXT_PLATFORM, ( cl_context_properties )( platformId ), 0
  };
  context = clCreateContext(cps, 1, &device_id, NULL, NULL, &status);
  CHECK(status);
#ifdef __PROFILING__
  master_queue = clCreateCommandQueue(context, device_id, CL_QUEUE_PROFILING_ENABLE, &status);
  worker_queue = clCreateCommandQueue(context, device_id, CL_QUEUE_PROFILING_ENABLE, &status);
#else
  master_queue = clCreateCommandQueue(context, device_id, 0, &status);
  worker_queue = clCreateCommandQueue(context, device_id, 0, &status);
#endif
  DEBUG("cl context created.\n");
}

DEPTH_DETCTION_CTX::~DEPTH_DETCTION_CTX() {
  release_worker_threads();
  release_buffers();
  release_kernels();
  /* release cl environment */
  if (master_queue) {
    CHECK(clReleaseCommandQueue(master_queue));
    master_queue = NULL;
  }
  if (worker_queue) {
    CHECK(clReleaseCommandQueue(worker_queue));
    worker_queue = NULL;
  }
  if (context) {
    CHECK(clReleaseContext(context));
    context = NULL;
  }
  DEBUG("cl context released.\n");
}

struct WORKER_THREAD_CTX {
public:
  int idx;
#ifdef _WIN32
  HANDLE tid;
  HANDLE work;
  HANDLE done;
#else
  pthread_t tid;
  sem_t work;
  sem_t done;
#endif
  unsigned char *src;
  unsigned char *dst;
  bool force_stopping;
  DEPTH_DETCTION_CTX *parent;
};

#ifdef _WIN32
DWORD WINAPI WORKER_THREAD_RUNNER(PVOID param) {
#else
void* WORKER_THREAD_RUNNER(void* param) {
#endif
  WORKER_THREAD_CTX *ctx = (WORKER_THREAD_CTX *)param;
  ctx->parent->worker_thread_callback(ctx->idx, ctx->parent->worker_thread_num);
  int size = 0;
  unsigned char *row = NULL;
  while (1){
#ifdef _WIN32
    WaitForSingleObject(ctx->work, INFINITE);
#else
    sem_wait(&(ctx->work));
#endif
    if (ctx->force_stopping) {
      break;
    }
    int new_size = ctx->parent->width * ctx->parent->param.num_disp;
    if (new_size > size) {
      if (row) {
        delete row;
      }
      row = new unsigned char[new_size];
      assert(row);
      size = new_size;
    }
    scanline_optimization(
      ctx->src,
      ctx->dst,
      row,
      ctx->parent->width,
      ctx->parent->height,
      ctx->parent->param.num_disp,
      ctx->parent->param.scanline_optimization_penalty1,
      ctx->parent->param.scanline_optimization_penalty2,
      ctx->idx * ctx->parent->height / ctx->parent->worker_thread_num,
      (ctx->idx + 1) * ctx->parent->height / ctx->parent->worker_thread_num
      );
#ifdef _WIN32
    ReleaseSemaphore(ctx->done, 1, NULL);
#else
    sem_post(&(ctx->done));
#endif
  }
  if (row) {
    delete row;
  }
  return 0;
}

int DEPTH_DETCTION_CTX::create_worker_threads() {
  worker_thread_ctx = new WORKER_THREAD_CTX[worker_thread_num];
  if (!worker_thread_ctx) {
    ERROR("no space to alloc worker thread context.\n");
    return -1;
  }
  for (int i = 0; i < worker_thread_num; i++) {
    memset(&worker_thread_ctx[i], 0, sizeof(WORKER_THREAD_CTX));
    worker_thread_ctx[i].idx = i;
    worker_thread_ctx[i].force_stopping = false;
    worker_thread_ctx[i].parent = this;
#ifdef _WIN32
    worker_thread_ctx[i].work = CreateSemaphore(NULL, 0, 1, NULL); 
    worker_thread_ctx[i].done = CreateSemaphore(NULL, 0, 1, NULL); 
    worker_thread_ctx[i].tid = (HANDLE)CreateThread(NULL, 0, &WORKER_THREAD_RUNNER, (PVOID)&(worker_thread_ctx[i]), 0, NULL);
#else
    sem_init(&worker_thread_ctx[i].work, 0, 0);
    sem_init(&worker_thread_ctx[i].done, 0, 0);
    pthread_create(&worker_thread_ctx[i].tid, NULL, &WORKER_THREAD_RUNNER, (void *)&(worker_thread_ctx[i]));
#endif
  }
  DEBUG("worker threads created\n");
  return 0;
}

void DEPTH_DETCTION_CTX::release_worker_threads() {
  if (worker_thread_ctx) {
    for (int i = 0; i < worker_thread_num; i++) {
      worker_thread_ctx[i].force_stopping = true;
#ifdef _WIN32
      ReleaseSemaphore(worker_thread_ctx[i].work, 1, NULL);
      WaitForSingleObject(worker_thread_ctx[i].tid, INFINITE); 
#else
      sem_post(&worker_thread_ctx[i].work);
      pthread_join(worker_thread_ctx[i].tid, NULL);
#endif
    }
  }
  delete worker_thread_ctx;
  worker_thread_ctx = NULL;
  DEBUG("worker threads released\n");
}

int DEPTH_DETCTION_CTX::create_buffers() {
  cl_int status = CL_SUCCESS;
  /* create opencl temporary buffers */
  for (int i = 0; i < 3; i++) {
    // 9x9 census transform need 4 bytes for each pixel, use size = width * height 
    // * sizeof(unsigned char) * (param.max_disp - param.min_disp + 1), because it is far 
    // greater than width * height * sizeof(unsigned char) * 4 * 2
    T[i] = clCreateBuffer(context,
      CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR,
      width * height * sizeof(unsigned char) * (param.num_disp < 8 ? 8 : param.num_disp),
      NULL,
      &status);
    CHECK(status);
  }
  /* create opencl input/output buffers */
  if (param.rect_width > 0 && param.rect_height > 0) {
    // create images if need to do rectification
    cl_image_format img_fmt;
    img_fmt.image_channel_data_type = CL_UNORM_INT8;
    img_fmt.image_channel_order = CL_R;
    cl_image_desc img_desc;
    memset(&img_desc, 0, sizeof(img_desc));
    img_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
    img_desc.image_width = param.src_width;
    img_desc.image_height = param.src_height * 2;
    img_desc.image_row_pitch = 0;
    src_image = clCreateImage(context, CL_MEM_READ_ONLY, &img_fmt, &img_desc, NULL, &status);
    CHECK(status);
    // prepare mesh grid data for left/right image rectification
    int rect_data_size = param.rect_width * param.rect_height * 4; // coordiate(component x and y) of each pixel of left&right image
#ifdef __ANDROID__
    int rect_data_length = rect_data_size * sizeof(unsigned short); // ARM Mali GPU supports half type
#else
    int rect_data_length = rect_data_size * sizeof(float); // otherwise, float type is used instead
#endif
    rect_data = clCreateBuffer(context,
        CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR,
        rect_data_length,
        NULL,
        &status);
    CHECK(status);
    void *rect_data_ptr = clEnqueueMapBuffer(master_queue,
        rect_data,
        CL_TRUE,
        CL_MAP_WRITE,
        0,
        rect_data_length,
        0,
        NULL,
        NULL,
        &status);
      CHECK(status);
    FILE *fp = fopen(param.rect_data_file_path, "rb");
    assert(fp);
#ifdef __ANDROID__
    fread(rect_data_ptr, 1, rect_data_length, fp);
#else
    // AMD graphic card doesn't support half type, so need to convert to float type.
    unsigned short *rect_raw_data = new unsigned short[rect_data_size];
    fread(rect_raw_data, sizeof(unsigned short), rect_data_size, fp);
    for (int j = 0; j < rect_data_size; j++) {
      ((float *)rect_data_ptr)[j] = half2float(rect_raw_data[j]);
    }
    delete rect_raw_data;
#endif
    fclose(fp);
    CHECK(clEnqueueUnmapMemObject(master_queue,
        rect_data,
        rect_data_ptr,
        0,
        NULL,
        NULL));
    clFinish(master_queue);
  }
  rect_image = clCreateBuffer(context,
    CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR,
    width * height * sizeof(unsigned char) * 4,
    NULL,
    &status);
  CHECK(status);
  DEBUG("cl buffers created.\n");
  return 0;
}

void DEPTH_DETCTION_CTX::release_buffers() {
  for (int i = 0; i < 3; i++) {
    if (T[i]) {
      CHECK(::clReleaseMemObject(T[i]));
      T[i] = NULL;
    }
  }
  if (src_image) {
    CHECK(::clReleaseMemObject(src_image));
    src_image = NULL;
  }
  if (rect_data) {
    CHECK(::clReleaseMemObject(rect_data));
    rect_data = NULL;
  }
  if (rect_image) {
    CHECK(::clReleaseMemObject(rect_image));
    rect_image = NULL;
  }
  DEBUG("cl buffers released.\n");
}

int DEPTH_DETCTION_CTX::create_kernels() {
  cl_int status = CL_SUCCESS;
  FILE *fp = fopen(kernel_file_path, "rb");
  if (!fp) {
    ERROR("kernel file %s open failed.\n", kernel_file_path);
    exit(-1);
  }
  assert(fp);
  fseek(fp, 0L, SEEK_END);
  size_t length = ftell(fp);
  fseek(fp, 0, SEEK_SET);
  char* code = new char[length + 1];
  assert(code);
  fread(code, 1, length, fp);
  fclose(fp);
  code[length] = '\0';
  cl_program program;
  if (kernel_is_source) {
    program = clCreateProgramWithSource(context, 1, (const char **)&code, NULL, &status);
  } else {
    program = clCreateProgramWithBinary(context, 1, &device_id, &length, (const unsigned char **)&code, NULL, &status);
  }
  delete code;
  char options[2048];
  char s[1024];
  options[0] = '\0';
  sprintf(s, "-cl-fast-relaxed-math -cl-mad-enable -cl-single-precision-constant");
  strcat(options, s);
#ifdef __ANDROID__ // Mali GPU support cl_khr_fp16 extension
  strcat(options, " -D__ANDROID__");
#endif
  sprintf(s, " -DMIN_DISP=%d -DNUM_DISP=%d -DSUBPIXEL_SHIFTBITS=%d -DWIDTH=%d -DHEIGHT=%d", 
         param.min_disp,
         param.num_disp,
         param.subpixel_shiftbits,
         width,
         height
  );
  strcat(options, s);
  status = clBuildProgram(program, 0, NULL, options, NULL, NULL);
  if (status != CL_SUCCESS) {
    if (status == CL_BUILD_PROGRAM_FAILURE) {
      cl_int logStatus;
      char *buildLog = NULL;
      size_t buildLogSize = 0;
      logStatus = clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, buildLogSize,
        buildLog, &buildLogSize);
      if (logStatus != CL_SUCCESS) {
        ERROR("failed to build the program and get the build info.\n");
      }
      buildLog = new char[buildLogSize];
      assert(!!buildLog);
      memset(buildLog, 0, buildLogSize);
      CHECK(clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, buildLogSize, buildLog, NULL));
      ERROR("\n---------------BUILD LOG--------------\n%s\n", buildLog);
      delete buildLog;
      exit(-1);
    } else {
      CHECK(status);
    }
  }
  /* create cl kernels */
  kernel_epipolar_rectification = clCreateKernel(program, "epipolar_rectification", &status);
  CHECK(status);
  kernel_mean_filter_3x3_except_borders = clCreateKernel(program, "mean_filter_3x3_except_borders", &status);
  CHECK(status);
  kernel_mean_filter_3x3_for_borders = clCreateKernel(program, "mean_filter_3x3_for_borders", &status);
  CHECK(status);
  kernel_sct_9x9_except_borders = clCreateKernel(program, "sct_9x9_except_borders", &status);
  CHECK(status);
  kernel_sct_9x9_for_borders = clCreateKernel(program, "sct_9x9_for_borders", &status);
  CHECK(status);
  kernel_sct_9x9_block_matching = clCreateKernel(program, "sct_9x9_block_matching", &status);
  CHECK(status);
  kernel_cost_aggregation_x = clCreateKernel(program, "cost_aggregation_x", &status);
  CHECK(status);
  kernel_cost_aggregation_y = clCreateKernel(program, "cost_aggregation_y", &status);
  CHECK(status);
  kernel_scanline_optimization = clCreateKernel(program, "scanline_optimization", &status);
  CHECK(status);
  kernel_winner_takes_all = clCreateKernel(program, "winner_takes_all", &status);
  CHECK(status);
  kernel_left_right_consistency_check = clCreateKernel(program, "left_right_consistency_check", &status);
  CHECK(status);
  kernel_sct_9x9_textureless_filter_except_borders = clCreateKernel(program, "sct_9x9_textureless_filter_except_borders", &status);
  CHECK(status);
  kernel_sct_9x9_textureless_filter_for_borders = clCreateKernel(program, "sct_9x9_textureless_filter_for_borders", &status);
  CHECK(status);
  sprintf(s, "median_filter_%dx1_except_borders", MEDIAN_FILTER_WIN_SIZE[param.median_filter_win_size]);
  kernel_median_filter_x_except_borders = clCreateKernel(program, s, &status);
  CHECK(status);
  sprintf(s, "median_filter_%dx1_for_borders", MEDIAN_FILTER_WIN_SIZE[param.median_filter_win_size]);
  kernel_median_filter_x_for_borders = clCreateKernel(program, s, &status);
  CHECK(status);
  sprintf(s, "median_filter_1x%d", MEDIAN_FILTER_WIN_SIZE[param.median_filter_win_size]);
  kernel_median_filter_y = clCreateKernel(program, s, &status);
  CHECK(status);
  kernel_disp2depth = clCreateKernel(program, "disp2depth", &status);
  CHECK(status);
  if (program) {
    CHECK(clReleaseProgram(program));
    program = NULL;
  }
  DEBUG("cl kernels created.\n");
  return 0;
}

void DEPTH_DETCTION_CTX::release_kernels() {
  /* release cl kernels & program */
  if (kernel_epipolar_rectification) {
    CHECK(clReleaseKernel(kernel_epipolar_rectification));
    kernel_epipolar_rectification = NULL;
  }
  if (kernel_mean_filter_3x3_except_borders) {
    CHECK(clReleaseKernel(kernel_mean_filter_3x3_except_borders));
    kernel_mean_filter_3x3_except_borders = NULL;
  }
  if (kernel_mean_filter_3x3_for_borders) {
    CHECK(clReleaseKernel(kernel_mean_filter_3x3_for_borders));
    kernel_mean_filter_3x3_for_borders = NULL;
  }
  if (kernel_sct_9x9_except_borders) {
    CHECK(clReleaseKernel(kernel_sct_9x9_except_borders));
    kernel_sct_9x9_except_borders = NULL;
  }
  if (kernel_sct_9x9_for_borders) {
    CHECK(clReleaseKernel(kernel_sct_9x9_for_borders));
    kernel_sct_9x9_for_borders = NULL;
  }
  if (kernel_sct_9x9_block_matching) {
    CHECK(clReleaseKernel(kernel_sct_9x9_block_matching));
    kernel_sct_9x9_block_matching = NULL;
  }
  if (kernel_cost_aggregation_x) {
    CHECK(clReleaseKernel(kernel_cost_aggregation_x));
    kernel_cost_aggregation_x = NULL;
  }
  if (kernel_cost_aggregation_y) {
    CHECK(clReleaseKernel(kernel_cost_aggregation_y));
    kernel_cost_aggregation_y = NULL;
  }
  if (kernel_scanline_optimization) {
    CHECK(clReleaseKernel(kernel_scanline_optimization));
    kernel_scanline_optimization = NULL;
  }
  if (kernel_winner_takes_all) {
    CHECK(clReleaseKernel(kernel_winner_takes_all));
    kernel_winner_takes_all = NULL;
  }
  if (kernel_left_right_consistency_check) {
    CHECK(clReleaseKernel(kernel_left_right_consistency_check));
    kernel_left_right_consistency_check = NULL;
  }
  if (kernel_sct_9x9_textureless_filter_except_borders) {
    CHECK(clReleaseKernel(kernel_sct_9x9_textureless_filter_except_borders));
    kernel_sct_9x9_textureless_filter_except_borders = NULL;
  }
  if (kernel_sct_9x9_textureless_filter_for_borders) {
    CHECK(clReleaseKernel(kernel_sct_9x9_textureless_filter_for_borders));
    kernel_sct_9x9_textureless_filter_for_borders = NULL;
  }
  if (kernel_median_filter_x_except_borders) {
    CHECK(clReleaseKernel(kernel_median_filter_x_except_borders));
    kernel_median_filter_x_except_borders = NULL;
  }
  if (kernel_median_filter_x_for_borders) {
    CHECK(clReleaseKernel(kernel_median_filter_x_for_borders));
    kernel_median_filter_x_for_borders = NULL;
  }
  if (kernel_median_filter_y) {
    CHECK(clReleaseKernel(kernel_median_filter_y));
    kernel_median_filter_y = NULL;
  }
  if (kernel_disp2depth) {
    CHECK(clReleaseKernel(kernel_disp2depth));
    kernel_disp2depth = NULL;
  }
  DEBUG("cl kernels released.\n");
}

int DEPTH_DETCTION_CTX::process(
  unsigned char **src_image_addr,
  unsigned char **rect_image_addr,
  unsigned short *disp_addr,
  unsigned short *depth_addr,
  float *scan_addr
  ) {
  int i;
  cl_int status = CL_SUCCESS;
  size_t global_threads[3];
  size_t local_threads[3];
  global_threads[2] = 2;
#ifdef DUMP
  unsigned char *dump_image_addr = new unsigned char[width * height * 2];
  assert(dump_image_addr);
#endif
  if (param.rect_width > 0 && param.rect_height > 0) {
    /* do epipolar rectification for left&right images */
    size_t origin[3] = { 0, 0, 0 };
    size_t region[3] = { param.src_width, param.src_height, 1 };
    CHECK(clEnqueueWriteImage(master_queue,
        src_image,
        CL_FALSE,
        origin,
        region,
        0,
        0,
        src_image_addr[0],
        0,
        NULL,
        NULL));
    origin[1] = param.src_height;
    CHECK(clEnqueueWriteImage(master_queue,
        src_image,
        CL_TRUE,
        origin,
        region,
        0,
        0,
        src_image_addr[1],
        0,
        NULL,
        NULL));
    global_threads[0] = param.rect_width / 8;
    global_threads[1] = param.rect_height;
    CHECK(clSetKernelArg(kernel_epipolar_rectification, 0, sizeof(cl_mem), &src_image));
    CHECK(clSetKernelArg(kernel_epipolar_rectification, 1, sizeof(cl_mem), &rect_data));
    CHECK(clSetKernelArg(kernel_epipolar_rectification, 2, sizeof(cl_mem), &rect_image));
    RUN("epipolar_rectification", master_queue, kernel_epipolar_rectification, 3, NULL, global_threads, NULL, 0, NULL, NULL);
#ifdef DUMP
    CHECK(clEnqueueReadBuffer(master_queue,
      rect_image,
      CL_TRUE,
      0,
      width * height * 2 * sizeof(unsigned char),
      dump_image_addr,
      0,
      NULL,
      NULL));
#ifdef __ANDROID__
    if (write_gray_to_bitmap("/data/local/tmp/rect.bmp", dump_image_addr, width, height * 2)) {
#else
    if (write_gray_to_bitmap("rect.bmp", dump_image_addr, width, height * 2)) {
#endif
      exit(-1);
    }
#endif
    if (rect_image_addr[0]) {
      CHECK(clEnqueueReadBuffer(master_queue,
        rect_image,
        CL_FALSE,
        0,
        width * height * sizeof(unsigned char),
        rect_image_addr[0],
        0,
        NULL,
        NULL));
    }
    if (rect_image_addr[1]) {
      CHECK(clEnqueueReadBuffer(master_queue,
        rect_image,
        CL_FALSE,
        width * height * sizeof(unsigned char),
        width * height * sizeof(unsigned char),
        rect_image_addr[1],
        0,
        NULL,
        NULL));
    }
  } else {
    /* copy left&right images to the buffer directly if unnessary to do epiolar rectification */
    CHECK(clEnqueueWriteBuffer(master_queue,
        rect_image,
        CL_FALSE,
        0,
        param.src_width * param.src_height * sizeof(unsigned char),
        src_image_addr[0],
        0,
        NULL,
        NULL));
    CHECK(clEnqueueWriteBuffer(master_queue,
        rect_image,
        CL_FALSE,
        param.src_width * param.src_height * sizeof(unsigned char),
        param.src_width * param.src_height * sizeof(unsigned char),
        src_image_addr[1],
        0,
        NULL,
        NULL));
    clFlush(master_queue);
  }
  int enable_mean_filter = !(param.block_matching_methold & 0x1);
  if (enable_mean_filter) {
    /* mean filter 3x3 to improve robustness against variations of brightness and high frequency noise */
    global_threads[0] = width / 16 - 2;
    global_threads[1] = height;
    CHECK(clSetKernelArg(kernel_mean_filter_3x3_except_borders, 0, sizeof(cl_mem), &rect_image));
    RUN("mean_filter_3x3_except_borders", master_queue, kernel_mean_filter_3x3_except_borders, 3, NULL, global_threads, NULL, 0, NULL, NULL);
    global_threads[0] = 1;
    CHECK(clSetKernelArg(kernel_mean_filter_3x3_for_borders, 0, sizeof(cl_mem), &rect_image));
    RUN("mean_filter_3x3_for_borders", master_queue, kernel_mean_filter_3x3_for_borders, 3, NULL, global_threads, NULL, 0, NULL, NULL);
#ifdef DUMP
    CHECK(clEnqueueReadBuffer(master_queue,
      rect_image,
      CL_TRUE,
      width * height * 2 * sizeof(unsigned char),
      width * height * 2 * sizeof(unsigned char),
      dump_image_addr,
      0,
      NULL,
      NULL));
#ifdef __ANDROID__
    if (write_gray_to_bitmap("/data/local/tmp/mean.bmp", dump_image_addr, width, height * 2)) {
#else
    if (write_gray_to_bitmap("mean_3x3.bmp", dump_image_addr, width, height * 2)) {
#endif
      exit(-1);
    }
#endif
  }
  /* 9x9 sparse modified census transform(smct) or 9x9 sparse census transform(sct) */
  global_threads[0] = width / 16 - 2;
  global_threads[1] = height;
  CHECK(clSetKernelArg(kernel_sct_9x9_except_borders, 0, sizeof(cl_mem), &rect_image));
  CHECK(clSetKernelArg(kernel_sct_9x9_except_borders, 1, sizeof(cl_mem), &T[1]));
  CHECK(clSetKernelArg(kernel_sct_9x9_except_borders, 2, sizeof(cl_int), &enable_mean_filter));
  RUN("sct_9x9_except_borders", master_queue, kernel_sct_9x9_except_borders, 3, NULL, global_threads, NULL, 0, NULL, NULL);
  global_threads[0] = 1;
  CHECK(clSetKernelArg(kernel_sct_9x9_for_borders, 0, sizeof(cl_mem), &rect_image));
  CHECK(clSetKernelArg(kernel_sct_9x9_for_borders, 1, sizeof(cl_mem), &T[1]));
  CHECK(clSetKernelArg(kernel_sct_9x9_for_borders, 2, sizeof(cl_int), &enable_mean_filter));
  RUN("sct_9x9_for_borders", master_queue, kernel_sct_9x9_for_borders, 3, NULL, global_threads, NULL, 0, NULL, NULL);
#ifdef DUMP
  CHECK(clEnqueueReadBuffer(master_queue,
    T[1],
    CL_TRUE,
    0,
    width * height * 2 * sizeof(unsigned char),
    dump_image_addr,
    0,
    NULL,
    NULL));
#ifdef __ANDROID__
  if (write_gray_to_bitmap("/data/local/tmp/sct_9x9.bmp", dump_image_addr, width, height * 2)) {
#else
  if (write_gray_to_bitmap("sct_9x9.bmp", dump_image_addr, width, height * 2)) {
#endif
    exit(-1);
  }
#endif
  /* block matching to initialize cost */
  global_threads[0] = width;
  CHECK(clSetKernelArg(kernel_sct_9x9_block_matching, 0, sizeof(cl_mem), &T[1]));
  CHECK(clSetKernelArg(kernel_sct_9x9_block_matching, 1, sizeof(cl_mem), &T[0]));
  RUN("stereo_matching", master_queue, kernel_sct_9x9_block_matching, 2, NULL, global_threads, NULL, 0, NULL, NULL);
  if (param.cost_aggreation_win_size > 0) {
    /* cost aggregation on horizontal&vertical directions seperately */
    CHECK(clSetKernelArg(kernel_cost_aggregation_x, 0, sizeof(cl_mem), &T[0]));
    CHECK(clSetKernelArg(kernel_cost_aggregation_x, 1, sizeof(cl_mem), &T[1]));
    CHECK(clSetKernelArg(kernel_cost_aggregation_x, 2, sizeof(cl_uchar), &param.cost_aggreation_win_size));
    RUN("cost_aggregation_x", master_queue, kernel_cost_aggregation_x, 2, NULL, global_threads, NULL, 0, NULL, NULL);
    CHECK(clSetKernelArg(kernel_cost_aggregation_y, 0, sizeof(cl_mem), &T[1]));
    CHECK(clSetKernelArg(kernel_cost_aggregation_y, 1, sizeof(cl_mem), &T[0]));
    CHECK(clSetKernelArg(kernel_cost_aggregation_y, 2, sizeof(cl_uchar), &param.cost_aggreation_win_size));
    RUN("cost_aggregation_y", master_queue, kernel_cost_aggregation_y, 2, NULL, global_threads, NULL, 0, NULL, NULL);
  }
  clFinish(master_queue); // T[0] should be valid before mapping it to CPU
  /* run scanline optimization at vertical direction on GPU */
  CHECK(clSetKernelArg(kernel_scanline_optimization, 0, sizeof(cl_mem), &T[0]));
  CHECK(clSetKernelArg(kernel_scanline_optimization, 1, sizeof(cl_mem), &T[1]));
  CHECK(clSetKernelArg(kernel_scanline_optimization, 2, sizeof(cl_uchar), &param.scanline_optimization_penalty1));
  CHECK(clSetKernelArg(kernel_scanline_optimization, 3, sizeof(cl_uchar), &param.scanline_optimization_penalty2));
  RUN("scanline_optimization", master_queue, kernel_scanline_optimization, 1, NULL, global_threads, NULL, 0, NULL, NULL);
  /* meanwhile, run scanline optimization at horizontal direction on CPU */
  // uint64_t now = get_timestamp();
  void *src_cost = clEnqueueMapBuffer(worker_queue,
    T[0],
    CL_FALSE,
    CL_MAP_READ,
    0,
    width * height * sizeof(unsigned char) * param.num_disp,
    0,
    NULL,
    NULL,
    &status);
  CHECK(status);
  void *dst_cost = clEnqueueMapBuffer(worker_queue,
    T[2],
    CL_TRUE,
    CL_MAP_WRITE,
    0,
    width * height * sizeof(unsigned char) * param.num_disp,
    0,
    NULL,
    NULL,
    &status);
  CHECK(status);
  /*
  double duration = get_duration(now) * 1000.0f;
  DEBUG("map: %.2f ms\n", duration);
  now = get_timestamp();
  */
  for (i = 0; i < worker_thread_num; i++) {
    worker_thread_ctx[i].src = (uint8_t*)src_cost;
    worker_thread_ctx[i].dst = (uint8_t*)dst_cost;
#ifdef _WIN32
    ReleaseSemaphore(worker_thread_ctx[i].work, 1, NULL); 
#else
    sem_post(&(worker_thread_ctx[i].work));
#endif
  }
  for (i = 0; i < worker_thread_num; i++) {
#ifdef _WIN32
    WaitForSingleObject(worker_thread_ctx[i].done, INFINITE);
#else
    sem_wait(&(worker_thread_ctx[i].done));
#endif
  }
  /*
  duration = get_duration(now) * 1000.0f;
  DEBUG("process: %.2f ms\n", duration);
  now = get_timestamp();
  */
  CHECK(clEnqueueUnmapMemObject(worker_queue,
    T[2],
    dst_cost,
    0,
    NULL,
    NULL));
  CHECK(clEnqueueUnmapMemObject(worker_queue,
    T[0],
    src_cost,
    0,
    NULL,
    NULL));
  /*
  duration = get_duration(now) * 1000.0f;
  DEBUG("unmap: %.2f ms\n", duration);
  */
  /* use "winner takes all" strategy to obtain left&right disparity */
  global_threads[0] = width * height;
  CHECK(clSetKernelArg(kernel_winner_takes_all, 0, sizeof(cl_mem), &T[1]));
  CHECK(clSetKernelArg(kernel_winner_takes_all, 1, sizeof(cl_mem), &T[2]));
  CHECK(clSetKernelArg(kernel_winner_takes_all, 2, sizeof(cl_mem), &T[0]));
  RUN("winner_takes_all", master_queue, kernel_winner_takes_all, 1, NULL, global_threads, NULL, 0, NULL, NULL);
  /* do left-right consistency checking to remove occluded and miss-matched pixels */
  global_threads[0] = height;
  CHECK(clSetKernelArg(kernel_left_right_consistency_check, 0, sizeof(cl_mem), &T[0]));
  CHECK(clSetKernelArg(kernel_left_right_consistency_check, 1, sizeof(cl_mem), &T[1]));
  int lrc_tolerance_with_subpixel = ((int)param.left_right_consistency_check_tolerance) * (1L << param.subpixel_shiftbits);
  int min_valid_disp = ((int)param.min_valid_disp) * (1L << param.subpixel_shiftbits);
  int max_valid_disp = ((int)(param.min_valid_disp + param.num_valid_disp)) * (1L << param.subpixel_shiftbits);
  CHECK(clSetKernelArg(kernel_left_right_consistency_check, 2, sizeof(cl_int), &min_valid_disp));
  CHECK(clSetKernelArg(kernel_left_right_consistency_check, 3, sizeof(cl_int), &max_valid_disp));
  CHECK(clSetKernelArg(kernel_left_right_consistency_check, 4, sizeof(cl_int), &lrc_tolerance_with_subpixel));
  RUN("left_right_consistency_check", master_queue, kernel_left_right_consistency_check, 1, NULL, global_threads, NULL, 0, NULL, NULL);
#ifdef DUMP
  CHECK(clEnqueueReadBuffer(master_queue,
    T[1],
    CL_TRUE,
    0,
    width * height * sizeof(unsigned short),
    dump_image_addr,
    0,
    NULL,
    NULL));
  for (i = 0; i < width * height; i++) {
    dump_image_addr[i] = ((unsigned short *)dump_image_addr)[i] >> param.subpixel_shiftbits;
  }
#ifdef __ANDROID__
  if (write_gray_to_bitmap("/data/local/tmp/lrc_check.bmp", dump_image_addr, width, height)) {
#else
  if (write_gray_to_bitmap("lrc_check.bmp", dump_image_addr, width, height)) {
#endif
    exit(-1);
  }
#endif
  if (param.textureless_filter_threshold > 0) {
    /* apply 9x9 textureless filter(similar as 9x9 sparse modified census transform) to remove textureless(low confidence) regions if needed */
    global_threads[0] = width / 16 - 2;
    CHECK(clSetKernelArg(kernel_sct_9x9_textureless_filter_except_borders, 0, sizeof(cl_mem), &rect_image));
    CHECK(clSetKernelArg(kernel_sct_9x9_textureless_filter_except_borders, 1, sizeof(cl_mem), &T[1]));
    CHECK(clSetKernelArg(kernel_sct_9x9_textureless_filter_except_borders, 2, sizeof(cl_uchar), &param.textureless_filter_threshold));
    CHECK(clSetKernelArg(kernel_sct_9x9_textureless_filter_except_borders, 3, sizeof(cl_int), &enable_mean_filter));
    RUN("sct_9x9_textureless_filter_except_borders", master_queue, kernel_sct_9x9_textureless_filter_except_borders, 2, NULL, global_threads, NULL, 0, NULL, NULL);
    global_threads[0] = 1;
    CHECK(clSetKernelArg(kernel_sct_9x9_textureless_filter_for_borders, 0, sizeof(cl_mem), &rect_image));
    CHECK(clSetKernelArg(kernel_sct_9x9_textureless_filter_for_borders, 1, sizeof(cl_mem), &T[1]));
    CHECK(clSetKernelArg(kernel_sct_9x9_textureless_filter_for_borders, 2, sizeof(cl_uchar), &param.textureless_filter_threshold));
    CHECK(clSetKernelArg(kernel_sct_9x9_textureless_filter_for_borders, 3, sizeof(cl_int), &enable_mean_filter));
    RUN("sct_9x9_textureless_filter_for_borders", master_queue, kernel_sct_9x9_textureless_filter_for_borders, 2, NULL, global_threads, NULL, 0, NULL, NULL);
#ifdef DUMP
    CHECK(clEnqueueReadBuffer(master_queue,
      T[1],
      CL_TRUE,
      0,
      width * height * sizeof(unsigned short),
      dump_image_addr,
      0,
      NULL,
      NULL));
     for (i = 0; i < width * height; i++) {
      dump_image_addr[i] = ((unsigned short *)dump_image_addr)[i] >> param.subpixel_shiftbits;
    }
#ifdef __ANDROID__
    if (write_gray_to_bitmap("/data/local/tmp/sct_9x9_textureless.bmp", dump_image_addr, width, height)) {
#else
    if (write_gray_to_bitmap("sct_9x9_textureless.bmp", dump_image_addr, width, height)) {
#endif
      exit(-1);
    }
#endif
  }
  /* apply median filter to reduce outlier or noise */
  global_threads[0] = width / 8 - 2;
  CHECK(clSetKernelArg(kernel_median_filter_x_except_borders, 0, sizeof(cl_mem), &T[1]));
  CHECK(clSetKernelArg(kernel_median_filter_x_except_borders, 1, sizeof(cl_mem), &T[0]));
  RUN("median_filter_x_except_borders", master_queue, kernel_median_filter_x_except_borders, 2, NULL, global_threads, NULL, 0, NULL, NULL);
  global_threads[0] = 1;
  CHECK(clSetKernelArg(kernel_median_filter_x_for_borders, 0, sizeof(cl_mem), &T[1]));
  CHECK(clSetKernelArg(kernel_median_filter_x_for_borders, 1, sizeof(cl_mem), &T[0]));
  RUN("median_filter_x_for_borders", master_queue, kernel_median_filter_x_for_borders, 2, NULL, global_threads, NULL, 0, NULL, NULL);
  global_threads[0] = width / 8;
  CHECK(clSetKernelArg(kernel_median_filter_y, 0, sizeof(cl_mem), &T[0]));
  CHECK(clSetKernelArg(kernel_median_filter_y, 1, sizeof(cl_mem), &T[1]));
  RUN("median_filter_y", master_queue, kernel_median_filter_y, 2, NULL, global_threads, NULL, 0, NULL, NULL);
#ifdef DUMP
  CHECK(clEnqueueReadBuffer(master_queue,
    T[1],
    CL_TRUE,
    0,
    width * height * sizeof(unsigned short),
    dump_image_addr,
    0,
    NULL,
    NULL));
  for (i = 0; i < width * height; i++) {
    dump_image_addr[i] = ((unsigned short *)dump_image_addr)[i] >> param.subpixel_shiftbits;
  }
#ifdef __ANDROID__
  if (write_gray_to_bitmap("/data/local/tmp/median.bmp", dump_image_addr, width, height)) {
#else
  if (write_gray_to_bitmap("median.bmp", dump_image_addr, width, height)) {
#endif
    exit(-1);
  }
#endif
  if (disp_addr) {
    CHECK(clEnqueueReadBuffer(master_queue,
      T[1],
      CL_FALSE,
      0,
      width * height * sizeof(unsigned short),
      disp_addr,
      0,
      NULL,
      NULL));
  }
  if (depth_addr) {
    /* disp2depth if needed */
    global_threads[0] = width * height / 16;
    CHECK(clSetKernelArg(kernel_disp2depth, 0, sizeof(cl_mem), &T[1]));
    CHECK(clSetKernelArg(kernel_disp2depth, 1, sizeof(cl_mem), &T[0]));
    float rect_focal_length_mul_rect_baseline = param.rect_focal_length * param.rect_baseline;
    float rect_right_cx_sub_rect_left_cx = param.rect_right_cx - param.rect_left_cx;
    CHECK(clSetKernelArg(kernel_disp2depth, 2, sizeof(cl_float), &rect_focal_length_mul_rect_baseline));
    CHECK(clSetKernelArg(kernel_disp2depth, 3, sizeof(cl_float), &rect_right_cx_sub_rect_left_cx));
    RUN("disp2depth", master_queue, kernel_disp2depth, 1, NULL, global_threads, NULL, 0, NULL, NULL);
    clEnqueueReadBuffer(master_queue,
      T[0],
      CL_FALSE,
      0,
      width * height * sizeof(unsigned short),
      depth_addr,
      0,
      NULL,
      NULL);
  }
  if (scan_addr) {
    /* disp2scan if needed */
    //uint64_t now = get_timestamp();
    int scan_offset = (int)(param.rect_cy - param.scan_height / 2);
    unsigned short* scan_disps = new unsigned short[width * param.scan_height];
    assert(scan_disps);
    clEnqueueReadBuffer(master_queue,
      T[1],
      CL_FALSE,
      width * scan_offset * sizeof(unsigned short),
      width * param.scan_height * sizeof(unsigned short),
      scan_disps,
      0,
      NULL,
      NULL);
    clFlush(master_queue);
    unsigned short* scan_indices = new unsigned short[width];
    assert(scan_indices);
    for (int u = 0; u < width; u++) {
      scan_addr[u] = std::numeric_limits<float>::quiet_NaN();
      float theta = -atan2((double)(u - param.rect_right_cx) / param.rect_focal_length, 1.0);
      scan_indices[u] = (int)((theta - param.angle_min) / param.angle_increment);
    }
    clFinish(master_queue);
    for(int v = 0; v < param.scan_height; v++) {
      for (int u = 0; u < width; u++) {
        unsigned short raw_disp = scan_disps[v * width + u];
        float fixed_disp = ((float)raw_disp) / (float)(1 << param.subpixel_shiftbits);
        fixed_disp += param.rect_right_cx - param.rect_left_cx;
        float new_dist = param.rect_baseline * param.rect_focal_length / fixed_disp;
        int idx = scan_indices[u];
        if (raw_disp != 0) {
          float x = (u - param.rect_right_cx) * new_dist / param.rect_focal_length;
          // calculate actual distance
          new_dist = sqrt(x * x + new_dist * new_dist);
        }
        float old_dist = scan_addr[idx];
        // check for NaNs and Infs, a real number within our limits is more desirable than these.
        bool new_finite = isfinite(new_dist);
        bool old_finite = isfinite(old_dist);
        bool is_replace = !new_finite && !old_finite && !isnan(new_dist);
        is_replace |= new_dist >= param.range_min && new_dist <= param.range_max && (!old_finite || (new_dist < old_dist));
        if (is_replace) {
          scan_addr[idx] = new_dist;
        }
      }
    }
    delete scan_disps;
    delete scan_indices;
#ifdef DUMP
    int dump_scan_min_x = -4; // meter
    int dump_scan_max_x = 4; // meter
    int dump_scan_min_y = 0; // meter
    int dump_scan_max_y = 5; // meter
    double dump_scan_res = 0.005; // meter
    int dump_scan_width = (int)((dump_scan_max_x - dump_scan_min_x) / dump_scan_res + 0.5) + 1;
    int dump_scan_height = (int)((dump_scan_max_y - dump_scan_min_y) / dump_scan_res + 0.5) + 1;
    unsigned char *dump_scan_addr = new unsigned char[dump_scan_width * dump_scan_height];
    assert(dump_scan_addr);
    memset(dump_scan_addr, 0, dump_scan_width * dump_scan_height * sizeof(unsigned char));
    for (i = 0; i < width; i++) {
      double dist = scan_addr[i];
      if (!_finite(dist) || _isnan(dist)) {
        continue;
      }
      double theta = i * param.angle_increment + param.angle_min;
      double x = dist * sin(theta);
      double y = dist * cos(theta);
      int dump_scan_x = (int)((x - dump_scan_min_x) / dump_scan_res + 0.5);
      int dump_scan_y = dump_scan_height - 1 - (int)((y - dump_scan_min_y) / dump_scan_res + 0.5);
      if (dump_scan_x >= dump_scan_width || dump_scan_x < 0 || 
          dump_scan_y >= dump_scan_height || dump_scan_y < 0) {
        continue;
      }
      dump_scan_addr[dump_scan_x + dump_scan_y * dump_scan_width] = 255;
    }
#ifdef __ANDROID__
    if (write_gray_to_bitmap("/data/local/tmp/scan.bmp", dump_scan_addr, dump_scan_width, dump_scan_height)) {
#else
    if (write_gray_to_bitmap("scan.bmp", dump_scan_addr, dump_scan_width, dump_scan_height)) {
#endif
      exit(-1);
    }
    delete dump_scan_addr;
#endif
    /*
    double duration = get_duration(now) * 1000.0f;
    DEBUG("disp2scan: %.2f ms\n", duration);
    */
  }
  clFinish(master_queue);
#ifdef DUMP
  delete dump_image_addr;
#endif
  return 0;
}

void *depth_detection_lc_init(
  const char *opencl_kernel_file_path,
  bool opencl_kernel_is_source,
  WORKER_THREAD_CALLBACK worker_thread_callback,
  int worker_thread_num
  ) {
  if (!opencl_kernel_file_path) {
    ERROR("depth_detection_lc_init: opencl_kernel_file_path should not be NULL.\n");
    return NULL;
  }
  if (!worker_thread_callback) {
    ERROR("depth_detection_lc_init: worker_thread_callback should not be NULL.\n");
    return NULL;
  }
  return new DEPTH_DETCTION_CTX(opencl_kernel_file_path, opencl_kernel_is_source, worker_thread_callback, worker_thread_num);
}

int depth_detection_lc_release(void *ctx) {
  if (ctx == NULL) {
    ERROR("depth_detection_lc_set_params: context should not be NULL.\n");
    return -1;
  }
  delete((DEPTH_DETCTION_CTX *)ctx);
  return 0;
}

int depth_detection_lc_set_params(void *ctx, DEPTH_DETECTION_PARAM param) {
  // check if all of items of algorithm params are valid
  if (ctx == NULL) {
    ERROR("depth_detection_lc_set_params: context should not be NULL.\n");
    return -1;
  }
  if (param.src_width <= 0 || param.src_height <= 0) {
    ERROR("depth_detection_lc_set_params: invalid src_width or src_height.\n");
    return -1;
  }
  if (param.src_width % 16 != 0) {
    ERROR("depth_detection_lc_set_params: src_width should be multiple of %d.\n", 16);
    return -1;
  }
  if ((param.rect_width > 0 && param.rect_height <= 0)
   || (param.rect_width <= 0 && param.rect_height > 0)) {
     ERROR("depth_detection_lc_set_params: invalid rect_width or rect_height.\n");
    return -1;
  }
  if (param.rect_width > 0 && param.rect_width % 16 != 0) {
    ERROR("depth_detection_lc_set_params: rect_width should be multiple of %d.\n", 16);
    return -1;
  }
  if (param.min_disp < 0) {
    ERROR("depth_detection_lc_set_params: min_disp should be [0, 255].\n");
    return -1;
  }
  if (param.num_disp <= 0 || param.num_disp > 256 || param.num_disp % 16 != 0) {
    ERROR("depth_detection_lc_set_params: num_disp should be [0, 256] and multiple of %d.\n", 16);
    return -1;
  }
  int max_disp = param.min_disp + param.num_disp - 1;
  if (max_disp > 255) {
    ERROR("depth_detection_lc_set_params: min_disp + num_disp - 1 should be less than %d.\n", 255);
    return -1;
  }
  int integer_part_bits = ceil(log((float)(max_disp)) / log((float)2));
  if (param.subpixel_shiftbits < 0 || integer_part_bits + param.subpixel_shiftbits > 16) {
    ERROR("depth_detection_lc_set_params: subpixel_shiftbits should be [0, 16 - log2(param.min_disp + param.num_disp - 1) = %d].\n",
      16 - integer_part_bits);
    return -1;
  }
  if (param.min_valid_disp < param.min_disp) {
    param.min_valid_disp = param.min_disp;
    WARNING("depth_detection_lc_set_params: min_valid_disp is changed to %d.\n", param.min_valid_disp);
  }
  int num_valid_disp = max_disp - param.min_valid_disp + 1;
  if (param.num_valid_disp > num_valid_disp || param.num_valid_disp == 0) {
    param.num_valid_disp = num_valid_disp;
    WARNING("depth_detection_lc_set_params: num_valid_disp is changed to %d.\n", param.num_valid_disp);
  }
  if (param.scanline_optimization_penalty1 > param.scanline_optimization_penalty2) {
    ERROR("depth_detection_lc_set_params: scanline_optimization_penalty1 should be less than scanline_optimization_penalty2.\n");
    return -1;
  }
  if (param.left_right_consistency_check_tolerance < 0.0f) {
    ERROR("depth_detection_lc_set_params: left_right_consistency_check_tolerance should be >= 0.0f.\n");
    return -1;
  }
  if (param.median_filter_win_size >= MAX_MEDIAN_FILTER_WIN_SIZE) {
    ERROR("depth_detection_lc_set_params: win size of median filter should be [0, %d]..\n", MAX_MEDIAN_FILTER_WIN_SIZE - 1);
    return -1;
  }
  int width = param.rect_width > 0 ? param.rect_width : param.src_width;
  int height = param.rect_height > 0 ? param.rect_height : param.src_height;
  // calculate disp2scan params
  double left_ray_x = (0 - param.rect_right_cx) / param.rect_focal_length;
  double left_ray_y = 0;
  double left_ray_z = 1.0;
  double right_ray_x = (width - 1 - param.rect_right_cx) / param.rect_focal_length;
  double right_ray_y = 0;
  double right_ray_z = 1.0;
  double center_ray_x = 0;
  double center_ray_y = 0;
  double center_ray_z = 1.0;
  double dot_product = left_ray_x * center_ray_x + left_ray_y * center_ray_y + left_ray_z * center_ray_z;
  double magnitude1 = sqrt(left_ray_x * left_ray_x + left_ray_y * left_ray_y + left_ray_z * left_ray_z);
  double magnitude2 = sqrt(center_ray_x * center_ray_x + center_ray_y * center_ray_y + center_ray_z * center_ray_z);
  param.angle_max = acos(dot_product / (magnitude1 * magnitude2));
  dot_product = center_ray_x * right_ray_x + center_ray_y * right_ray_y + center_ray_z * right_ray_z;
  magnitude1 = sqrt(center_ray_x * center_ray_x + center_ray_y * center_ray_y + center_ray_z * center_ray_z);
  magnitude2 = sqrt(right_ray_x * right_ray_x + right_ray_y * right_ray_y + right_ray_z * right_ray_z);
  param.angle_min = -acos(dot_product / (magnitude1 * magnitude2));
  param.angle_increment = (param.angle_max - param.angle_min) / (width - 1);
  // release buffers/kernels if algorithm params are changed
  bool buffer_changed = false;
  buffer_changed |= param.src_width != ((DEPTH_DETCTION_CTX *)ctx)->param.src_width;
  buffer_changed |= param.src_height != ((DEPTH_DETCTION_CTX *)ctx)->param.src_height;
  buffer_changed |= param.rect_width != ((DEPTH_DETCTION_CTX *)ctx)->param.rect_width;
  buffer_changed |= param.rect_height != ((DEPTH_DETCTION_CTX *)ctx)->param.rect_height;
  buffer_changed |= param.min_disp != ((DEPTH_DETCTION_CTX *)ctx)->param.min_disp;
  buffer_changed |= param.num_disp != ((DEPTH_DETCTION_CTX *)ctx)->param.num_disp;
  buffer_changed |= width != ((DEPTH_DETCTION_CTX *)ctx)->width;
  buffer_changed |= height != ((DEPTH_DETCTION_CTX *)ctx)->height;
  if (buffer_changed) {
    ((DEPTH_DETCTION_CTX *)ctx)->release_buffers();
  }
  bool kernel_changed = false;
  kernel_changed |= param.min_disp != ((DEPTH_DETCTION_CTX *)ctx)->param.min_disp;
  kernel_changed |= param.num_disp != ((DEPTH_DETCTION_CTX *)ctx)->param.num_disp;
  kernel_changed |= param.subpixel_shiftbits != ((DEPTH_DETCTION_CTX *)ctx)->param.subpixel_shiftbits;
  kernel_changed |= width != ((DEPTH_DETCTION_CTX *)ctx)->width;
  kernel_changed |= height != ((DEPTH_DETCTION_CTX *)ctx)->height;
  if (kernel_changed) {
    ((DEPTH_DETCTION_CTX *)ctx)->release_kernels();
  }
  // update algorithm params if needed
  ((DEPTH_DETCTION_CTX *)ctx)->param = param;
  ((DEPTH_DETCTION_CTX *)ctx)->width = width;
  ((DEPTH_DETCTION_CTX *)ctx)->height = height;
  // and realloc buffers if algorithm params are changed
  if (buffer_changed) {
    ((DEPTH_DETCTION_CTX *)ctx)->create_buffers();
  }
  if (kernel_changed) {
    ((DEPTH_DETCTION_CTX *)ctx)->create_kernels();
  }
  return 0;
}

int depth_detection_lc_get_params(void *ctx, DEPTH_DETECTION_PARAM *param) {
  if (ctx == NULL || param == NULL) {
    ERROR("depth_detection_lc_get_params: context or parameter should not be NULL.\n");
    return -1;
  }
  *param = ((DEPTH_DETCTION_CTX *)ctx)->param;
  return 0;
}

int depth_detection_lc_get_disp(
  void *ctx,
  unsigned char *src_image_addr[2],
  unsigned short *disp_addr
  ) {
  if (ctx == NULL || src_image_addr[0] == NULL || src_image_addr[1] == NULL || disp_addr == NULL) {
    ERROR("depth_detection_lc_calc_disp: context or buffer pointers should not be NULL.\n");
    return -1;
  }
  unsigned char* rect_image_addr[2] = { NULL, NULL };
  return ((DEPTH_DETCTION_CTX *)ctx)->process(src_image_addr, rect_image_addr, disp_addr, NULL, NULL);
}

int depth_detection_lc_get_rect_image_and_disp(
  void *ctx,
  unsigned char *src_image_addr[2],
  unsigned char *rect_image_addr[2],
  unsigned short *disp_addr
  ) {
  if (ctx == NULL || src_image_addr[0] == NULL || src_image_addr[1] == NULL
   || rect_image_addr[0] == NULL || rect_image_addr[1] == NULL  || disp_addr == NULL) {
    ERROR("depth_detection_lc_calc_disp_with_rect_image: context or buffer pointers should not be NULL.\n");
    return -1;
  }
  return ((DEPTH_DETCTION_CTX *)ctx)->process(src_image_addr, rect_image_addr, disp_addr, NULL, NULL);
}

int depth_detection_lc_get_depth(
  void *ctx,
  unsigned char *src_image_addr[2],
  unsigned short *depth_addr
  ) {
  if (ctx == NULL || src_image_addr[0] == NULL ||  src_image_addr[1] == NULL || depth_addr == NULL) {
    ERROR("depth_detection_lc_calc_depth: context or buffer pointers should not be NULL.\n");
    return -1;
  }
  unsigned char* rect_image_addr[2] = { NULL, NULL };
  return ((DEPTH_DETCTION_CTX *)ctx)->process(src_image_addr, rect_image_addr, NULL, depth_addr, NULL);
}

int depth_detection_lc_get_rect_image_and_depth(
  void *ctx,
  unsigned char *src_image_addr[2],
  unsigned char *rect_image_addr[2],
  unsigned short *depth_addr
  ) {
  if (ctx == NULL || src_image_addr[0] == NULL || src_image_addr[1] == NULL
   || rect_image_addr[0] == NULL || rect_image_addr[1] == NULL  || depth_addr == NULL) {
    ERROR("depth_detection_lc_calc_depth_width_rect_image: context or buffer pointers should not be NULL.\n");
    return -1;
  }
  return ((DEPTH_DETCTION_CTX *)ctx)->process(src_image_addr, rect_image_addr, NULL, depth_addr, NULL);
}

int depth_detection_lc_get_scan(
  void *ctx,
  unsigned char *src_image_addr[2],
  float *scan_addr
  ) {
  if (ctx == NULL || src_image_addr[0] == NULL ||  src_image_addr[1] == NULL || scan_addr == NULL) {
    ERROR("depth_detection_lc_calc_depth: context or buffer pointers should not be NULL.\n");
    return -1;
  }
  unsigned char* rect_image_addr[2] = { NULL, NULL };
  return ((DEPTH_DETCTION_CTX *)ctx)->process(src_image_addr, rect_image_addr, NULL, NULL, scan_addr);
}

int depth_detection_lc_get_rect_image_and_depth(
  void *ctx,
  unsigned char *src_image_addr[2],
  unsigned char *rect_image_addr[2],
  float *scan_addr
  ) {
  if (ctx == NULL || src_image_addr[0] == NULL || src_image_addr[1] == NULL
   || rect_image_addr[0] == NULL || rect_image_addr[1] == NULL  || scan_addr == NULL) {
    ERROR("depth_detection_lc_calc_depth_width_rect_image: context or buffer pointers should not be NULL.\n");
    return -1;
  }
  return ((DEPTH_DETCTION_CTX *)ctx)->process(src_image_addr, rect_image_addr, NULL, NULL, scan_addr);
}


const char *depth_detection_lc_version_code_get() {
  return "1.0";
}